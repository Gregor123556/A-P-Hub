import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { parseUnstructuredLoAInput, generateChaseLetter } from './src/server/gemini';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // API route for parsing natural language LoA requests
  app.post('/api/parse-loa', async (req, res) => {
    try {
      const { text, referenceDate } = req.body;
      if (!text) {
        res.status(400).json({ error: 'Text prompt is required.' });
        return;
      }
      const refDate = referenceDate || new Date().toLocaleDateString('en-GB');
      const result = await parseUnstructuredLoAInput(text, refDate);
      res.json(result);
    } catch (error: any) {
      console.error('Error in /api/parse-loa:', error);
      res.status(500).json({ error: error?.message || 'Failed to parse request.' });
    }
  });

  // API route for drafting chase letters
  app.post('/api/generate-chase-letter', async (req, res) => {
    try {
      const { clientName, provider, accountType, policyNumber, daysOutstanding, lastChasedDate, urgencyLevel } = req.body;
      const letter = await generateChaseLetter(
        clientName || 'Valued Client',
        provider || 'Provider',
        accountType || 'Pension',
        policyNumber || 'N/A',
        daysOutstanding || 14,
        lastChasedDate,
        urgencyLevel || 'Standard'
      );
      res.json({ letter });
    } catch (error: any) {
      console.error('Error in /api/generate-chase-letter:', error);
      res.status(500).json({ error: error?.message || 'Failed to generate chase letter.' });
    }
  });

  // Vite middleware for dev or Static serving for prod
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Adams & Poole Financial Services Hub] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});


