import { LoAEntry, ProviderContact } from '../types';
import { getTodayDDMMYYYY, formatDDMMYYYY } from '../utils/dateUtils';

// Helper date generator around today
const today = new Date();
const daysAgo = (days: number) => {
  const d = new Date(today);
  d.setDate(d.getDate() - days);
  return formatDDMMYYYY(d);
};

const daysAhead = (days: number) => {
  const d = new Date(today);
  d.setDate(d.getDate() + days);
  return formatDDMMYYYY(d);
};

export const INITIAL_LOAS: LoAEntry[] = [
  {
    id: 'loa-101',
    clientName: 'Arthur & Margaret Pendelton',
    accountType: 'Pension',
    currentProvider: 'Aviva',
    dateSent: daysAgo(18), // Sent 18 days ago -> Due 4 days ago -> OVERDUE
    dateDue: daysAgo(4),
    chaseUpDate: daysAgo(11),
    status: 'Overdue',
    policyNumber: 'AV-993821-P',
    adviserName: 'Sam Adams',
    notes: 'Chased via phone on 05/08/2026. Aviva servicing team reported 15-day processing backlog.',
    lastChasedDate: daysAgo(6),
    createdAt: new Date().toISOString()
  },
  {
    id: 'loa-102',
    clientName: 'Dr. Alistair Finch',
    accountType: 'ISA & GIA',
    currentProvider: 'Fidelity International',
    dateSent: daysAgo(8), // Sent 8 days ago -> Chase date was yesterday (7 days)
    dateDue: daysAhead(6),
    chaseUpDate: daysAgo(1),
    status: 'Pending',
    policyNumber: 'FID-882103',
    adviserName: 'Anthony Poole',
    notes: 'ISA transfer request details requested alongside full breakdown of portfolio funds.',
    createdAt: new Date().toISOString()
  },
  {
    id: 'loa-103',
    clientName: 'Eleanor Vance',
    accountType: 'CIB',
    currentProvider: 'Prudential',
    dateSent: daysAgo(22), // Sent 22 days ago -> Due 8 days ago -> OVERDUE + CHASED
    dateDue: daysAgo(8),
    chaseUpDate: daysAgo(15),
    status: 'Overdue + Chased',
    policyNumber: 'PRU-BND-40291',
    adviserName: 'Sam Adams',
    notes: 'Escalated to Provider Senior Escalations Desk. 2nd formal chase letter issued.',
    lastChasedDate: daysAgo(2),
    createdAt: new Date().toISOString()
  },
  {
    id: 'loa-104',
    clientName: 'Gareth & Fiona Edwards',
    accountType: 'Pension',
    currentProvider: 'Royal London',
    dateSent: daysAgo(12),
    dateDue: daysAhead(2),
    chaseUpDate: daysAgo(5),
    status: 'Pending',
    policyNumber: 'RL-PENS-7712',
    adviserName: 'Anthony Poole',
    notes: 'SIPP transfer authority. Provider acknowledged receipt on 03/08/2026.',
    lastChasedDate: daysAgo(5),
    createdAt: new Date().toISOString()
  },
  {
    id: 'loa-105',
    clientName: 'Victoria Sterling',
    accountType: 'ISA & GIA',
    currentProvider: 'Legal & General',
    dateSent: daysAgo(16),
    dateDue: daysAgo(2),
    chaseUpDate: daysAgo(9),
    status: 'Received',
    policyNumber: 'L&G-INV-0012',
    adviserName: 'Sam Adams',
    notes: 'Full valuation schedule and historic performance summary received & uploaded to Intelligent Office.',
    lastChasedDate: daysAgo(4),
    createdAt: new Date().toISOString()
  },
  {
    id: 'loa-106',
    clientName: 'Rupert Montgomery',
    accountType: 'CIB',
    currentProvider: 'Utmost Wealth Solutions',
    dateSent: daysAgo(3), // Sent 3 days ago
    dateDue: daysAhead(11),
    chaseUpDate: daysAhead(4),
    status: 'Pending',
    policyNumber: 'UTM-OFFSHORE-551',
    adviserName: 'Anthony Poole',
    notes: 'Offshore Bond details requested for estate planning & trust review.',
    createdAt: new Date().toISOString()
  },
  {
    id: 'loa-107',
    clientName: 'Harriet Watson',
    accountType: 'Pension',
    currentProvider: 'Scottish Widows',
    dateSent: daysAgo(14), // Sent 14 days ago -> Due today
    dateDue: getTodayDDMMYYYY(),
    chaseUpDate: daysAgo(7),
    status: 'Pending',
    policyNumber: 'SW-RET-30912',
    adviserName: 'Sam Adams',
    notes: 'Personal Pension CETV (Cash Equivalent Transfer Value) calculation requested.',
    lastChasedDate: daysAgo(7),
    createdAt: new Date().toISOString()
  }
];

export const INITIAL_PROVIDERS: ProviderContact[] = [
  {
    id: 'prov-aviva',
    name: 'Aviva',
    mailingAddress: 'Aviva Life & Pensions UK Ltd, PO Box 520, Norwich, NR1 3WG',
    email: 'loa.pensions@aviva.co.uk',
    phone: '0800 068 6800',
    bestSubmissionMethod: 'unipass',
    avgTurnaroundDays: 16,
    notes: 'Direct Unipass Mailock integration preferred. Scans accepted via paraplanning inbox with client digital signature.'
  },
  {
    id: 'prov-fidelity',
    name: 'Fidelity International',
    mailingAddress: 'Fidelity International, Oakhill House, 130 Tonbridge Road, Hildenborough, Tonbridge, Kent, TN11 9DZ',
    email: 'transfers@fidelity.co.uk',
    phone: '0800 41 41 61',
    bestSubmissionMethod: 'unipass',
    avgTurnaroundDays: 9,
    notes: 'Fast turnaround on Unipass/Origo electronic LoA submissions.'
  },
  {
    id: 'prov-prudential',
    name: 'Prudential',
    mailingAddress: 'Prudential Customer Service Centre, Craigforth, Stirling, FK9 4UE',
    email: 'bonds.servicing@prudential.co.uk',
    phone: '0345 600 0383',
    bestSubmissionMethod: 'post',
    avgTurnaroundDays: 19,
    notes: 'Requires physical wet-ink signed LoA by post for onshore/offshore bonds and legacy retirement plans.'
  },
  {
    id: 'prov-royallondon',
    name: 'Royal London',
    mailingAddress: 'Royal London House, Alderley Park, Congleton Road, Nether Alderley, Macclesfield, SK10 4EL',
    email: 'paraplanning.support@royallondon.com',
    phone: '0345 602 1800',
    bestSubmissionMethod: 'unipass',
    avgTurnaroundDays: 11,
    notes: 'Accepts Unipass Mailock & verified DocuSign attachments via email.'
  },
  {
    id: 'prov-landg',
    name: 'Legal & General',
    mailingAddress: 'Legal & General Customer Services, Knox Court, 10 Fitzalan Park, Cardiff, CF24 0EB',
    email: 'investments.loa@landg.com',
    phone: '0370 050 0955',
    bestSubmissionMethod: 'email',
    avgTurnaroundDays: 12,
    notes: 'Send PDF scans with original or certified electronic signature directly to investments desk.'
  },
  {
    id: 'prov-scottishwidows',
    name: 'Scottish Widows',
    mailingAddress: 'Scottish Widows, 69 Morrison Street, Edinburgh, EH3 8YF',
    email: 'servicing@scottishwidows.co.uk',
    phone: '0345 767 8910',
    bestSubmissionMethod: 'unipass',
    avgTurnaroundDays: 14,
    notes: 'Unipass Mailock submission speeds up CETV and valuation requests by ~4 working days.'
  },
  {
    id: 'prov-utmost',
    name: 'Utmost Wealth Solutions',
    mailingAddress: 'Utmost House, Isle of Man Business Park, Cooil Road, Douglas, Isle of Man, IM2 2QZ',
    email: 'enquiries@utmostwealth.com',
    phone: '01624 643333',
    bestSubmissionMethod: 'post',
    avgTurnaroundDays: 15,
    notes: 'Offshore bond jurisdiction requires original postal authority or verified certified trustee copy.'
  },
  {
    id: 'prov-standardlife',
    name: 'Standard Life',
    mailingAddress: 'Standard Life House, 30 Lothian Road, Edinburgh, EH1 2DH',
    email: 'loa@standardlife.com',
    phone: '0345 606 0000',
    bestSubmissionMethod: 'unipass',
    avgTurnaroundDays: 13,
    notes: 'Unipass digital mailbox or email with adviser agency code cited in subject line.'
  },
  {
    id: 'prov-aegon',
    name: 'Aegon',
    mailingAddress: 'Aegon UK plc, Edinburgh Park, Edinburgh, EH12 9SE',
    email: 'transfers@aegon.co.uk',
    phone: '0345 608 0380',
    bestSubmissionMethod: 'unipass',
    avgTurnaroundDays: 12,
    notes: 'ARC and Retiready platform accounts processed via electronic portal/Unipass.'
  },
  {
    id: 'prov-ajbell',
    name: 'AJ Bell',
    mailingAddress: 'AJ Bell, 4 Exchange Quay, Salford Quays, Manchester, M5 3EE',
    email: 'adviserservices@ajbell.co.uk',
    phone: '0345 408 9100',
    bestSubmissionMethod: 'unipass',
    avgTurnaroundDays: 8,
    notes: 'Direct adviser portal & Unipass Mailock processing with same-week turnarounds.'
  },
  {
    id: 'prov-quilter',
    name: 'Quilter',
    mailingAddress: 'Quilter House, Portland Terrace, Southampton, SO14 7EJ',
    email: 'enquiries@quilter.com',
    phone: '0808 171 2626',
    bestSubmissionMethod: 'unipass',
    avgTurnaroundDays: 10,
    notes: 'Quilter platform and collective investments support Unipass automated authority matching.'
  },
  {
    id: 'prov-transact',
    name: 'Transact',
    mailingAddress: 'Integrated Financial Arrangements Ltd, 29 Clement\'s Lane, London, EC4N 7AE',
    email: 'info@transact-online.co.uk',
    phone: '020 7608 4900',
    bestSubmissionMethod: 'email',
    avgTurnaroundDays: 7,
    notes: 'Dedicated client service team accepts email instructions with digital signatures.'
  },
  {
    id: 'prov-zurich',
    name: 'Zurich Assurance',
    mailingAddress: 'Zurich Financial Services, Tri-centre 1, New Bridge Square, Swindon, SN1 1HN',
    email: 'enquiries@zurich.co.uk',
    phone: '0370 333 1500',
    bestSubmissionMethod: 'post',
    avgTurnaroundDays: 15,
    notes: 'Legacy protection and pension contracts often require posted wet-ink signed authority.'
  },
  {
    id: 'prov-phoenix',
    name: 'Phoenix Life',
    mailingAddress: 'Phoenix Life Limited, 1 Wythall Green Way, Wythall, Birmingham, B47 6WG',
    email: 'servicing@phoenixlife.co.uk',
    phone: '0345 600 0048',
    bestSubmissionMethod: 'post',
    avgTurnaroundDays: 18,
    notes: 'Closed-book policy administrator. Paper postal forms required for policy verification.'
  }
];

export const PROVIDER_CONTACTS: Record<string, { email: string; phone: string; avgTurnaroundDays: number; mailingAddress?: string; bestSubmissionMethod?: 'unipass' | 'post' | 'email' }> = {
  'Aviva': { email: 'loa.pensions@aviva.co.uk', phone: '0800 068 6800', avgTurnaroundDays: 16, mailingAddress: 'Aviva Life & Pensions UK Ltd, PO Box 520, Norwich, NR1 3WG', bestSubmissionMethod: 'unipass' },
  'Prudential': { email: 'bonds.servicing@prudential.co.uk', phone: '0345 600 0383', avgTurnaroundDays: 19, mailingAddress: 'Prudential Customer Service Centre, Craigforth, Stirling, FK9 4UE', bestSubmissionMethod: 'post' },
  'Royal London': { email: 'paraplanning.support@royallondon.com', phone: '0345 602 1800', avgTurnaroundDays: 11, mailingAddress: 'Royal London House, Alderley Park, Congleton Road, Nether Alderley, Macclesfield, SK10 4EL', bestSubmissionMethod: 'unipass' },
  'Fidelity International': { email: 'transfers@fidelity.co.uk', phone: '0800 41 41 61', avgTurnaroundDays: 9, mailingAddress: 'Fidelity International, Oakhill House, 130 Tonbridge Road, Hildenborough, Tonbridge, Kent, TN11 9DZ', bestSubmissionMethod: 'unipass' },
  'Legal & General': { email: 'investments.loa@landg.com', phone: '0370 050 0955', avgTurnaroundDays: 12, mailingAddress: 'Legal & General Customer Services, Knox Court, 10 Fitzalan Park, Cardiff, CF24 0EB', bestSubmissionMethod: 'email' },
  'Scottish Widows': { email: 'servicing@scottishwidows.co.uk', phone: '0345 767 8910', avgTurnaroundDays: 14, mailingAddress: 'Scottish Widows, 69 Morrison Street, Edinburgh, EH3 8YF', bestSubmissionMethod: 'unipass' },
  'Utmost Wealth Solutions': { email: 'enquiries@utmostwealth.com', phone: '01624 643333', avgTurnaroundDays: 15, mailingAddress: 'Utmost House, Isle of Man Business Park, Cooil Road, Douglas, Isle of Man, IM2 2QZ', bestSubmissionMethod: 'post' },
  'Standard Life': { email: 'loa@standardlife.com', phone: '0345 606 0000', avgTurnaroundDays: 13, mailingAddress: 'Standard Life House, 30 Lothian Road, Edinburgh, EH1 2DH', bestSubmissionMethod: 'unipass' },
  'Aegon': { email: 'transfers@aegon.co.uk', phone: '0345 608 0380', avgTurnaroundDays: 12, mailingAddress: 'Aegon UK plc, Edinburgh Park, Edinburgh, EH12 9SE', bestSubmissionMethod: 'unipass' },
  'AJ Bell': { email: 'adviserservices@ajbell.co.uk', phone: '0345 408 9100', avgTurnaroundDays: 8, mailingAddress: 'AJ Bell, 4 Exchange Quay, Salford Quays, Manchester, M5 3EE', bestSubmissionMethod: 'unipass' },
  'Quilter': { email: 'enquiries@quilter.com', phone: '0808 171 2626', avgTurnaroundDays: 10, mailingAddress: 'Quilter House, Portland Terrace, Southampton, SO14 7EJ', bestSubmissionMethod: 'unipass' },
  'Transact': { email: 'info@transact-online.co.uk', phone: '020 7608 4900', avgTurnaroundDays: 7, mailingAddress: 'Integrated Financial Arrangements Ltd, 29 Clement\'s Lane, London, EC4N 7AE', bestSubmissionMethod: 'email' },
  'Zurich': { email: 'enquiries@zurich.co.uk', phone: '0370 333 1500', avgTurnaroundDays: 15, mailingAddress: 'Zurich Financial Services, Tri-centre 1, New Bridge Square, Swindon, SN1 1HN', bestSubmissionMethod: 'post' },
  'Phoenix Life': { email: 'servicing@phoenixlife.co.uk', phone: '0345 600 0048', avgTurnaroundDays: 18, mailingAddress: 'Phoenix Life Limited, 1 Wythall Green Way, Wythall, Birmingham, B47 6WG', bestSubmissionMethod: 'post' }
};
