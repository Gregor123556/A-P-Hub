import { ClientAdminEntry, ClientAdminStep, ClientCategory } from '../types';
import { formatDDMMYYYY } from '../utils/dateUtils';

const today = new Date();
const daysAgo = (days: number) => {
  const d = new Date(today);
  d.setDate(d.getDate() - days);
  return formatDDMMYYYY(d);
};

const daysAhead = (days: number) => {
  const d = new Date(today);
  d.setDate(d.getDate() + days);
  return formatDDMMYYYY(d);
};

export const DEFAULT_POTENTIAL_STEPS: Omit<ClientAdminStep, 'id' | 'isCompleted'>[] = [];

export const DEFAULT_ONGOING_STEPS: Omit<ClientAdminStep, 'id' | 'isCompleted'>[] = [
  {
    title: 'Terms of Business',
    description: 'Signed Client Terms of Business and Fee Agreement logged.'
  },
  {
    title: 'AFAF',
    description: 'Adviser Fee Authorisation Form (AFAF) completed, signed and logged.'
  },
  {
    title: 'Illustrations & Charges',
    description: 'Platform illustrations and full cost & charges disclosure pack produced.'
  },
  {
    title: 'ID3',
    description: 'Electronic ID3 / SmartSearch verification & AML/KYC checks completed.'
  },
  {
    title: 'Source of Funds',
    description: 'Source of wealth and funds verified and compliant.'
  },
  {
    title: 'ATR',
    description: 'Attitude to Risk (ATR) assessment and capacity for loss completed.'
  },
  {
    title: 'Suitability Report',
    description: 'Comprehensive Suitability Report drafted, peer-reviewed and presented.'
  },
  {
    title: 'Set up Servicing',
    description: 'Set up ongoing platform servicing, fee schedules and review triggers.'
  },
  {
    title: 'Xplan FF',
    description: 'Xplan Fact Find (FF) profile created, mapped and verified in practice management system.'
  }
];

export const DEFAULT_ONBOARDED_STEPS: Omit<ClientAdminStep, 'id' | 'isCompleted'>[] = [
  {
    title: 'Money Landed Confirmation',
    description: 'Confirm client investments/funds have landed into designated platform accounts.'
  },
  {
    title: 'Servicing Set Up Confirmation',
    description: 'Confirm ongoing servicing schedule, review triggers and fee mandates are operational.'
  },
  {
    title: 'Handover to Servicing Pipeline',
    description: 'Transition client file smoothly into the Servicing management workflow.'
  }
];

export const DEFAULT_COMPLETED_STEPS: Omit<ClientAdminStep, 'id' | 'isCompleted'>[] = [
  {
    title: 'Administrative & Transfer Sign-Off',
    description: 'All paraplanning, LoAs, advice recommendations, and fund transfers completed.'
  },
  {
    title: 'Funds Landed & Reconciled',
    description: 'All client funds landed in designated platforms and reconciled.'
  },
  {
    title: 'Servicing Schedule Active',
    description: 'Ongoing servicing review triggers and communications active in Servicing pipeline.'
  },
  {
    title: 'Archived to Dormant Complete Files Database',
    description: 'File archived as complete and accessible for historical audit and reporting.'
  }
];

export const DEFAULT_ON_HOLD_STEPS: Omit<ClientAdminStep, 'id' | 'isCompleted'>[] = [
  {
    title: 'Reason for Hold Formally Logged with Adviser Approval',
    description: 'Document reason for temporary pause and adviser sign-off.'
  },
  {
    title: 'Client & Third Parties Notified in Writing',
    description: 'Confirm file is on hold and notify solicitors/accountants if applicable.'
  },
  {
    title: 'Periodic Diary Review Trigger Set in Calendar',
    description: 'Set 30-day or 60-day calendar review reminder to recheck status.'
  },
  {
    title: 'Outstanding External Prerequisite Monitored',
    description: 'Track external resolution (e.g. Probate Registry grant, divorce, medicals).'
  },
  {
    title: 'Reactivation Review & Updated Fact Find Checklist',
    description: 'Prepare checklist to resume active ongoing processing when ready.'
  }
];

export function normalizeOngoingMilestones(steps?: ClientAdminStep[], clientPrefix?: string): ClientAdminStep[] {
  const defaultMilestones = DEFAULT_ONGOING_STEPS;
  const prefix = clientPrefix || `ong-${Math.random().toString(36).substring(2, 6)}`;

  if (!steps || !Array.isArray(steps) || steps.length === 0) {
    return defaultMilestones.map((m, idx) => ({
      id: `step-${prefix}-${idx + 1}-${Math.random().toString(36).substring(2, 6)}`,
      title: m.title,
      description: m.description,
      isCompleted: false
    }));
  }

  const usedIds = new Set<string>();

  // Check if steps already match the 9 milestones exactly and have distinct IDs
  const hasExact9 = steps.length === defaultMilestones.length &&
    defaultMilestones.every((dm, i) => steps[i]?.title === dm.title);
  
  if (hasExact9) {
    return steps.map((s, idx) => {
      let id = s.id;
      if (!id || usedIds.has(id)) {
        id = `step-${prefix}-${idx + 1}-${Math.random().toString(36).substring(2, 6)}`;
      }
      usedIds.add(id);
      return { ...s, id };
    });
  }

  // Map from legacy or partial steps into the 9 exact milestones with no ID collisions
  const matchedExistingIds = new Set<string>();

  return defaultMilestones.map((dm, idx) => {
    const existing = steps.find(s => {
      if (s.id && matchedExistingIds.has(s.id)) return false;
      const t = (s.title || '').toLowerCase();
      const target = dm.title.toLowerCase();
      if (t === target) return true;
      if (target === 'terms of business' && (t.includes('terms of business') || t.includes('terms of engagement'))) return true;
      if (target === 'afaf' && (t.includes('afaf') || t.includes('fee mandate') || t.includes('fee authorisation'))) return true;
      if (target === 'illustrations & charges' && (t.includes('illustration') || t.includes('charges') || t.includes('cashflow'))) return true;
      if (target === 'id3' && (t.includes('id3') || t.includes('aml') || t.includes('kyc') || t.includes('identity'))) return true;
      if (target === 'source of funds' && (t.includes('source of funds') || t.includes('source of wealth'))) return true;
      if (target === 'atr' && (t.includes('atr') || t.includes('attitude to risk') || t.includes('risk profiling'))) return true;
      if (target === 'suitability report' && (t.includes('suitability report') || t.includes('statement of advice'))) return true;
      if (target === 'set up servicing' && (t.includes('set up servicing') || t.includes('platform application') || t.includes('annual review'))) return true;
      if (target === 'xplan ff' && (t.includes('xplan') || t.includes('ff') || t.includes('fact find'))) return true;
      return false;
    });

    if (existing?.id) {
      matchedExistingIds.add(existing.id);
    }

    let id = existing?.id;
    if (!id || usedIds.has(id)) {
      id = `step-${prefix}-${idx + 1}-${Math.random().toString(36).substring(2, 6)}`;
    }
    usedIds.add(id);

    return {
      id,
      title: dm.title,
      description: dm.description,
      isCompleted: !!existing?.isCompleted,
      completedAt: existing?.completedAt || '',
      completedBy: existing?.completedBy || '',
      dueDate: existing?.dueDate || '',
      notes: existing?.notes || ''
    };
  });
}

export function generateStepsForCategory(category: ClientCategory): ClientAdminStep[] {
  const templates = 
    category === 'potential' ? DEFAULT_POTENTIAL_STEPS :
    category === 'ongoing' ? DEFAULT_ONGOING_STEPS :
    category === 'onboarded' ? DEFAULT_ONBOARDED_STEPS :
    category === 'completed' ? DEFAULT_COMPLETED_STEPS :
    DEFAULT_ON_HOLD_STEPS;

  return templates.map((t, index) => ({
    id: `step-${category}-${index + 1}-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    title: t.title,
    description: t.description,
    isCompleted: false
  }));
}

export const INITIAL_CLIENT_ADMIN: ClientAdminEntry[] = [
  // 1. Potential Clients
  {
    id: 'client-pot-1',
    clientName: 'Edward & Caroline Thornton',
    category: 'potential',
    adviserName: 'Sam Adams',
    serviceType: 'Pension',
    estimatedValue: '£520,000',
    potentialSelectedFund: 'Quilter Cirilium Moderate Portfolio',
    proposedFeeInitial: '3%',
    proposedFeeOngoing: '1%',
    email: 'thornton.edward@outlook.com',
    phone: '07700 900142',
    notes: 'Initial discovery meeting held on Tuesday. Clients very keen to consolidate 3 legacy defined contribution pots into a unified Quilter SIPP.',
    createdAt: new Date().toISOString(),
    steps: [],
    factFind: {
      status: 'in_progress',
      currentStage: 2,
      stage1: {
        hasSecondClient: true,
        client1: {
          fullName: 'Edward Thornton',
          dateOfBirth: '14-06-1965',
          email: 'thornton.edward@outlook.com',
          phone: '07700 900142',
          address: '14 Highwood Close, Guildford, Surrey, GU1 2AZ'
        },
        client2: {
          fullName: 'Caroline Thornton',
          dateOfBirth: '22-09-1967',
          email: 'caroline.thornton@outlook.com',
          phone: '07700 900143',
          address: '14 Highwood Close, Guildford, Surrey, GU1 2AZ'
        },
        meetingDate: daysAgo(2),
        adviser: 'Sam Adams'
      },
      stage2: {
        maritalStatus: 'Married',
        vulnerability: {
          answered: 'no',
          details: "Client is of full sound body and mind, they're financially independent and fully grasped our discussion"
        },
        pepSanctions: {
          answered: 'no',
          details: ''
        },
        dependants: {
          answered: 'yes',
          details: 'Two financially independent adult children; elder daughter currently pursuing post-grad with occasional rent subsidy.'
        },
        willInPlace: {
          answered: 'yes',
          details: 'Standard mirror wills drafted in 2018 with family solicitor (Wilsons LLP). Need review following property sale.'
        },
        powerOfAttorney: {
          answered: 'no',
          details: ''
        },
        expectedLifeChanges: {
          answered: 'yes',
          details: 'Edward plans to semi-retire from engineering consultancy in 2.5 years; downsizing main family home in Surrey within 4 years.'
        }
      },
      stage3: {
        incomeStreams: [
          {
            id: 'income-1',
            employmentStatus: 'Employed',
            employerBusiness: 'Thornton Engineering Consultants Ltd',
            annualIncome: '£110,000'
          },
          {
            id: 'income-2',
            employmentStatus: 'Employed',
            employerBusiness: 'Surrey County Council',
            annualIncome: '£42,000'
          },
          {
            id: 'income-3',
            employmentStatus: 'Other',
            employerBusiness: 'Buy-To-Let Rental Property (Guildford)',
            annualIncome: '£16,200'
          }
        ],
        monthlyExpenses: '£4,200',
        employmentStatus: 'Employed',
        employer: 'Thornton Engineering Consultants Ltd',
        annualIncomeApprox: '£110,000',
        otherIncome: {
          answered: 'yes',
          details: 'Rental income from 2-bed buy-to-let property in Guildford (£1,350/mo gross).'
        },
        client1: {
          employmentStatus: 'Employed',
          employer: 'Thornton Engineering Consultants Ltd',
          annualIncomeApprox: '£110,000',
          monthlyExpenses: '£4,200',
          otherIncome: {
            answered: 'yes',
            details: 'Rental income from 2-bed buy-to-let property in Guildford (£1,350/mo gross).'
          }
        },
        client2: {
          employmentStatus: 'Employed',
          employer: 'Surrey County Council',
          annualIncomeApprox: '£42,000',
          monthlyExpenses: '£0',
          otherIncome: {
            answered: 'no',
            details: ''
          }
        }
      },
      stage4: {
        assets: [
          {
            id: 'asset-1',
            assetType: 'Residential Property',
            providerPlatform: 'Main Residence (Guildford, Surrey)',
            approxValue: '£750,000',
            notes: 'Mortgage-free 4-bed detached family home. Last formal valuation Q3 2024.'
          },
          {
            id: 'asset-2',
            assetType: 'Additional Property',
            providerPlatform: 'Buy-to-Let (Guildford town centre)',
            approxValue: '£285,000',
            notes: '2-bed apartment let out at £1,350/mo. Remaining interest-only mortgage £95,000.'
          },
          {
            id: 'asset-3',
            assetType: 'Stock & Shares ISA',
            providerPlatform: 'Hargreaves Lansdown',
            approxValue: '£165,000',
            notes: 'Mix of global equity index trackers and blue-chip UK equities across both Edward and Caroline.'
          },
          {
            id: 'asset-4',
            assetType: 'Cash ISA',
            providerPlatform: 'Marcus by Goldman Sachs',
            approxValue: '£45,000',
            notes: 'Easy-access emergency liquidity cash reserve.'
          }
        ],
        totalApproxValue: '£1,245,000',
        notes: 'Assets held jointly or individually as indicated. Mortgages deducted from gross property figures where noted.'
      }
    }
  },
  {
    id: 'client-pot-2',
    clientName: 'Dr. Natasha Patel',
    category: 'potential',
    adviserName: 'Anthony Poole',
    serviceType: 'ISA & GIA',
    estimatedValue: '£240,000',
    potentialSelectedFund: 'Vanguard LifeStrategy 60% Equity',
    proposedFeeInitial: '3%',
    proposedFeeOngoing: '1%',
    email: 'npatel.consulting@gmail.com',
    phone: '07700 900581',
    notes: 'Referred by existing client Victoria Sterling. Seeking tax-efficient growth across Stocks & Shares ISA and General Investment Account.',
    createdAt: new Date().toISOString(),
    steps: [],
    factFind: {
      status: 'in_progress',
      currentStage: 1,
      stage1: {
        hasSecondClient: false,
        client1: {
          fullName: 'Dr. Natasha Patel',
          dateOfBirth: '08-11-1979',
          email: 'npatel.consulting@gmail.com',
          phone: '07700 900581',
          address: '72 Westbourne Terrace, London, W2 3UJ'
        },
        meetingDate: daysAgo(1),
        adviser: 'Anthony Poole'
      }
    }
  },
  {
    id: 'client-pot-3',
    clientName: 'Marcus & Linda Gallagher',
    category: 'potential',
    adviserName: 'Sam Adams',
    serviceType: 'CIB',
    estimatedValue: '£780,000',
    potentialSelectedFund: 'L&G Multi-Index 4 Portfolio',
    proposedFeeInitial: '3%',
    proposedFeeOngoing: '1%',
    email: 'marcus.gallagher@gallagher-ltd.co.uk',
    phone: '07700 900892',
    notes: 'Clients seeking IHT mitigation strategies following sale of commercial premises. Initial discovery meeting completed last Friday.',
    createdAt: new Date().toISOString(),
    steps: [],
    factFind: {
      status: 'not_started',
      currentStage: 1,
      stage1: {
        hasSecondClient: true,
        client1: {
          fullName: 'Marcus Gallagher',
          dateOfBirth: '03-04-1958',
          email: 'marcus.gallagher@gallagher-ltd.co.uk',
          phone: '07700 900892',
          address: 'Oaklands Manor, Chelmsford Road, Essex, CM1 4LP'
        },
        client2: {
          fullName: 'Linda Gallagher',
          dateOfBirth: '19-12-1960',
          email: 'linda.gallagher@gallagher-ltd.co.uk',
          phone: '07700 900893',
          address: 'Oaklands Manor, Chelmsford Road, Essex, CM1 4LP'
        },
        meetingDate: formatDDMMYYYY(today),
        adviser: 'Sam Adams'
      }
    }
  },
  {
    id: 'client-pot-4',
    clientName: 'Timothy Peter Cripps',
    category: 'potential',
    adviserName: 'Sam Adams',
    serviceType: 'Pension',
    estimatedValue: '£460,000',
    potentialSelectedFund: 'Vanguard LifeStrategy 60% Equity',
    proposedFeeInitial: '3%',
    proposedFeeOngoing: '1%',
    email: 'timothy.cripps@outlook.com',
    phone: '07700 900389',
    notes: 'Initial discovery and Stage 2 assessment completed. Vulnerability notes and support requirements logged.',
    createdAt: new Date().toISOString(),
    steps: [],
    factFind: {
      status: 'in_progress',
      currentStage: 2,
      stage1: {
        hasSecondClient: false,
        client1: {
          fullName: 'Timothy Peter Cripps',
          dateOfBirth: '18-05-1959',
          email: 'timothy.cripps@outlook.com',
          phone: '07700 900389',
          address: '42 Meadowbrook Lane, Chichester, West Sussex, PO19 8TY'
        },
        meetingDate: daysAgo(3),
        adviser: 'Sam Adams'
      },
      stage2: {
        maritalStatus: 'Single',
        vulnerability: {
          answered: 'yes',
          details: 'Client has disclosed mild hearing impairment requiring written confirmation of all verbal advice, and has recently suffered bereavement. Additional time allocated for review and key documents provided in large font.'
        },
        pepSanctions: {
          answered: 'no',
          details: ''
        },
        dependants: {
          answered: 'no',
          details: ''
        },
        willInPlace: {
          answered: 'yes',
          details: 'Valid Will drafted in 2021 with Chichester Legal Services; executor appointed.'
        },
        powerOfAttorney: {
          answered: 'yes',
          details: 'Lasting Power of Attorney for Property & Financial Affairs registered with OPG.'
        },
        expectedLifeChanges: {
          answered: 'yes',
          details: 'Planning retirement within 18 months; transitioning DC pension pot to flexible drawdown.'
        }
      },
      stage3: {
        incomeStreams: [
          {
            id: 'income-tc-1',
            employmentStatus: 'Employed',
            employerBusiness: 'Sussex Maritime Logistics Ltd',
            annualIncome: '£68,000'
          }
        ],
        monthlyExpenses: '£2,600'
      },
      stage4: {
        assets: [
          {
            id: 'asset-tc-1',
            assetType: 'Residential Property',
            providerPlatform: 'Main Residence (Chichester)',
            approxValue: '£420,000',
            notes: 'Unencumbered property.'
          },
          {
            id: 'asset-tc-2',
            assetType: 'Pension Pot',
            providerPlatform: 'Aviva Workplace Pension',
            approxValue: '£380,000',
            notes: 'Defined contribution pension scheme scheduled for consolidation.'
          },
          {
            id: 'asset-tc-3',
            assetType: 'Stock & Shares ISA',
            providerPlatform: 'AJ Bell Youinvest',
            approxValue: '£80,000',
            notes: 'Tax-efficient investment portfolio.'
          }
        ],
        totalApproxValue: '£880,000',
        liabilities: {
          answered: 'no',
          details: ''
        }
      }
    }
  },

  // 2. Ongoing Clients
  {
    id: 'client-ong-1',
    clientName: 'Arthur & Margaret Pendelton',
    category: 'ongoing',
    adviserName: 'Sam Adams',
    serviceType: 'Pension',
    estimatedValue: '£640,000',
    potentialSelectedFund: 'Vanguard LifeStrategy 60% Equity',
    proposedFeeInitial: '3%',
    proposedFeeOngoing: '1%',
    signUpDate: daysAgo(25),
    targetCompletionDate: daysAhead(15),
    nextAction: 'Escalate overdue Aviva LoA info pack & finalize cashflow model',
    nextActionDueDate: daysAhead(1),
    email: 'pendelton.arthur@btinternet.com',
    phone: '01603 492019',
    notes: 'Signed engagement received. LoA dispatched to Aviva 18 days ago (currently overdue on LoA tracker). AML verified via SmartSearch.',
    createdAt: new Date().toISOString(),
    steps: [
      {
        id: 'step-ong-1-1',
        title: 'Terms of Business',
        description: 'Signed Client Terms of Business and Fee Agreement logged.',
        isCompleted: true,
        completedAt: daysAgo(25),
        completedBy: 'Sam Adams'
      },
      {
        id: 'step-ong-1-2',
        title: 'AFAF',
        description: 'Adviser Fee Authorisation Form (AFAF) completed, signed and logged.',
        isCompleted: true,
        completedAt: daysAgo(25),
        completedBy: 'Sam Adams'
      },
      {
        id: 'step-ong-1-3',
        title: 'Illustrations & Charges',
        description: 'Platform illustrations and full cost & charges disclosure pack produced.',
        isCompleted: true,
        completedAt: daysAgo(24),
        completedBy: 'Paraplanning Desk'
      },
      {
        id: 'step-ong-1-4',
        title: 'ID3',
        description: 'Electronic ID3 / SmartSearch verification & AML/KYC checks completed.',
        isCompleted: true,
        completedAt: daysAgo(24),
        completedBy: 'Paraplanning Desk'
      },
      {
        id: 'step-ong-1-5',
        title: 'Source of Funds',
        description: 'Source of wealth and funds verified and compliant.',
        isCompleted: true,
        completedAt: daysAgo(20),
        completedBy: 'Sam Adams'
      },
      {
        id: 'step-ong-1-6',
        title: 'ATR',
        description: 'Attitude to Risk (ATR) assessment and capacity for loss completed.',
        isCompleted: true,
        completedAt: daysAgo(20),
        completedBy: 'Sam Adams'
      },
      {
        id: 'step-ong-1-7',
        title: 'Suitability Report',
        description: 'Comprehensive Suitability Report drafted, peer-reviewed and presented.',
        isCompleted: false,
        dueDate: daysAhead(1)
      },
      {
        id: 'step-ong-1-8',
        title: 'Set up Servicing',
        description: 'Set up ongoing platform servicing, fee schedules and review triggers.',
        isCompleted: false
      },
      {
        id: 'step-ong-1-9',
        title: 'Xplan FF',
        description: 'Xplan Fact Find (FF) profile created, mapped and verified in practice management system.',
        isCompleted: false
      }
    ]
  },
  {
    id: 'client-ong-2',
    clientName: 'Eleanor Vance',
    category: 'ongoing',
    adviserName: 'Sam Adams',
    serviceType: 'CIB',
    estimatedValue: '£390,000',
    potentialSelectedFund: 'Quilter Cirilium Moderate Portfolio',
    proposedFeeInitial: '3%',
    proposedFeeOngoing: '0.75%',
    signUpDate: daysAgo(30),
    targetCompletionDate: daysAhead(10),
    nextAction: 'Receive Prudential bond breakdown following 2nd chase letter',
    nextActionDueDate: daysAhead(3),
    email: 'evance.heritage@gmail.com',
    phone: '07700 900234',
    notes: '2nd formal chase letter issued to Prudential customer service centre. Paraplanning research ready once bond surrender values and chargeable event gains are confirmed.',
    createdAt: new Date().toISOString(),
    steps: [
      {
        id: 'step-ong-2-1',
        title: 'Terms of Business',
        description: 'Signed Client Terms of Business and Fee Agreement logged.',
        isCompleted: true,
        completedAt: daysAgo(30),
        completedBy: 'Sam Adams'
      },
      {
        id: 'step-ong-2-2',
        title: 'AFAF',
        description: 'Adviser Fee Authorisation Form (AFAF) completed, signed and logged.',
        isCompleted: true,
        completedAt: daysAgo(30),
        completedBy: 'Sam Adams'
      },
      {
        id: 'step-ong-2-3',
        title: 'Illustrations & Charges',
        description: 'Platform illustrations and full cost & charges disclosure pack produced.',
        isCompleted: false,
        dueDate: daysAhead(3)
      },
      {
        id: 'step-ong-2-4',
        title: 'ID3',
        description: 'Electronic ID3 / SmartSearch verification & AML/KYC checks completed.',
        isCompleted: true,
        completedAt: daysAgo(29),
        completedBy: 'Paraplanning Desk'
      },
      {
        id: 'step-ong-2-5',
        title: 'Source of Funds',
        description: 'Source of wealth and funds verified and compliant.',
        isCompleted: true,
        completedAt: daysAgo(28),
        completedBy: 'Sam Adams'
      },
      {
        id: 'step-ong-2-6',
        title: 'ATR',
        description: 'Attitude to Risk (ATR) assessment and capacity for loss completed.',
        isCompleted: true,
        completedAt: daysAgo(26),
        completedBy: 'Sam Adams'
      },
      {
        id: 'step-ong-2-7',
        title: 'Suitability Report',
        description: 'Comprehensive Suitability Report drafted, peer-reviewed and presented.',
        isCompleted: false
      },
      {
        id: 'step-ong-2-8',
        title: 'Set up Servicing',
        description: 'Set up ongoing platform servicing, fee schedules and review triggers.',
        isCompleted: false
      },
      {
        id: 'step-ong-2-9',
        title: 'Xplan FF',
        description: 'Xplan Fact Find (FF) profile created, mapped and verified in practice management system.',
        isCompleted: false
      }
    ]
  },
  {
    id: 'client-ong-3',
    clientName: 'Gareth & Fiona Edwards',
    category: 'ongoing',
    adviserName: 'Anthony Poole',
    serviceType: 'Pension',
    estimatedValue: '£480,000',
    potentialSelectedFund: 'L&G Multi-Index 4 Portfolio',
    proposedFeeInitial: '3%',
    proposedFeeOngoing: '1%',
    signUpDate: daysAgo(18),
    targetCompletionDate: daysAhead(22),
    nextAction: 'Collate Royal London scheme info and begin Suitability Report draft',
    nextActionDueDate: daysAhead(4),
    email: 'edwards.gareth@edwards-engineering.co.uk',
    phone: '01625 582910',
    notes: 'Royal London acknowledged electronic Unipass LoA. Turnaround expected within 48 hours.',
    createdAt: new Date().toISOString(),
    steps: [
      {
        id: 'step-ong-3-1',
        title: 'Terms of Business',
        description: 'Signed Client Terms of Business and Fee Agreement logged.',
        isCompleted: true,
        completedAt: daysAgo(18),
        completedBy: 'Anthony Poole'
      },
      {
        id: 'step-ong-3-2',
        title: 'AFAF',
        description: 'Adviser Fee Authorisation Form (AFAF) completed, signed and logged.',
        isCompleted: true,
        completedAt: daysAgo(18),
        completedBy: 'Anthony Poole'
      },
      {
        id: 'step-ong-3-3',
        title: 'Illustrations & Charges',
        description: 'Platform illustrations and full cost & charges disclosure pack produced.',
        isCompleted: true,
        completedAt: daysAgo(17),
        completedBy: 'Paraplanning Desk'
      },
      {
        id: 'step-ong-3-4',
        title: 'ID3',
        description: 'Electronic ID3 / SmartSearch verification & AML/KYC checks completed.',
        isCompleted: true,
        completedAt: daysAgo(17),
        completedBy: 'Paraplanning Desk'
      },
      {
        id: 'step-ong-3-5',
        title: 'Source of Funds',
        description: 'Source of wealth and funds verified and compliant.',
        isCompleted: true,
        completedAt: daysAgo(16),
        completedBy: 'Anthony Poole'
      },
      {
        id: 'step-ong-3-6',
        title: 'ATR',
        description: 'Attitude to Risk (ATR) assessment and capacity for loss completed.',
        isCompleted: true,
        completedAt: daysAgo(15),
        completedBy: 'Anthony Poole'
      },
      {
        id: 'step-ong-3-7',
        title: 'Suitability Report',
        description: 'Comprehensive Suitability Report drafted, peer-reviewed and presented.',
        isCompleted: false,
        dueDate: daysAhead(4)
      },
      {
        id: 'step-ong-3-8',
        title: 'Set up Servicing',
        description: 'Set up ongoing platform servicing, fee schedules and review triggers.',
        isCompleted: false
      },
      {
        id: 'step-ong-3-9',
        title: 'Xplan FF',
        description: 'Xplan Fact Find (FF) profile created, mapped and verified in practice management system.',
        isCompleted: false
      }
    ]
  },
  {
    id: 'client-ong-4',
    clientName: 'Victoria Sterling',
    category: 'ongoing',
    adviserName: 'Sam Adams',
    serviceType: 'ISA & GIA',
    estimatedValue: '£850,000',
    potentialSelectedFund: 'Tatton Core Active Portfolio',
    proposedFeeInitial: '2.5%',
    proposedFeeOngoing: '1%',
    signUpDate: daysAgo(35),
    targetCompletionDate: daysAhead(5),
    nextAction: 'Client recommendation presentation meeting scheduled for Thursday',
    nextActionDueDate: daysAhead(2),
    email: 'v.sterling@sterling-holdings.co.uk',
    phone: '020 7946 0912',
    notes: 'Full information pack received from Legal & General. Suitability report drafted and quality checked by Sam. Recommendation meeting booked.',
    createdAt: new Date().toISOString(),
    steps: [
      {
        id: 'step-ong-4-1',
        title: 'Terms of Business',
        description: 'Signed Client Terms of Business and Fee Agreement logged.',
        isCompleted: true,
        completedAt: daysAgo(35),
        completedBy: 'Sam Adams'
      },
      {
        id: 'step-ong-4-2',
        title: 'AFAF',
        description: 'Adviser Fee Authorisation Form (AFAF) completed, signed and logged.',
        isCompleted: true,
        completedAt: daysAgo(35),
        completedBy: 'Sam Adams'
      },
      {
        id: 'step-ong-4-3',
        title: 'Illustrations & Charges',
        description: 'Platform illustrations and full cost & charges disclosure pack produced.',
        isCompleted: true,
        completedAt: daysAgo(34),
        completedBy: 'Paraplanning Desk'
      },
      {
        id: 'step-ong-4-4',
        title: 'ID3',
        description: 'Electronic ID3 / SmartSearch verification & AML/KYC checks completed.',
        isCompleted: true,
        completedAt: daysAgo(34),
        completedBy: 'Paraplanning Desk'
      },
      {
        id: 'step-ong-4-5',
        title: 'Source of Funds',
        description: 'Source of wealth and funds verified and compliant.',
        isCompleted: true,
        completedAt: daysAgo(30),
        completedBy: 'Sam Adams'
      },
      {
        id: 'step-ong-4-6',
        title: 'ATR',
        description: 'Attitude to Risk (ATR) assessment and capacity for loss completed.',
        isCompleted: true,
        completedAt: daysAgo(30),
        completedBy: 'Sam Adams'
      },
      {
        id: 'step-ong-4-7',
        title: 'Suitability Report',
        description: 'Comprehensive Suitability Report drafted, peer-reviewed and presented.',
        isCompleted: true,
        completedAt: daysAgo(1),
        completedBy: 'Sam Adams'
      },
      {
        id: 'step-ong-4-8',
        title: 'Set up Servicing',
        description: 'Set up ongoing platform servicing, fee schedules and review triggers.',
        isCompleted: false,
        dueDate: daysAhead(2)
      },
      {
        id: 'step-ong-4-9',
        title: 'Xplan FF',
        description: 'Xplan Fact Find (FF) profile created, mapped and verified in practice management system.',
        isCompleted: false
      }
    ]
  },

  // 3. On Hold Clients
  {
    id: 'client-hld-1',
    clientName: 'Estate of William C. Harris',
    category: 'on_hold',
    adviserName: 'Sam Adams',
    serviceType: 'CIB',
    estimatedValue: '£920,000',
    signUpDate: daysAgo(45),
    onHoldReason: 'Awaiting Grant of Probate from Probate Registry (Executors: James & Susan Harris)',
    nextAction: 'Check with Harrison & Cole Solicitors for Probate Grant issue status',
    nextActionDueDate: daysAhead(14),
    email: 'james.harris@harris-estates.com',
    phone: '01603 720199',
    notes: 'File temporarily on hold pending official Grant of Probate. Solicitors estimate 4-6 weeks turnaround from HMCTS Probate Service.',
    createdAt: new Date().toISOString(),
    steps: [
      {
        id: 'step-hld-1-1',
        title: 'Reason for Hold Formally Logged with Adviser Approval',
        isCompleted: true,
        completedAt: daysAgo(40),
        completedBy: 'Sam Adams'
      },
      {
        id: 'step-hld-1-2',
        title: 'Client & Third Parties Notified in Writing',
        isCompleted: true,
        completedAt: daysAgo(39),
        completedBy: 'Sam Adams'
      },
      {
        id: 'step-hld-1-3',
        title: 'Periodic Diary Review Trigger Set in Calendar',
        isCompleted: true,
        completedAt: daysAgo(38),
        completedBy: 'Paraplanning Desk',
        notes: 'Diary trigger set for 14-day intervals'
      },
      {
        id: 'step-hld-1-4',
        title: 'Outstanding External Prerequisite Monitored',
        isCompleted: false,
        dueDate: daysAhead(14),
        notes: 'Awaiting Grant of Probate'
      },
      {
        id: 'step-hld-1-5',
        title: 'Reactivation Review & Updated Fact Find Checklist',
        isCompleted: false
      }
    ]
  },
  {
    id: 'client-hld-2',
    clientName: 'Simon & Rachel Beaumont',
    category: 'on_hold',
    adviserName: 'Anthony Poole',
    serviceType: 'Pension',
    estimatedValue: '£310,000',
    signUpDate: daysAgo(50),
    onHoldReason: 'Clients temporarily seconded overseas in Singapore until late October 2026',
    nextAction: 'Schedule video check-in call ahead of clients return to UK',
    nextActionDueDate: daysAhead(30),
    email: 'beaumont.simon@singapore-tech.sg',
    phone: '+65 6789 0123',
    notes: 'Initial fact find completed. On hold while clients confirm their UK non-resident tax status with KPMG before proceeding with DB transfer evaluation.',
    createdAt: new Date().toISOString(),
    steps: [
      {
        id: 'step-hld-2-1',
        title: 'Reason for Hold Formally Logged with Adviser Approval',
        isCompleted: true,
        completedAt: daysAgo(45),
        completedBy: 'Anthony Poole'
      },
      {
        id: 'step-hld-2-2',
        title: 'Client & Third Parties Notified in Writing',
        isCompleted: true,
        completedAt: daysAgo(44),
        completedBy: 'Anthony Poole'
      },
      {
        id: 'step-hld-2-3',
        title: 'Periodic Diary Review Trigger Set in Calendar',
        isCompleted: true,
        completedAt: daysAgo(43),
        completedBy: 'Paraplanning Desk'
      },
      {
        id: 'step-hld-2-4',
        title: 'Outstanding External Prerequisite Monitored',
        isCompleted: false,
        dueDate: daysAhead(30),
        notes: 'KPMG UK tax residency opinion awaited'
      },
      {
        id: 'step-hld-2-5',
        title: 'Reactivation Review & Updated Fact Find Checklist',
        isCompleted: false
      }
    ]
  },
  {
    id: 'client-onb-1',
    clientName: 'Oliver & Sophia Vance',
    category: 'onboarded',
    adviserName: 'Sam Adams',
    serviceType: 'ISA & GIA',
    estimatedValue: '£420,000',
    signUpDate: daysAgo(35),
    moneyLanded: true,
    moneyLandedDate: daysAgo(3),
    servicingSetUp: false,
    nextAction: 'Confirm servicing mandate activation and schedule welcome call',
    nextActionDueDate: daysAhead(4),
    email: 'oliver.vance@vancetech.co.uk',
    phone: '07700 900543',
    notes: 'All 9 administrative onboarding stages completed. Money has landed in Aviva wrap platform. Pending final servicing schedule activation.',
    createdAt: new Date().toISOString(),
    steps: [
      {
        id: 'step-onb-1-1',
        title: 'Money Landed Confirmation',
        isCompleted: true,
        completedAt: daysAgo(3),
        completedBy: 'Sam Adams'
      },
      {
        id: 'step-onb-1-2',
        title: 'Servicing Set Up Confirmation',
        isCompleted: false
      },
      {
        id: 'step-onb-1-3',
        title: 'Handover to Servicing Pipeline',
        isCompleted: false
      }
    ]
  },
  // 5. Completed Clients (Dormant Database for Complete Files)
  {
    id: 'client-comp-1',
    clientName: 'Geoffrey & Diane Harper',
    category: 'completed',
    adviserName: 'Sam Adams',
    serviceType: 'Pension & ISA',
    estimatedValue: '£720,000',
    signUpDate: daysAgo(60),
    moneyLanded: true,
    moneyLandedDate: daysAgo(14),
    servicingSetUp: true,
    servicingSetUpDate: daysAgo(14),
    nextAction: 'File completed and archived in dormant database • Active in Servicing tab',
    email: 'harper.gd@gmail.com',
    phone: '07700 900892',
    notes: 'All 9 administrative milestones, money landed, and servicing configuration complete. Transferred to dormant complete files database and active in Servicing pipeline.',
    createdAt: new Date().toISOString(),
    steps: [
      {
        id: 'step-comp-1-1',
        title: 'Administrative & Transfer Sign-Off',
        isCompleted: true,
        completedAt: daysAgo(14),
        completedBy: 'Sam Adams'
      },
      {
        id: 'step-comp-1-2',
        title: 'Funds Landed & Reconciled',
        isCompleted: true,
        completedAt: daysAgo(14),
        completedBy: 'Sam Adams'
      },
      {
        id: 'step-comp-1-3',
        title: 'Servicing Schedule Active',
        isCompleted: true,
        completedAt: daysAgo(14),
        completedBy: 'Sam Adams'
      },
      {
        id: 'step-comp-1-4',
        title: 'Archived to Dormant Complete Files Database',
        isCompleted: true,
        completedAt: daysAgo(14),
        completedBy: 'Paraplanning Desk'
      }
    ]
  }
];
