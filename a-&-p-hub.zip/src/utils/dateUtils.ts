/**
 * Date utilities for DD-MM-YYYY format conversion, calculations, and overdue tracking.
 */

/**
 * Parses a date string in DD-MM-YYYY or YYYY-MM-DD or standard Date parseable format.
 */
export function parseDDMMYYYY(dateStr: string): Date | null {
  if (!dateStr) return null;
  
  // Clean string
  const cleanStr = dateStr.trim();

  // Try DD-MM-YYYY or DD/MM/YYYY or DD.MM.YYYY format
  const ddMMyyyyMatch = cleanStr.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$/);
  if (ddMMyyyyMatch) {
    const day = parseInt(ddMMyyyyMatch[1], 10);
    const month = parseInt(ddMMyyyyMatch[2], 10) - 1; // 0-indexed
    const year = parseInt(ddMMyyyyMatch[3], 10);
    const d = new Date(year, month, day);
    if (year < 100) d.setFullYear(year);
    if (!isNaN(d.getTime())) return d;
  }

  // Try YYYY-MM-DD
  const yyyyMMddMatch = cleanStr.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/);
  if (yyyyMMddMatch) {
    const year = parseInt(yyyyMMddMatch[1], 10);
    const month = parseInt(yyyyMMddMatch[2], 10) - 1;
    const day = parseInt(yyyyMMddMatch[3], 10);
    const d = new Date(year, month, day);
    if (year < 100) d.setFullYear(year);
    if (!isNaN(d.getTime())) return d;
  }

  // Fallback to standard JS Date only if string contains date separators or words
  if (/[-/.]/.test(cleanStr) || /[a-zA-Z]/.test(cleanStr)) {
    const parsed = new Date(cleanStr);
    return isNaN(parsed.getTime()) ? null : parsed;
  }

  return null;
}

/**
 * Formats a Date object into DD-MM-YYYY string.
 */
export function formatDDMMYYYY(date: Date): string {
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  return `${day}-${month}-${year}`;
}

/**
 * Formats a Date object into YYYY-MM-DD string for HTML date inputs.
 */
export function formatYYYYMMDD(date: Date): string {
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  return `${year}-${month}-${day}`;
}

/**
 * Converts DD-MM-YYYY string to YYYY-MM-DD for HTML date inputs.
 */
export function ddmmToYyyyMmDd(ddmm: string): string {
  if (!ddmm) return '';
  const clean = ddmm.trim();
  const match = clean.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$/);
  if (match) {
    const day = match[1].padStart(2, '0');
    const month = match[2].padStart(2, '0');
    const year = match[3];
    return `${year}-${month}-${day}`;
  }
  const isoMatch = clean.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/);
  if (isoMatch) {
    const year = isoMatch[1];
    const month = isoMatch[2].padStart(2, '0');
    const day = isoMatch[3].padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
  const d = parseDDMMYYYY(clean);
  return d ? formatYYYYMMDD(d) : '';
}
export const convertDDMMYYYYToYYYYMMDD = ddmmToYyyyMmDd;

/**
 * Converts YYYY-MM-DD or standard date input string to DD-MM-YYYY.
 */
export function yyyymmddToDdMmYyyy(yyyyMmDd: string): string {
  if (!yyyyMmDd) return '';
  const clean = yyyyMmDd.trim();
  const isoMatch = clean.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/);
  if (isoMatch) {
    const year = isoMatch[1];
    const month = isoMatch[2].padStart(2, '0');
    const day = isoMatch[3].padStart(2, '0');
    return `${day}-${month}-${year}`;
  }
  const ddmmMatch = clean.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$/);
  if (ddmmMatch) {
    const day = ddmmMatch[1].padStart(2, '0');
    const month = ddmmMatch[2].padStart(2, '0');
    const year = ddmmMatch[3];
    return `${day}-${month}-${year}`;
  }
  const d = parseDDMMYYYY(clean);
  return d ? formatDDMMYYYY(d) : '';
}
export const convertYYYYMMDDToDDMMYYYY = yyyymmddToDdMmYyyy;

/**
 * Calculates current age from a DOB string. Returns null if invalid.
 */
export function calculateAge(dobStr: string): number | null {
  if (!dobStr) return null;
  const d = parseDDMMYYYY(dobStr);
  if (!d) return null;
  const today = new Date();
  let age = today.getFullYear() - d.getFullYear();
  const m = today.getMonth() - d.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < d.getDate())) {
    age--;
  }
  return age >= 0 && age <= 125 ? age : null;
}

/**
 * Normalizes user typed date (e.g. 15051979 or 15/05/1979 or 15-05-1979) into DD-MM-YYYY
 */
export function normalizeDateStringToDDMMYYYY(input: string): string {
  if (!input) return '';
  const clean = input.trim();

  // 8 raw digits: DDMMYYYY
  const rawDigitsMatch = clean.match(/^(\d{2})(\d{2})(\d{4})$/);
  if (rawDigitsMatch) {
    return `${rawDigitsMatch[1]}-${rawDigitsMatch[2]}-${rawDigitsMatch[3]}`;
  }

  // 6 raw digits: DDMMYY (e.g. 150579 -> 15-05-1979)
  const sixDigitsMatch = clean.match(/^(\d{2})(\d{2})(\d{2})$/);
  if (sixDigitsMatch) {
    const yr = parseInt(sixDigitsMatch[3], 10);
    const fullYr = yr > 40 ? 1900 + yr : 2000 + yr;
    return `${sixDigitsMatch[1]}-${sixDigitsMatch[2]}-${fullYr}`;
  }

  // DD/MM/YYYY or DD-MM-YYYY or DD.MM.YYYY
  const ddMMyyyyMatch = clean.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})$/);
  if (ddMMyyyyMatch) {
    const day = ddMMyyyyMatch[1].padStart(2, '0');
    const month = ddMMyyyyMatch[2].padStart(2, '0');
    let year = ddMMyyyyMatch[3];
    if (year.length === 2) {
      const yr = parseInt(year, 10);
      year = String(yr > 40 ? 1900 + yr : 2000 + yr);
    }
    return `${day}-${month}-${year}`;
  }

  // YYYY-MM-DD
  const isoMatch = clean.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/);
  if (isoMatch) {
    const year = isoMatch[1];
    const month = isoMatch[2].padStart(2, '0');
    const day = isoMatch[3].padStart(2, '0');
    return `${day}-${month}-${year}`;
  }

  return clean;
}

/**
 * Calculates Date Due as exactly 14 days after Date Sent.
 */
export function calculateDueDate(dateSentStr: string): string {
  const sentDate = parseDDMMYYYY(dateSentStr) || new Date();
  const dueDate = new Date(sentDate);
  dueDate.setDate(dueDate.getDate() + 14);
  return formatDDMMYYYY(dueDate);
}

/**
 * Calculates Chase-up Date as 7 days before Date Due (or 7 days after Date Sent).
 */
export function calculateChaseUpDate(dateSentStr: string): string {
  const sentDate = parseDDMMYYYY(dateSentStr) || new Date();
  const chaseDate = new Date(sentDate);
  chaseDate.setDate(chaseDate.getDate() + 7);
  return formatDDMMYYYY(chaseDate);
}

/**
 * Calculates Servicing dates based on a start date (DD-MM-YYYY):
 * - Welcome call: 1 week (7 days) after start date
 * - 6-month review: 6 months after start date
 * - 1-year review: 1 year (12 months or +6 months from 6-month review) after start date
 */
export function calculateServicingDates(startDateStr: string) {
  const start = parseDDMMYYYY(startDateStr) || new Date();
  
  // Welcome call: 1 week (7 days)
  const welcomeCallDate = new Date(start);
  welcomeCallDate.setDate(welcomeCallDate.getDate() + 7);

  // 6 month review: 6 months
  const sixMonthDate = new Date(start);
  sixMonthDate.setMonth(sixMonthDate.getMonth() + 6);

  // 1 year review: 1 year (or 6 months after 6 month review)
  const oneYearDate = new Date(start);
  oneYearDate.setFullYear(oneYearDate.getFullYear() + 1);

  return {
    welcomeCallDueDate: formatDDMMYYYY(welcomeCallDate),
    sixMonthReviewDueDate: formatDDMMYYYY(sixMonthDate),
    oneYearReviewDueDate: formatDDMMYYYY(oneYearDate)
  };
}

/**
 * Gets current local date string formatted as DD-MM-YYYY
 */
export function getTodayDDMMYYYY(): string {
  return formatDDMMYYYY(new Date());
}

/**
 * Determines if an LoA is due for chasing or overdue based on target reference date.
 */
export function getLoATimingStatus(dateSentStr: string, dateDueStr: string, chaseUpDateStr: string, currentStatus: string, refDate: Date = new Date()) {
  const dueDate = parseDDMMYYYY(dateDueStr);
  const chaseDate = parseDDMMYYYY(chaseUpDateStr);
  const sentDate = parseDDMMYYYY(dateSentStr);

  const today = new Date(refDate.getFullYear(), refDate.getMonth(), refDate.getDate());

  if (currentStatus === 'Received') {
    return { isOverdue: false, isChaseDue: false, daysRemaining: 0, label: 'Received' };
  }

  let daysRemaining = 0;
  if (dueDate) {
    const dueNormalized = new Date(dueDate.getFullYear(), dueDate.getMonth(), dueDate.getDate());
    const diffTime = dueNormalized.getTime() - today.getTime();
    daysRemaining = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }

  const isOverdue = dueDate ? today > dueDate : false;
  const isChaseDue = chaseDate ? today >= chaseDate && !isOverdue : false;

  return {
    isOverdue,
    isChaseDue,
    daysRemaining,
    label: isOverdue ? 'Overdue' : isChaseDue ? 'Chase Today' : `${daysRemaining} days left`
  };
}

/**
 * Formats date into readable string like "11 Aug 2026"
 */
export function formatPrettyDate(dateStr: string): string {
  const d = parseDDMMYYYY(dateStr);
  if (!d) return dateStr;
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}
