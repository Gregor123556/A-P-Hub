/**
 * Currency and Service Scope formatting utilities for Adams & Poole Financial Services
 */

export type ServiceScope = 'ISA & GIA' | 'CIB' | 'Pension';

/**
 * Normalizes any freeform or legacy service type / account type into one of the 3 official practice scopes:
 * 'ISA & GIA' | 'CIB' | 'Pension'
 */
export function normalizeServiceScope(val?: string | null): ServiceScope {
  if (!val) return 'Pension';
  const trimmed = val.trim();

  if (trimmed === 'ISA & GIA' || trimmed === 'CIB' || trimmed === 'Pension') {
    return trimmed;
  }

  const lower = trimmed.toLowerCase();

  // Check CIB / Bond
  if (
    lower.includes('cib') ||
    lower.includes('bond') ||
    lower.includes('capital investment') ||
    lower.includes('collective investment') ||
    lower.includes('onshore') ||
    lower.includes('offshore')
  ) {
    return 'CIB';
  }

  // Check ISA & GIA / Investment / Wealth
  if (
    lower.includes('isa') ||
    lower.includes('gia') ||
    lower.includes('invest') ||
    lower.includes('wealth') ||
    lower.includes('general investment') ||
    lower.includes('share') ||
    lower.includes('stock') ||
    lower.includes('fund')
  ) {
    return 'ISA & GIA';
  }

  // Check Pension / SIPP / Retirement
  if (
    lower.includes('pension') ||
    lower.includes('sipp') ||
    lower.includes('retire') ||
    lower.includes('drawdown') ||
    lower.includes('annuity') ||
    lower.includes('ppp')
  ) {
    return 'Pension';
  }

  return 'Pension';
}

/**
 * Formats any string or numeric value into UK Pound Sterling (£)
 * Examples:
 *   520000 -> "£520,000"
 *   "520000" -> "£520,000"
 *   "£520000" -> "£520,000"
 *   "520k" / "520K" -> "£520,000"
 *   "1.2m" / "1.2M" -> "£1,200,000"
 *   "450,000" -> "£450,000"
 */
export function formatPoundSterling(val?: string | number | null): string {
  if (val === undefined || val === null) return '';
  const raw = val.toString().trim();
  if (!raw || raw === '—' || raw === '-') return '';

  const lower = raw.toLowerCase().trim();

  // Shorthand with 'm' (millions)
  if (lower.endsWith('m')) {
    const numPart = parseFloat(lower.replace(/[^0-9.]/g, ''));
    if (!isNaN(numPart)) {
      const formatted = Math.round(numPart * 1_000_000).toLocaleString('en-GB');
      return `£${formatted}`;
    }
  }

  // Shorthand with 'k' (thousands)
  if (lower.endsWith('k')) {
    const numPart = parseFloat(lower.replace(/[^0-9.]/g, ''));
    if (!isNaN(numPart)) {
      const formatted = Math.round(numPart * 1_000).toLocaleString('en-GB');
      return `£${formatted}`;
    }
  }

  // General number parsing
  const numericPart = raw.replace(/[^0-9.]/g, '');
  if (!numericPart) {
    return raw.startsWith('£') ? raw : `£${raw}`;
  }

  const num = parseFloat(numericPart);
  if (isNaN(num)) return raw;

  const formattedNum = num % 1 === 0
    ? num.toLocaleString('en-GB')
    : num.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  return `£${formattedNum}`;
}

/**
 * Parses any Pound Sterling string into a numeric value for calculations and sorting.
 */
export function parsePoundValue(val?: string | number | null): number {
  if (val === undefined || val === null) return 0;
  const raw = val.toString().trim().toLowerCase();
  if (!raw || raw === '—' || raw === '-') return 0;

  if (raw.endsWith('m')) {
    const num = parseFloat(raw.replace(/[^0-9.]/g, ''));
    return isNaN(num) ? 0 : num * 1_000_000;
  }

  if (raw.endsWith('k')) {
    const num = parseFloat(raw.replace(/[^0-9.]/g, ''));
    return isNaN(num) ? 0 : num * 1_000;
  }

  const num = parseFloat(raw.replace(/[^0-9.]/g, ''));
  return isNaN(num) ? 0 : num;
}
