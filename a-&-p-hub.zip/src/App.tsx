import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { LoATable } from './components/LoATable';
import { LoAFormModal } from './components/LoAFormModal';
import { ChaseLetterModal } from './components/ChaseLetterModal';
import { ProviderDirectory } from './components/ProviderDirectory';
import { ClientAdminDashboard } from './components/ClientAdmin/ClientAdminDashboard';
import { ServicingDashboard } from './components/ServicingDashboard';
import { MarkdownExportModal } from './components/MarkdownExportModal';
import { LoAEntry, LoAStatus, ProviderContact, ClientAdminEntry, ServicingClient } from './types';
import { 
  subscribeToLoAs, 
  createLoA, 
  updateLoA, 
  deleteLoA, 
  resetLoAsToInitial,
  initializeFirestoreIfEmpty
} from './services/loaService';
import {
  subscribeToProviders,
  getStoredProviders,
  initializeProvidersIfEmpty
} from './services/providerService';
import {
  subscribeToClientAdmin,
  getStoredClients,
  initializeClientAdminIfEmpty
} from './services/clientAdminService';
import {
  subscribeToServicingClients,
  getStoredServicingClients,
  initializeServicingIfEmpty
} from './services/servicingService';
import { 
  Plus, 
  FileSpreadsheet, 
  AlertCircle, 
  Menu, 
  X, 
  Cloud, 
  RefreshCw 
} from 'lucide-react';
import { AdamsPooleLogo } from './components/AdamsPooleLogo';

export default function App() {
  const [loas, setLoas] = useState<LoAEntry[]>([]);
  const [providers, setProviders] = useState<ProviderContact[]>(() => getStoredProviders());
  const [clients, setClients] = useState<ClientAdminEntry[]>(() => getStoredClients());
  const [servicingClients, setServicingClients] = useState<ServicingClient[]>(() => getStoredServicingClients());
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [syncStatus, setSyncStatus] = useState<'synced' | 'saving' | 'error'>('synced');
  const [activeTab, setActiveTab] = useState<'tracker' | 'analytics' | 'clientAdmin' | 'servicing'>('clientAdmin');
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<LoAEntry | null>(null);
  const [chaseModalEntry, setChaseModalEntry] = useState<LoAEntry | null>(null);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Subscribe to real-time Firestore updates across all team members
  useEffect(() => {
    setIsLoading(true);
    // Initialize if needed
    initializeFirestoreIfEmpty();
    initializeProvidersIfEmpty();
    initializeClientAdminIfEmpty();
    initializeServicingIfEmpty();

    const unsubscribeLoas = subscribeToLoAs(
      (updatedLoas) => {
        setLoas(updatedLoas);
        setIsLoading(false);
        setSyncStatus('synced');
      },
      (error) => {
        console.error('Real-time sync error:', error);
        setIsLoading(false);
        setSyncStatus('error');
      }
    );

    const unsubscribeProviders = subscribeToProviders(
      (updatedProviders) => {
        setProviders(updatedProviders);
      },
      (error) => {
        console.error('Provider sync error:', error);
      }
    );

    const unsubscribeClients = subscribeToClientAdmin(
      (updatedClients) => {
        setClients(updatedClients);
      },
      (error) => {
        console.error('Client admin sync error:', error);
      }
    );

    const unsubscribeServicing = subscribeToServicingClients(
      (updatedServicing) => {
        setServicingClients(updatedServicing);
      },
      (error) => {
        console.error('Servicing clients sync error:', error);
      }
    );

    return () => {
      unsubscribeLoas();
      unsubscribeProviders();
      unsubscribeClients();
      unsubscribeServicing();
    };
  }, []);

  // Handler for saving/editing an existing LoA record
  const handleSaveFormModal = async (data: Omit<LoAEntry, 'id' | 'createdAt'>, existingId?: string) => {
    try {
      setSyncStatus('saving');
      if (existingId) {
        await updateLoA(existingId, data);
      } else {
        await createLoA(data);
      }
      setSyncStatus('synced');
    } catch (err: any) {
      console.error('Error saving LoA from modal:', err);
      setSyncStatus('error');
    }
  };

  // Handler for updating status of a specific LoA by ID
  const handleUpdateStatusById = async (id: string, newStatus: LoAStatus) => {
    try {
      setSyncStatus('saving');
      await updateLoA(id, { status: newStatus });
      setSyncStatus('synced');
    } catch (err) {
      console.error('Failed to update LoA status in Firestore:', err);
      setSyncStatus('error');
    }
  };

  // Handler for deleting an LoA
  const handleDeleteLoA = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this Letter of Authority record across the practice?')) {
      try {
        setSyncStatus('saving');
        await deleteLoA(id);
        setSyncStatus('synced');
      } catch (err) {
        console.error('Failed to delete LoA in Firestore:', err);
        setSyncStatus('error');
        alert('Failed to delete record from cloud database.');
      }
    }
  };

  // Handler for logging last chased date
  const handleLogChase = async (id: string, dateChased: string) => {
    try {
      setSyncStatus('saving');
      await updateLoA(id, { 
        lastChasedDate: dateChased,
        status: 'Overdue + Chased' 
      });
      setSyncStatus('synced');
    } catch (err) {
      console.error('Failed to log chase date:', err);
      setSyncStatus('error');
    }
  };

  // Reset demo data in Firestore
  const handleResetData = async () => {
    if (window.confirm('Reset cloud database to default Adams & Poole practice demo entries for all users?')) {
      try {
        setSyncStatus('saving');
        await resetLoAsToInitial();
        setSyncStatus('synced');
      } catch (err) {
        console.error('Failed to reset cloud data:', err);
        setSyncStatus('error');
        alert('Failed to reset cloud database.');
      }
    }
  };

  const overdueCount = loas.filter(l => l.status === 'Overdue').length;
  const overdueChasedCount = loas.filter(l => l.status === 'Overdue + Chased').length;
  const receivedCount = loas.filter(l => l.status === 'Received').length;
  const activeCount = loas.filter(l => l.status === 'Pending' || l.status === 'Overdue' || l.status === 'Overdue + Chased').length;

  return (
    <div className="flex h-screen w-screen bg-slate-50 font-sans text-slate-900 overflow-hidden">
      
      {/* Desktop Sidebar */}
      <div className="hidden md:block shrink-0 h-full">
        <Sidebar
          loas={loas}
          clientAdminCount={clients.length}
          servicingCount={servicingClients.length}
          activeTab={activeTab}
          setActiveTab={(tab) => setActiveTab(tab)}
          onOpenNewModal={() => {
            setEditingEntry(null);
            setIsFormModalOpen(true);
          }}
          onOpenExportModal={() => setIsExportModalOpen(true)}
        />
      </div>

      {/* Mobile Drawer Overlay */}
      {isMobileSidebarOpen && (
        <div className="fixed inset-0 z-50 flex md:hidden">
          <div 
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm"
            onClick={() => setIsMobileSidebarOpen(false)}
          />
          <div className="relative flex-1 max-w-xs w-full bg-slate-900 h-full z-10">
            <button
              onClick={() => setIsMobileSidebarOpen(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
            <Sidebar
              loas={loas}
              clientAdminCount={clients.length}
              servicingCount={servicingClients.length}
              activeTab={activeTab}
              setActiveTab={(tab) => {
                setActiveTab(tab);
                setIsMobileSidebarOpen(false);
              }}
              onOpenNewModal={() => {
                setEditingEntry(null);
                setIsFormModalOpen(true);
                setIsMobileSidebarOpen(false);
              }}
              onOpenExportModal={() => {
                setIsExportModalOpen(true);
                setIsMobileSidebarOpen(false);
              }}
            />
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col p-4 sm:p-6 lg:p-8 overflow-y-auto bg-slate-50 text-slate-900">
        
        {/* Mobile Header Bar */}
        <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-200 md:hidden">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsMobileSidebarOpen(true)}
              className="p-2 text-slate-700 hover:bg-slate-200 rounded-lg"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <AdamsPooleLogo size={28} />
              <span className="font-bold text-slate-900 text-sm">Adams &amp; Poole</span>
            </div>
          </div>
          {activeTab === 'tracker' && (
            <button
              onClick={() => {
                setEditingEntry(null);
                setIsFormModalOpen(true);
              }}
              className="px-3 py-1.5 bg-blue-600 text-white text-xs font-medium rounded-lg"
            >
              + New LoA
            </button>
          )}
        </div>

        {/* Top Header Section */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold tracking-tight text-slate-900">
                {activeTab === 'servicing'
                  ? 'Ongoing Client Servicing & Reviews'
                  : activeTab === 'clientAdmin' 
                  ? 'Client Administration Pipeline'
                  : activeTab === 'analytics' 
                  ? 'Provider Directory' 
                  : 'Letters of Authority Tracker'}
              </h1>
              {/* Real-Time Cloud Sync Badge */}
              <div 
                className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200 shadow-2xs"
                title="Shared live database synced across all team members"
              >
                {syncStatus === 'saving' ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 text-blue-600 animate-spin" />
                    <span>Syncing...</span>
                  </>
                ) : syncStatus === 'error' ? (
                  <>
                    <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                    <span className="text-rose-700">Sync Error</span>
                  </>
                ) : (
                  <>
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                    </span>
                    <Cloud className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Live Team Sync Active</span>
                  </>
                )}
              </div>
            </div>
            <p className="text-sm text-slate-500 mt-1">
              {activeTab === 'servicing'
                ? 'Track completed onboarding clients, welcome email dispatch, welcome calls (+1 week), 6-month review dates, and 1-year annual reviews.'
                : activeTab === 'clientAdmin'
                ? 'Track administrative onboarding, compliance milestones, and progress tracking across Potential, Ongoing, and On Hold clients.'
                : activeTab === 'analytics'
                ? 'Verified UK provider directory, mailing addresses, dedicated paraplanning contact desks, and dispatch methods.'
                : 'Shared multi-user LoA pipeline for Adams & Poole Financial Services. All additions and edits reflect live across all team members.'}
            </p>
          </div>

          {activeTab === 'tracker' && (
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setIsExportModalOpen(true)}
                className="px-4 py-2 bg-white border border-slate-200 text-slate-700 font-medium text-xs sm:text-sm rounded-lg shadow-2xs hover:bg-slate-50 transition flex items-center gap-2"
              >
                <FileSpreadsheet className="w-4 h-4 text-blue-600" />
                <span>Export Report</span>
              </button>

              <button
                onClick={() => {
                  setEditingEntry(null);
                  setIsFormModalOpen(true);
                }}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium text-xs sm:text-sm rounded-lg shadow-2xs transition flex items-center space-x-2"
              >
                <Plus className="w-4 h-4" />
                <span>+ New LoA Entry</span>
              </button>
            </div>
          )}
        </div>

        {/* 4 Stat Metric Cards (shown on LoA Tracker dashboard) */}
        {activeTab === 'tracker' && (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-8">
            <div className="bg-white p-5 sm:p-6 rounded-xl border border-slate-200 shadow-2xs">
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Active Requests</p>
              <p className="text-3xl font-bold mt-2 text-slate-900">{activeCount}</p>
            </div>

            <div className="bg-white p-5 sm:p-6 rounded-xl border border-slate-200 shadow-2xs border-l-4 border-l-amber-500">
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Overdue Items</p>
              <p className="text-3xl font-bold mt-2 text-amber-600">{overdueCount}</p>
            </div>

            <div className="bg-white p-5 sm:p-6 rounded-xl border border-slate-200 shadow-2xs border-l-4 border-l-red-500">
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Overdue + Chased</p>
              <p className="text-3xl font-bold mt-2 text-red-600">{overdueChasedCount}</p>
            </div>

            <div className="bg-white p-5 sm:p-6 rounded-xl border border-slate-200 shadow-2xs border-l-4 border-l-green-500">
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Received (MTD)</p>
              <p className="text-3xl font-bold mt-2 text-green-600">{receivedCount}</p>
            </div>
          </div>
        )}

        {/* Main Tab Content */}
        <div className="flex-1 space-y-6">
          {isLoading ? (
            <div className="bg-white border border-slate-200 rounded-xl p-12 flex flex-col items-center justify-center text-center shadow-2xs">
              <RefreshCw className="w-8 h-8 text-blue-600 animate-spin mb-3" />
              <h3 className="text-base font-semibold text-slate-800">Connecting to Live Team Cloud Database...</h3>
              <p className="text-xs text-slate-500 mt-1">Synchronizing LoA records across practice members in real time.</p>
            </div>
          ) : activeTab === 'servicing' ? (
            <ServicingDashboard
              servicingClients={servicingClients}
              onNavigateToClientAdmin={() => setActiveTab('clientAdmin')}
            />
          ) : activeTab === 'clientAdmin' ? (
            <ClientAdminDashboard 
              clients={clients} 
              loas={loas} 
            />
          ) : activeTab === 'analytics' ? (
            <ProviderDirectory 
              loas={loas} 
              providers={providers} 
            />
          ) : (
            /* Default Master Tracker */
            <div className="space-y-6">
              <LoATable
                loas={loas}
                onUpdateStatus={handleUpdateStatusById}
                onEdit={(entry) => {
                  setEditingEntry(entry);
                  setIsFormModalOpen(true);
                }}
                onDelete={handleDeleteLoA}
                onGenerateChase={(entry) => setChaseModalEntry(entry)}
              />
            </div>
          )}
        </div>

        {/* Footer */}
        <footer className="mt-8 pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
          <div className="flex items-center gap-2">
            <AdamsPooleLogo size={20} />
            <span>Adams &amp; Poole Financial Services • LoA Tracking Hub</span>
          </div>
          <button
            onClick={handleResetData}
            className="text-slate-400 hover:text-slate-600 underline text-[11px]"
          >
            Reset Seed Data
          </button>
        </footer>

      </main>

      {/* Modals */}
      <LoAFormModal
        isOpen={isFormModalOpen}
        onClose={() => {
          setIsFormModalOpen(false);
          setEditingEntry(null);
        }}
        onSubmit={handleSaveFormModal}
        editingEntry={editingEntry}
        providers={providers}
      />

      <ChaseLetterModal
        entry={chaseModalEntry}
        isOpen={!!chaseModalEntry}
        onClose={() => setChaseModalEntry(null)}
        onLoggedChase={handleLogChase}
      />

      <MarkdownExportModal
        loas={loas}
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
      />

    </div>
  );
}
