import React, { useState, useEffect } from 'react';
import { X, Building2, Mail, Phone, MapPin, Send, Clock, FileText } from 'lucide-react';
import { ProviderContact, SubmissionMethod } from '../types';

interface ProviderFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (provider: Omit<ProviderContact, 'id'>, existingId?: string) => void;
  editingProvider?: ProviderContact | null;
}

export const ProviderFormModal: React.FC<ProviderFormModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  editingProvider
}) => {
  const [name, setName] = useState('');
  const [mailingAddress, setMailingAddress] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [bestSubmissionMethod, setBestSubmissionMethod] = useState<SubmissionMethod>('unipass');
  const [avgTurnaroundDays, setAvgTurnaroundDays] = useState<number>(14);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (editingProvider) {
      setName(editingProvider.name);
      setMailingAddress(editingProvider.mailingAddress);
      setEmail(editingProvider.email);
      setPhone(editingProvider.phone);
      setBestSubmissionMethod(editingProvider.bestSubmissionMethod);
      setAvgTurnaroundDays(editingProvider.avgTurnaroundDays || 14);
      setNotes(editingProvider.notes || '');
    } else {
      setName('');
      setMailingAddress('');
      setEmail('');
      setPhone('');
      setBestSubmissionMethod('unipass');
      setAvgTurnaroundDays(14);
      setNotes('');
    }
  }, [editingProvider, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onSubmit(
      {
        name: name.trim(),
        mailingAddress: mailingAddress.trim(),
        email: email.trim(),
        phone: phone.trim(),
        bestSubmissionMethod,
        avgTurnaroundDays: Number(avgTurnaroundDays) || 14,
        notes: notes.trim()
      },
      editingProvider?.id
    );

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-lg w-full max-h-[90vh] flex flex-col shadow-2xl relative overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header - Light clean styling matching LoA Tracker modals */}
        <div className="flex items-center justify-between border-b border-slate-200 p-5 sm:p-6 bg-white shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-50 border border-blue-100 rounded-lg text-blue-600 shrink-0">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                {editingProvider ? 'Edit Provider Contact' : 'Add New UK Provider'}
              </h3>
              <p className="text-xs text-slate-500">
                Provider directory &amp; LoA dispatch configuration
              </p>
            </div>
          </div>
          
          {/* Explicit Top-Right Exit Button */}
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition"
            title="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body - Comfortable spacing and scrollable */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4 overflow-y-auto flex-1">
          
          {/* Provider Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Provider Name <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <Building2 className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                required
                placeholder="e.g. Royal London, Aviva, Transact..."
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white transition font-medium"
              />
            </div>
          </div>

          {/* Mailing Address */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Mailing Address <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <MapPin className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <textarea
                required
                rows={2}
                placeholder="Full UK servicing postal address & postcode..."
                value={mailingAddress}
                onChange={(e) => setMailingAddress(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white transition"
              />
            </div>
          </div>

          {/* Email & Phone Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="email"
                  placeholder="loa@provider.co.uk"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white transition font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Telephone Number
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="0800 000 0000"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white transition font-mono"
                />
              </div>
            </div>
          </div>

          {/* Best Submission Method (Interactive Choice: Unipass, Post, Email) */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Best Submission Method <span className="text-rose-500">*</span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setBestSubmissionMethod('unipass')}
                className={`py-2 px-3 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1.5 transition ${
                  bestSubmissionMethod === 'unipass'
                    ? 'bg-purple-50 border-purple-500 text-purple-700 ring-2 ring-purple-500/20'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <span>⚡</span>
                <span>Unipass</span>
              </button>

              <button
                type="button"
                onClick={() => setBestSubmissionMethod('post')}
                className={`py-2 px-3 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1.5 transition ${
                  bestSubmissionMethod === 'post'
                    ? 'bg-amber-50 border-amber-500 text-amber-700 ring-2 ring-amber-500/20'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <span>✉️</span>
                <span>Post</span>
              </button>

              <button
                type="button"
                onClick={() => setBestSubmissionMethod('email')}
                className={`py-2 px-3 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1.5 transition ${
                  bestSubmissionMethod === 'email'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-700 ring-2 ring-emerald-500/20'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <span>📧</span>
                <span>Email</span>
              </button>
            </div>
          </div>

          {/* Avg SLA (Days) */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Average Turnaround SLA (Working Days)
            </label>
            <div className="relative">
              <Clock className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="number"
                min="1"
                max="60"
                value={avgTurnaroundDays}
                onChange={(e) => setAvgTurnaroundDays(Number(e.target.value))}
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white transition"
              />
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Paraplanning Notes / Specific Requirements
            </label>
            <div className="relative">
              <FileText className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                placeholder="e.g. Unipass Mailock integration, DocuSign accepted..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white transition"
              />
            </div>
          </div>

          {/* Action Buttons Footer */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-xs rounded-lg transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium text-xs rounded-lg shadow-sm transition"
            >
              {editingProvider ? 'Save Changes' : 'Add Provider'}
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
