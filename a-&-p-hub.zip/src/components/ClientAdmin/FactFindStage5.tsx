import React from 'react';
import { 
  Coins, 
  TrendingUp, 
  Landmark, 
  Receipt, 
  Gift, 
  PoundSterling, 
  AlertCircle, 
  Info,
  SlidersHorizontal,
  Plus,
  Trash2,
  Calendar,
  User,
  Users
} from 'lucide-react';
import { FactFindYesNoQuestion, FactFindGiftItem } from '../../types';

export const DEFAULT_1_GIFT_ROW: FactFindGiftItem = {
  id: 'gift-1',
  recipient: '',
  dateGifted: '',
  amountGifted: ''
};

export interface Stage5CapacityState {
  availableLumpSum: FactFindYesNoQuestion;
  availableMonthlyInvestment: FactFindYesNoQuestion;
  isaAllowanceUsed: FactFindYesNoQuestion;
  cgtAllowanceUsed: FactFindYesNoQuestion;
  giftAllowanceUsed: FactFindYesNoQuestion;
  gifts?: FactFindGiftItem[];
}

export const DEFAULT_STAGE5_CAPACITY: Stage5CapacityState = {
  availableLumpSum: { answered: '', details: '' },
  availableMonthlyInvestment: { answered: '', details: '' },
  isaAllowanceUsed: { answered: '', details: '' },
  cgtAllowanceUsed: { answered: '', details: '' },
  giftAllowanceUsed: { answered: '', details: '' },
  gifts: [DEFAULT_1_GIFT_ROW]
};

export interface FactFindStage5Props {
  c1State?: Stage5CapacityState;
  onChangeC1State?: (updater: (prev: Stage5CapacityState) => Stage5CapacityState) => void;
  c2State?: Stage5CapacityState;
  onChangeC2State?: (updater: (prev: Stage5CapacityState) => Stage5CapacityState) => void;
  data?: Stage5CapacityState;
  onChangeData?: (data: Stage5CapacityState) => void;
  setData?: React.Dispatch<React.SetStateAction<Stage5CapacityState>> | ((data: Stage5CapacityState) => void);
  fieldErrors?: Record<string, boolean>;
  onClearFieldError?: (key: string) => void;
  c1FullName?: string;
  c2FullName?: string;
  client1Name?: string;
  client2Name?: string;
  hasSecondClient?: boolean;
  adviser?: string;
  adviserName?: string;
  onBackToStage4?: () => void;
  onSubmit: (e: React.FormEvent) => void;
}

interface CapacityQuestionConfig {
  key: keyof Omit<Stage5CapacityState, 'gifts'>;
  label: string;
  question: string;
  icon: React.ComponentType<{ className?: string }>;
  placeholder: string;
  inputLabel: string;
}

const CAPACITY_QUESTIONS: CapacityQuestionConfig[] = [
  {
    key: 'availableLumpSum',
    label: 'Available Lump Sum to Invest?',
    question: 'Lump sum capital available to invest or restructure',
    icon: Coins,
    placeholder: '£50,000',
    inputLabel: 'Available Lump Sum Amount (£)'
  },
  {
    key: 'availableMonthlyInvestment',
    label: 'Available Monthly Investment Capacity?',
    question: 'Surplus regular monthly income available to invest',
    icon: TrendingUp,
    placeholder: '£1,000',
    inputLabel: 'Monthly Investment Capacity (£ / month)'
  },
  {
    key: 'isaAllowanceUsed',
    label: 'ISA Allowance Used?',
    question: 'Annual ISA subscription allowance utilized (£20,000 max)',
    icon: Landmark,
    placeholder: '£20,000',
    inputLabel: 'ISA Allowance Amount Used (£)'
  },
  {
    key: 'cgtAllowanceUsed',
    label: 'CGT Allowance Used?',
    question: 'Annual Capital Gains Tax exemption utilized',
    icon: Receipt,
    placeholder: '£3,000',
    inputLabel: 'Capital Gains Tax Exemption Used (£)'
  },
  {
    key: 'giftAllowanceUsed',
    label: 'Gift Allowance Used?',
    question: 'Annual inheritance tax gift exemption utilized (£3,000/yr)',
    icon: Gift,
    placeholder: '£3,000',
    inputLabel: 'Annual Gift Exemption Used (£)'
  }
];

export const FactFindStage5: React.FC<FactFindStage5Props> = ({
  c1State,
  onChangeC1State,
  c2State,
  onChangeC2State,
  data,
  onChangeData,
  setData,
  fieldErrors = {},
  onClearFieldError,
  c1FullName,
  c2FullName,
  client1Name,
  client2Name,
  hasSecondClient,
  adviser,
  adviserName,
  onSubmit
}) => {
  const client1DisplayName = c1FullName?.trim() || client1Name?.trim() || 'Client 1 (Primary Client)';
  const client2DisplayName = c2FullName?.trim() || client2Name?.trim() || 'Client 2 (Partner / Spouse)';
  const leadAdviser = adviser || adviserName || 'Lead Adviser';
  const isJoint = hasSecondClient !== undefined ? hasSecondClient : Boolean(c2FullName || client2Name);

  // Resolved states for Client 1 and Client 2
  const activeC1State: Stage5CapacityState = c1State || data || DEFAULT_STAGE5_CAPACITY;
  const activeC2State: Stage5CapacityState = c2State || DEFAULT_STAGE5_CAPACITY;

  const updateC1 = (updater: (prev: Stage5CapacityState) => Stage5CapacityState) => {
    if (typeof onChangeC1State === 'function') {
      onChangeC1State(updater);
    } else {
      const next = updater(activeC1State);
      if (typeof onChangeData === 'function') onChangeData(next);
      if (typeof setData === 'function') setData(next);
    }
  };

  const updateC2 = (updater: (prev: Stage5CapacityState) => Stage5CapacityState) => {
    if (typeof onChangeC2State === 'function') {
      onChangeC2State(updater);
    }
  };

  const calculateTotalGifted = (gifts: FactFindGiftItem[]): number => {
    return gifts.reduce((sum, g) => {
      if (!g.amountGifted) return sum;
      const num = parseFloat(g.amountGifted.replace(/[^0-9.]/g, ''));
      return isNaN(num) ? sum : sum + num;
    }, 0);
  };

  // Generic handler for question updates
  const handleUpdateQuestion = (
    clientPrefix: 'c1' | 'c2',
    key: keyof Omit<Stage5CapacityState, 'gifts'>,
    update: Partial<FactFindYesNoQuestion>
  ) => {
    const isC1 = clientPrefix === 'c1';
    const state = isC1 ? activeC1State : activeC2State;
    const updateFn = isC1 ? updateC1 : updateC2;

    const current = state[key] || { answered: '', details: '' };
    const updatedQuestion: FactFindYesNoQuestion = {
      ...current,
      ...update
    };

    let nextGifts = state.gifts;
    if (key === 'giftAllowanceUsed') {
      if (update.answered === 'yes' && (!state.gifts || state.gifts.length === 0)) {
        nextGifts = [DEFAULT_1_GIFT_ROW];
      }
    }

    updateFn(prev => ({
      ...prev,
      [key]: updatedQuestion,
      gifts: nextGifts
    }));

    const errorKey1 = `${clientPrefix}-${key}`;
    const errorKey2 = key;
    if (onClearFieldError) {
      if (updatedQuestion.answered === 'no' || (updatedQuestion.details && updatedQuestion.details.trim())) {
        onClearFieldError(errorKey1);
        onClearFieldError(errorKey2);
      }
    }
  };

  const formatCurrencyOnBlur = (
    clientPrefix: 'c1' | 'c2',
    key: keyof Omit<Stage5CapacityState, 'gifts'>,
    rawVal: string
  ) => {
    if (!rawVal) return;
    const clean = rawVal.replace(/[^0-9.]/g, '');
    const num = parseFloat(clean);
    if (!isNaN(num)) {
      const formatted = `£${Math.round(num).toLocaleString('en-GB')}`;
      handleUpdateQuestion(clientPrefix, key, { details: formatted });
    }
  };

  // Gift handlers for a specific client
  const handleAddGift = (clientPrefix: 'c1' | 'c2') => {
    const isC1 = clientPrefix === 'c1';
    const state = isC1 ? activeC1State : activeC2State;
    const updateFn = isC1 ? updateC1 : updateC2;
    const currentGifts = state.gifts && state.gifts.length > 0 ? state.gifts : [DEFAULT_1_GIFT_ROW];

    if (currentGifts.length >= 5) return;
    const newGift: FactFindGiftItem = {
      id: `gift-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      recipient: '',
      dateGifted: '',
      amountGifted: ''
    };
    const updatedGifts = [...currentGifts, newGift];
    const totalAmount = calculateTotalGifted(updatedGifts);
    const formattedTotal = totalAmount > 0 ? `£${Math.round(totalAmount).toLocaleString('en-GB')}` : state.giftAllowanceUsed.details;

    updateFn(prev => ({
      ...prev,
      giftAllowanceUsed: {
        ...prev.giftAllowanceUsed,
        answered: 'yes',
        details: formattedTotal
      },
      gifts: updatedGifts
    }));
  };

  const handleRemoveGift = (clientPrefix: 'c1' | 'c2', index: number) => {
    const isC1 = clientPrefix === 'c1';
    const state = isC1 ? activeC1State : activeC2State;
    const updateFn = isC1 ? updateC1 : updateC2;
    const currentGifts = state.gifts && state.gifts.length > 0 ? state.gifts : [DEFAULT_1_GIFT_ROW];

    let updatedGifts: FactFindGiftItem[];
    if (currentGifts.length <= 1) {
      updatedGifts = [{
        id: `gift-${Date.now()}`,
        recipient: '',
        dateGifted: '',
        amountGifted: ''
      }];
    } else {
      updatedGifts = currentGifts.filter((_, i) => i !== index);
    }

    const totalAmount = calculateTotalGifted(updatedGifts);
    const formattedTotal = totalAmount > 0 ? `£${Math.round(totalAmount).toLocaleString('en-GB')}` : '';

    updateFn(prev => ({
      ...prev,
      giftAllowanceUsed: {
        ...prev.giftAllowanceUsed,
        answered: 'yes',
        details: formattedTotal
      },
      gifts: updatedGifts
    }));
  };

  const handleUpdateGift = (
    clientPrefix: 'c1' | 'c2',
    index: number,
    updates: Partial<FactFindGiftItem>
  ) => {
    const isC1 = clientPrefix === 'c1';
    const state = isC1 ? activeC1State : activeC2State;
    const updateFn = isC1 ? updateC1 : updateC2;
    const currentGifts = state.gifts && state.gifts.length > 0 ? state.gifts : [DEFAULT_1_GIFT_ROW];

    const updatedGifts = [...currentGifts];
    updatedGifts[index] = {
      ...updatedGifts[index],
      ...updates
    };

    const totalAmount = calculateTotalGifted(updatedGifts);
    const formattedTotal = totalAmount > 0 ? `£${Math.round(totalAmount).toLocaleString('en-GB')}` : state.giftAllowanceUsed.details;

    updateFn(prev => ({
      ...prev,
      giftAllowanceUsed: {
        ...prev.giftAllowanceUsed,
        answered: 'yes',
        details: formattedTotal
      },
      gifts: updatedGifts
    }));

    if (onClearFieldError) {
      if (updates.recipient) {
        onClearFieldError(`${clientPrefix}-gift-recipient-${index}`);
        onClearFieldError(`gift-recipient-${index}`);
      }
      if (updates.amountGifted) {
        onClearFieldError(`${clientPrefix}-gift-amount-${index}`);
        onClearFieldError(`gift-amount-${index}`);
      }
    }
  };

  const formatGiftAmountOnBlur = (clientPrefix: 'c1' | 'c2', index: number, rawVal: string) => {
    if (!rawVal || !rawVal.trim()) return;
    const cleanNum = rawVal.replace(/[^0-9.]/g, '');
    const num = parseFloat(cleanNum);
    if (!isNaN(num)) {
      const formatted = `£${Math.round(num).toLocaleString('en-GB')}`;
      handleUpdateGift(clientPrefix, index, { amountGifted: formatted });
    }
  };

  // Render an individual question card for a specific client
  const renderQuestionCard = (
    item: CapacityQuestionConfig,
    clientPrefix: 'c1' | 'c2',
    clientState: Stage5CapacityState,
    themeColor: 'blue' | 'indigo'
  ) => {
    const errorKey1 = `${clientPrefix}-${item.key}`;
    const errorKey2 = item.key;
    const hasError = Boolean(fieldErrors[errorKey1] || fieldErrors[errorKey2]);
    const currentQuestion = clientState[item.key] || { answered: '', details: '' };
    const isYes = currentQuestion.answered === 'yes';
    const isNo = currentQuestion.answered === 'no';
    const IconComponent = item.icon;
    const isGiftAllowance = item.key === 'giftAllowanceUsed';
    const isIndigo = themeColor === 'indigo';

    const currentGifts = clientState.gifts && clientState.gifts.length > 0
      ? clientState.gifts
      : [DEFAULT_1_GIFT_ROW];
    const totalGiftedValue = calculateTotalGifted(currentGifts);

    const activeYesBg = isIndigo 
      ? 'bg-indigo-600 border-indigo-600 text-white shadow-xs' 
      : 'bg-blue-600 border-blue-600 text-white shadow-xs';
    
    const iconAccentBg = isYes
      ? (isIndigo ? 'bg-indigo-100 text-indigo-700' : 'bg-blue-100 text-blue-700')
      : 'bg-slate-100 text-slate-600';

    return (
      <div
        key={`${clientPrefix}-${item.key}`}
        id={`stage5-${clientPrefix}-${item.key}`}
        className={`rounded-xl border transition-all p-4 bg-white ${
          hasError
            ? 'border-rose-400 bg-rose-50/20 ring-2 ring-rose-400/20'
            : isYes
            ? (isIndigo ? 'border-indigo-200 bg-indigo-50/15 shadow-xs' : 'border-blue-200 bg-blue-50/20 shadow-xs')
            : 'border-slate-200 hover:border-slate-300'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          
          {/* Question title and description */}
          <div className="flex items-start gap-3 flex-1">
            <div className={`p-2 rounded-lg shrink-0 mt-0.5 ${iconAccentBg}`}>
              <IconComponent className="w-4 h-4" />
            </div>

            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-900">
                  {item.label}
                </span>
                {isYes && (
                  <span className={`px-2 py-0.2 rounded-full text-[10px] font-bold uppercase tracking-wide border ${
                    isIndigo 
                      ? 'bg-indigo-100 text-indigo-800 border-indigo-200' 
                      : 'bg-amber-100 text-amber-800 border-amber-200'
                  }`}>
                    {isGiftAllowance ? 'Gift Schedule' : 'Value Required'}
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-600 leading-snug">
                {item.question}
              </p>
            </div>
          </div>

          {/* Yes / No Choice Buttons */}
          <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
            {/* Yes Button */}
            <button
              type="button"
              id={`${clientPrefix}-${item.key}-yes-btn`}
              onClick={() => {
                handleUpdateQuestion(clientPrefix, item.key, {
                  answered: 'yes'
                });
              }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
                isYes
                  ? activeYesBg
                  : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <div className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                isYes ? 'border-white bg-white' : 'border-slate-400'
              }`}>
                {isYes && (
                  <div className={`w-1.5 h-1.5 rounded-full ${isIndigo ? 'bg-indigo-600' : 'bg-blue-600'}`} />
                )}
              </div>
              <span>Yes</span>
            </button>

            {/* No Button */}
            <button
              type="button"
              id={`${clientPrefix}-${item.key}-no-btn`}
              onClick={() => {
                handleUpdateQuestion(clientPrefix, item.key, {
                  answered: 'no',
                  details: ''
                });
              }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
                isNo
                  ? 'bg-slate-700 border-slate-700 text-white shadow-xs'
                  : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <div className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                isNo ? 'border-white bg-white' : 'border-slate-400'
              }`}>
                {isNo && <div className="w-1.5 h-1.5 rounded-full bg-slate-700" />}
              </div>
              <span>No</span>
            </button>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* GIFT ALLOWANCE TABLE: Displayed when Yes is selected for giftAllowanceUsed */}
        {/* ========================================================================= */}
        {isYes && isGiftAllowance && (
          <div className="mt-3.5 pt-3 border-t border-slate-200/80 animate-in fade-in slide-in-from-top-1 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <div className="flex items-center gap-2">
                  <label className="text-xs font-bold text-slate-900">
                    Gift Allowance Details &amp; Schedule <span className="text-rose-500">* (Mandatory)</span>
                  </label>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                    isIndigo ? 'bg-indigo-100 text-indigo-800 border-indigo-200' : 'bg-blue-100 text-blue-800 border-blue-200'
                  }`}>
                    {currentGifts.length} / 5 Gifts
                  </span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Record financial gifts, recipients, dates, and amounts (maximum 5 gifts).
                </p>
              </div>

              {/* Add Gift Button */}
              <button
                type="button"
                onClick={() => handleAddGift(clientPrefix)}
                disabled={currentGifts.length >= 5}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition border cursor-pointer self-start sm:self-auto ${
                  currentGifts.length >= 5
                    ? 'bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed'
                    : isIndigo
                    ? 'bg-indigo-600 hover:bg-indigo-700 border-indigo-600 text-white shadow-xs'
                    : 'bg-blue-600 hover:bg-blue-700 border-blue-600 text-white shadow-xs'
                }`}
                title={currentGifts.length >= 5 ? 'Maximum 5 gifts reached' : 'Add another gift'}
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{currentGifts.length >= 5 ? 'Max 5 Gifts' : 'Add Gift'}</span>
              </button>
            </div>

            {/* Gifts Table */}
            <div className="border border-slate-200 rounded-xl bg-white shadow-2xs overflow-hidden">
              <div className="w-full overflow-hidden">
                <table className="w-full text-left border-collapse table-fixed">
                  <colgroup>
                    <col style={{ width: '8%' }} />
                    <col style={{ width: '38%' }} />
                    <col style={{ width: '24%' }} />
                    <col style={{ width: '22%' }} />
                    <col style={{ width: '8%' }} />
                  </colgroup>
                  <thead>
                    <tr className="bg-slate-50 text-[10px] font-bold text-slate-700 uppercase tracking-wider border-b border-slate-200">
                      <th className="py-2 px-1 text-center">#</th>
                      <th className="py-2 px-2 truncate">
                        Recipient <span className="text-rose-500">*</span>
                      </th>
                      <th className="py-2 px-2 truncate">
                        Date Gifted
                      </th>
                      <th className="py-2 px-2 truncate">
                        Amount <span className="text-rose-500">*</span>
                      </th>
                      <th className="py-2 px-1 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs">
                    {currentGifts.map((gift, idx) => {
                      const recError = fieldErrors[`${clientPrefix}-gift-recipient-${idx}`] || fieldErrors[`gift-recipient-${idx}`];
                      const amtError = fieldErrors[`${clientPrefix}-gift-amount-${idx}`] || fieldErrors[`gift-amount-${idx}`];

                      return (
                        <tr key={gift.id || `gift-${idx}`} className="hover:bg-slate-50/70 transition-colors align-top">
                          {/* Row index */}
                          <td className="py-2 px-1 text-center text-slate-400 font-mono font-medium pt-3">
                            {idx + 1}
                          </td>

                          {/* Gift Recipient */}
                          <td className="py-1.5 px-2 space-y-1">
                            <div className="relative">
                              <User className={`w-3 h-3 absolute left-2 top-2.5 pointer-events-none ${recError ? 'text-rose-500' : 'text-slate-400'}`} />
                              <input
                                type="text"
                                value={gift.recipient || ''}
                                onChange={(e) => handleUpdateGift(clientPrefix, idx, { recipient: e.target.value })}
                                placeholder="Recipient name..."
                                className={`w-full min-w-0 py-1.5 pl-6 pr-2 text-xs rounded-lg border bg-white focus:outline-none transition ${
                                  recError
                                    ? 'border-rose-400 focus:ring-2 focus:ring-rose-200 bg-rose-50/20 text-slate-900'
                                    : 'border-slate-300 focus:ring-2 focus:ring-blue-500 text-slate-900'
                                }`}
                              />
                            </div>
                            {recError && (
                              <p className="text-[9px] text-rose-600 font-semibold flex items-center gap-0.5 truncate">
                                <AlertCircle className="w-2.5 h-2.5 shrink-0" />
                                Required
                              </p>
                            )}
                          </td>

                          {/* Date Gifted */}
                          <td className="py-1.5 px-2 space-y-1">
                            <div className="relative">
                              <Calendar className="w-3 h-3 absolute left-2 top-2.5 pointer-events-none text-slate-400" />
                              <input
                                type="text"
                                value={gift.dateGifted || ''}
                                onChange={(e) => handleUpdateGift(clientPrefix, idx, { dateGifted: e.target.value })}
                                placeholder="DD/MM/YYYY"
                                className="w-full min-w-0 py-1.5 pl-6 pr-2 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-900"
                              />
                            </div>
                          </td>

                          {/* Amount Gifted */}
                          <td className="py-1.5 px-2 space-y-1">
                            <div className="relative">
                              <PoundSterling className={`w-3 h-3 absolute left-2 top-2.5 pointer-events-none ${amtError ? 'text-rose-500' : 'text-slate-400'}`} />
                              <input
                                type="text"
                                value={gift.amountGifted || ''}
                                onChange={(e) => handleUpdateGift(clientPrefix, idx, { amountGifted: e.target.value })}
                                onBlur={(e) => formatGiftAmountOnBlur(clientPrefix, idx, e.target.value)}
                                placeholder="£3,000"
                                className={`w-full min-w-0 py-1.5 pl-6 pr-2 text-xs font-mono font-bold rounded-lg border bg-white focus:outline-none transition ${
                                  amtError
                                    ? 'border-rose-400 focus:ring-2 focus:ring-rose-200 bg-rose-50/20 text-slate-900'
                                    : 'border-slate-300 focus:ring-2 focus:ring-blue-500 text-slate-900'
                                }`}
                              />
                            </div>
                            {amtError && (
                              <p className="text-[9px] text-rose-600 font-semibold flex items-center gap-0.5 truncate">
                                <AlertCircle className="w-2.5 h-2.5 shrink-0" />
                                Required
                              </p>
                            )}
                          </td>

                          {/* Action */}
                          <td className="py-1.5 px-1 text-center pt-2.5">
                            <button
                              type="button"
                              onClick={() => handleRemoveGift(clientPrefix, idx)}
                              className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                              title={currentGifts.length <= 1 ? 'Clear gift row' : 'Remove this gift'}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Gifts Summary Footer */}
              <div className="p-2.5 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-1.5 text-[10px] text-slate-500">
                  <Info className="w-3 h-3 text-blue-600 shrink-0" />
                  <span>Annual exemption (£3,000/tax yr) or PETs.</span>
                </div>
                <div className="flex items-center gap-1.5 self-end sm:self-auto font-mono">
                  <span className="text-[10px] font-bold text-slate-600 uppercase tracking-wider">
                    Total:
                  </span>
                  <span className="text-[11px] font-bold text-blue-900 bg-blue-100/70 border border-blue-200 px-2 py-0.5 rounded-md">
                    £{Math.round(totalGiftedValue).toLocaleString('en-GB')}
                  </span>
                </div>
              </div>
            </div>

            {hasError && (
              <p className="text-[11px] text-rose-600 font-semibold flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                Please enter valid Gift Recipient and Amount Gifted for each recorded gift.
              </p>
            )}
          </div>
        )}

        {/* Standard Pound Sterling Input (for questions other than giftAllowanceUsed) */}
        {isYes && !isGiftAllowance && (
          <div className="mt-3.5 pt-3 border-t border-slate-200/80 animate-in fade-in slide-in-from-top-1 space-y-1.5">
            <label className="block text-xs font-bold text-slate-900">
              {item.inputLabel} <span className="text-rose-500">* (Mandatory)</span>
            </label>
            <div className="relative max-w-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <PoundSterling className={`w-4 h-4 ${hasError ? 'text-rose-500' : 'text-slate-400'}`} />
              </div>
              <input
                type="text"
                value={currentQuestion.details || ''}
                onChange={(e) => {
                  handleUpdateQuestion(clientPrefix, item.key, {
                    answered: 'yes',
                    details: e.target.value
                  });
                }}
                onBlur={(e) => formatCurrencyOnBlur(clientPrefix, item.key, e.target.value)}
                placeholder={item.placeholder}
                className={`w-full pl-9 pr-3 py-2 text-xs font-mono font-bold rounded-lg border bg-white focus:outline-none transition leading-relaxed ${
                  hasError
                    ? 'border-rose-400 focus:border-rose-500 focus:ring-2 focus:ring-rose-200 text-slate-900'
                    : isIndigo
                    ? 'border-slate-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 text-slate-900'
                    : 'border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 text-slate-900'
                }`}
                required={isYes}
              />
            </div>
            {hasError ? (
              <p className="text-[11px] text-rose-600 font-semibold flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                Please enter a valid Pound Sterling (£) value because &ldquo;Yes&rdquo; is selected.
              </p>
            ) : (
              <p className="text-[10px] text-slate-400">
                Values will automatically format in standard Pound Sterling (£) currency format.
              </p>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <form id="fact-find-stage5-form" onSubmit={onSubmit} className="space-y-6 animate-in fade-in duration-150">
      
      {/* Context Summary Banner */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-100 text-blue-700 rounded-lg shrink-0">
            <SlidersHorizontal className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-900">
              Stage 5: Capacity &amp; Tax Allowances
            </h3>
            <p className="text-[11px] text-slate-500">
              Client: <span className="font-semibold text-slate-800">{client1DisplayName}</span> {isJoint ? `& ${client2DisplayName}` : ''} • Adviser: {leadAdviser}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {isJoint ? (
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-indigo-50 border border-indigo-200 text-indigo-800 rounded-lg text-xs font-semibold self-start sm:self-center">
              <Users className="w-3.5 h-3.5" />
              <span>Married Couple / 2 Clients Enabled</span>
            </div>
          ) : (
            <span className="px-2.5 py-1 text-[11px] font-semibold bg-blue-50 text-blue-700 border border-blue-200 rounded-lg">
              Capacity &amp; Allowances
            </span>
          )}
        </div>
      </div>

      {/* Questions: Single Client OR Side-by-Side View for Married Couples */}
      {isJoint ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* ============================================================ */}
          {/* CLIENT 1 COLUMN (LEFT SIDE)                                  */}
          {/* ============================================================ */}
          <div className="border border-blue-200 rounded-2xl p-5 bg-white shadow-2xs space-y-4">
            
            {/* Column Header */}
            <div className="flex items-center justify-between pb-3 border-b border-blue-100 bg-blue-50/40 -mx-5 -mt-5 p-4 rounded-t-2xl">
              <div className="flex items-center gap-2.5">
                <div className="w-6 h-6 rounded-full bg-blue-600 text-white text-xs font-bold flex items-center justify-center shadow-xs">
                  1
                </div>
                <div>
                  <h4 className="text-xs font-bold text-blue-950 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-blue-600" />
                    <span>Client 1 (Left Side)</span>
                  </h4>
                  <span className="text-[11px] font-semibold text-blue-800 truncate block max-w-[220px]">
                    {client1DisplayName}
                  </span>
                </div>
              </div>
              <span className="text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 bg-blue-100 text-blue-800 rounded-full border border-blue-200">
                Primary Client
              </span>
            </div>

            {/* Questions for Client 1 */}
            <div className="space-y-3.5">
              {CAPACITY_QUESTIONS.map((item) => renderQuestionCard(item, 'c1', activeC1State, 'blue'))}
            </div>
          </div>

          {/* ============================================================ */}
          {/* CLIENT 2 COLUMN (RIGHT SIDE)                                 */}
          {/* ============================================================ */}
          <div className="border border-indigo-200 rounded-2xl p-5 bg-white shadow-2xs space-y-4">
            
            {/* Column Header */}
            <div className="flex items-center justify-between pb-3 border-b border-indigo-100 bg-indigo-50/40 -mx-5 -mt-5 p-4 rounded-t-2xl">
              <div className="flex items-center gap-2.5">
                <div className="w-6 h-6 rounded-full bg-indigo-600 text-white text-xs font-bold flex items-center justify-center shadow-xs">
                  2
                </div>
                <div>
                  <h4 className="text-xs font-bold text-indigo-950 flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Client 2 (Right Side)</span>
                  </h4>
                  <span className="text-[11px] font-semibold text-indigo-800 truncate block max-w-[220px]">
                    {client2DisplayName}
                  </span>
                </div>
              </div>
              <span className="text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 bg-indigo-100 text-indigo-800 rounded-full border border-indigo-200">
                Partner / Spouse
              </span>
            </div>

            {/* Questions for Client 2 */}
            <div className="space-y-3.5">
              {CAPACITY_QUESTIONS.map((item) => renderQuestionCard(item, 'c2', activeC2State, 'indigo'))}
            </div>
          </div>
        </div>
      ) : (
        /* ============================================================ */
        /* SINGLE CLIENT VIEW                                           */
        /* ============================================================ */
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
              Investment Capacity &amp; Allowance Utilization
            </h4>
            <span className="text-[11px] text-slate-500">
              Selecting &ldquo;Yes&rdquo; requires formatted financial breakdown values
            </span>
          </div>

          <div className="space-y-3.5">
            {CAPACITY_QUESTIONS.map((item) => renderQuestionCard(item, 'c1', activeC1State, 'blue'))}
          </div>
        </div>
      )}

      {/* Information Note */}
      <div className="p-3.5 bg-blue-50/70 border border-blue-200 rounded-xl flex items-start gap-2.5 text-blue-900 text-xs">
        <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
        <div className="space-y-0.5">
          <p className="font-semibold text-blue-950">
            Capacity &amp; Allowance Review Summary
          </p>
          <p className="text-blue-800 text-[11px] leading-relaxed">
            These figures determine tax wrapper allocation suitability (ISAs, General Investment Accounts, Pensions, and Trusts) and ensure advice aligns with statutory annual allowances and IHT planning.
          </p>
        </div>
      </div>

    </form>
  );
};
