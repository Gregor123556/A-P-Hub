import React, { useState, useEffect, useRef } from 'react';
import { Calendar, Cake } from 'lucide-react';
import { 
  parseDDMMYYYY, 
  formatDDMMYYYY, 
  calculateAge, 
  normalizeDateStringToDDMMYYYY, 
  ddmmToYyyyMmDd, 
  yyyymmddToDdMmYyyy 
} from '../../utils/dateUtils';

interface DateOfBirthInputProps {
  id?: string;
  value: string;
  onChange: (val: string) => void;
  label?: string;
  themeColor?: 'blue' | 'indigo';
  required?: boolean;
  helperText?: string;
}

export const DateOfBirthInput: React.FC<DateOfBirthInputProps> = ({
  id = 'dob-input',
  value,
  onChange,
  label = '2. Date of Birth',
  themeColor = 'blue',
  required = false,
  helperText = 'Format: DD/MM/YYYY (e.g. 15/05/1979)'
}) => {
  // Convert standard internal DD-MM-YYYY to display DD/MM/YYYY
  const formatDisplay = (val: string) => {
    if (!val) return '';
    return val.replace(/-/g, '/');
  };

  const [displayText, setDisplayText] = useState<string>(() => formatDisplay(value));
  const nativeDateRef = useRef<HTMLInputElement>(null);

  // Synchronize when value changes externally (e.g. when loading client data)
  useEffect(() => {
    setDisplayText(formatDisplay(value));
  }, [value]);

  // Compute live age if valid date
  const age = calculateAge(displayText || value);

  // Intelligent auto-formatting for DD/MM/YYYY typing
  const handleTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let input = e.target.value;

    // Allow user to type digits, slashes, dashes, dots
    // If user is typing raw numbers or pasting, format progressively
    const digitsOnly = input.replace(/\D/g, '');

    let formatted = input;
    // Auto-mask if user is entering digits sequentially without separators
    if (!input.includes('/') && !input.includes('-') && !input.includes('.')) {
      if (digitsOnly.length <= 2) {
        formatted = digitsOnly;
      } else if (digitsOnly.length <= 4) {
        formatted = `${digitsOnly.slice(0, 2)}/${digitsOnly.slice(2)}`;
      } else {
        formatted = `${digitsOnly.slice(0, 2)}/${digitsOnly.slice(2, 4)}/${digitsOnly.slice(4, 8)}`;
      }
    }

    setDisplayText(formatted);

    // If complete date with 8 digits, normalize and send to parent
    const clean = formatted.trim();
    if (/^\d{1,2}[-/.]\d{1,2}[-/.]\d{4}$/.test(clean) || /^\d{8}$/.test(clean)) {
      const normalized = normalizeDateStringToDDMMYYYY(clean);
      onChange(normalized);
    } else {
      onChange(clean);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    // If user presses backspace and character before cursor is '/', delete the '/' and preceding character
    if (e.key === 'Backspace') {
      const target = e.currentTarget;
      const pos = target.selectionStart;
      if (pos && (displayText[pos - 1] === '/' || displayText[pos - 1] === '-')) {
        e.preventDefault();
        const nextText = displayText.slice(0, pos - 2) + displayText.slice(pos);
        setDisplayText(nextText);
        onChange(nextText);
      }
    }
  };

  const handleBlur = () => {
    if (!displayText.trim()) {
      setDisplayText('');
      onChange('');
      return;
    }

    const normalized = normalizeDateStringToDDMMYYYY(displayText);
    const parsed = parseDDMMYYYY(normalized);

    if (parsed) {
      const formattedDash = formatDDMMYYYY(parsed);
      setDisplayText(formatDisplay(formattedDash));
      onChange(formattedDash);
    } else {
      // Keep user's input as-is so they can fix it
      onChange(displayText.trim());
    }
  };

  const handleNativePickerChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const isoVal = e.target.value;
    if (isoVal) {
      const ddmmyyyy = yyyymmddToDdMmYyyy(isoVal);
      setDisplayText(formatDisplay(ddmmyyyy));
      onChange(ddmmyyyy);
    }
  };

  const openCalendarPicker = () => {
    if (nativeDateRef.current) {
      if (typeof nativeDateRef.current.showPicker === 'function') {
        try {
          nativeDateRef.current.showPicker();
        } catch {
          nativeDateRef.current.focus();
        }
      } else {
        nativeDateRef.current.focus();
      }
    }
  };

  const isIndigo = themeColor === 'indigo';
  const ringFocus = isIndigo 
    ? 'focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 border-indigo-200' 
    : 'focus:ring-2 focus:ring-blue-500 focus:border-blue-500 border-slate-300';
  
  const iconColor = isIndigo ? 'text-indigo-400' : 'text-slate-400';
  const labelColor = isIndigo ? 'text-indigo-950' : 'text-slate-800';

  return (
    <div>
      <div className="flex items-center justify-between mb-1.5">
        <label htmlFor={id} className={`block text-xs font-bold ${labelColor}`}>
          {label} {required && <span className="text-rose-500">*</span>}
        </label>
        {age !== null && (
          <span className={`inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-md ${
            isIndigo ? 'bg-indigo-100 text-indigo-800' : 'bg-blue-100 text-blue-800'
          }`}>
            <Cake className="w-3 h-3" />
            <span>Age: {age}</span>
          </span>
        )}
      </div>

      <div className="relative">
        <Calendar className={`w-4 h-4 ${iconColor} absolute left-3 top-2.5 pointer-events-none`} />
        
        <input
          id={id}
          type="text"
          value={displayText}
          onChange={handleTextChange}
          onKeyDown={handleKeyDown}
          onBlur={handleBlur}
          placeholder="DD/MM/YYYY (e.g. 15/05/1979)"
          autoComplete="bday"
          maxLength={10}
          className={`w-full pl-9 pr-10 py-2 text-xs border rounded-lg bg-white font-mono text-slate-900 ${ringFocus}`}
        />

        {/* Interactive Calendar Icon / Picker trigger on the right */}
        <div className="absolute right-1.5 top-1.5 flex items-center">
          <button
            type="button"
            onClick={openCalendarPicker}
            tabIndex={-1}
            title="Open calendar picker"
            className={`p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-md transition cursor-pointer`}
          >
            <Calendar className="w-4 h-4" />
          </button>
          
          {/* Hidden native date input for browser datepicker dialog */}
          <input
            ref={nativeDateRef}
            type="date"
            tabIndex={-1}
            aria-hidden="true"
            value={ddmmToYyyyMmDd(displayText || value)}
            onChange={handleNativePickerChange}
            className="sr-only absolute w-0 h-0 opacity-0 pointer-events-none"
          />
        </div>
      </div>

      <div className="flex items-center justify-between mt-1 text-[10px] text-slate-500">
        <span>{helperText}</span>
        {value && value !== displayText && (
          <span className="font-mono text-slate-600 font-semibold">Saved: {value}</span>
        )}
      </div>
    </div>
  );
};
