import React from 'react';
import { 
  FileText, 
  Info, 
  User, 
  Sparkles,
  Edit3
} from 'lucide-react';

export interface Stage7AdditionalNotesState {
  additionalNotes: string;
}

export interface FactFindStage7Props {
  data: Stage7AdditionalNotesState;
  onChangeData?: (data: Stage7AdditionalNotesState) => void;
  setData?: React.Dispatch<React.SetStateAction<Stage7AdditionalNotesState>> | ((data: Stage7AdditionalNotesState) => void);
  fieldErrors?: Record<string, boolean>;
  onClearFieldError?: (key: string) => void;
  c1FullName?: string;
  c2FullName?: string;
  client1Name?: string;
  client2Name?: string;
  hasSecondClient?: boolean;
  adviser?: string;
  adviserName?: string;
  onBackToStage6: () => void;
  onSubmit: (e: React.FormEvent) => void;
}

export const FactFindStage7: React.FC<FactFindStage7Props> = ({
  data,
  onChangeData,
  setData,
  onClearFieldError,
  c1FullName,
  c2FullName,
  client1Name,
  client2Name,
  hasSecondClient,
  adviser,
  adviserName,
  onBackToStage6: _onBackToStage6,
  onSubmit
}) => {
  const primaryName = c1FullName || client1Name || 'Primary Client';
  const secondaryName = c2FullName || client2Name || 'Second Client';
  const activeAdviser = adviser || adviserName || 'Adams & Poole Adviser';

  const handleUpdate = (notes: string) => {
    const nextState = { additionalNotes: notes };
    if (onChangeData) onChangeData(nextState);
    if (setData) setData(nextState);
    if (onClearFieldError) onClearFieldError('additionalNotes');
  };

  return (
    <form id="fact-find-stage7-form" onSubmit={onSubmit} className="space-y-6 pb-6">
      {/* Overview Banner */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-2xl p-4 sm:p-5 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="p-2.5 bg-blue-600 text-white rounded-xl shadow-xs shrink-0 mt-0.5">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-blue-600 text-white rounded-md">
                  Stage 7 of 8
                </span>
                <h3 className="text-sm font-bold text-slate-900">
                  Additional Notes
                </h3>
              </div>
              <p className="text-xs text-slate-600 mt-1 max-w-2xl">
                Capture any additional qualitative notes, meeting observations, vulnerable client considerations, specific instructions, or compliance points.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-600 bg-white/80 backdrop-blur-xs px-3 py-1.5 rounded-xl border border-blue-100 self-start sm:self-auto shrink-0">
            <User className="w-3.5 h-3.5 text-blue-600" />
            <span className="font-medium">
              {primaryName}
              {hasSecondClient && ` & ${secondaryName}`}
            </span>
            <span className="text-slate-300">•</span>
            <span className="text-slate-500">{activeAdviser}</span>
          </div>
        </div>
      </div>

      {/* Main Large Notes Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-2xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Edit3 className="w-4 h-4 text-blue-600" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              Adviser Fact Find Notes
            </h4>
          </div>
          <span className="text-[11px] font-medium text-slate-400">
            {data.additionalNotes ? `${data.additionalNotes.length} characters` : 'Optional'}
          </span>
        </div>

        <div className="space-y-2">
          <label htmlFor="additional-notes-textarea" className="block text-xs font-semibold text-slate-700">
            Extra Notes &amp; Observations
          </label>
          <textarea
            id="additional-notes-textarea"
            rows={14}
            value={data.additionalNotes || ''}
            onChange={(e) => handleUpdate(e.target.value)}
            placeholder="Record any extra details, client background context, soft facts, health/vulnerability notes, specialist requirements, legacy planning ideas, or follow-up action points here..."
            className="w-full text-xs text-slate-800 bg-slate-50/50 border border-slate-300 rounded-xl p-4 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition placeholder:text-slate-400 leading-relaxed resize-y min-h-[280px]"
          />
        </div>

        {/* Helpful Guidance Hints */}
        <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex items-start gap-2.5 text-[11px] text-slate-600">
          <Info className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <span className="font-semibold text-slate-800">Suggested Topics to Document:</span>
            <ul className="list-disc list-inside space-y-0.5 text-slate-600 marker:text-slate-400">
              <li>Meeting setting, attendees, and dynamics between joint applicants</li>
              <li>Life events, upcoming retirement dates, property downsizing intentions, or business exit plans</li>
              <li>Vulnerable customer indicators (health, bereavement, financial capability)</li>
              <li>Existing professional advisers (solicitors, accountants, trustees)</li>
              <li>Specific exclusions or ethical preferences not covered in Stage 6</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Completion Ready Note */}
      <div className="p-4 bg-blue-50/70 border border-blue-200/80 rounded-xl flex items-center justify-between text-xs text-blue-950">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-blue-600 shrink-0" />
          <span>
            Click <strong>"Next: Stage 8 (Review &amp; Submit)"</strong> below to review a complete summary of all client data before submitting.
          </span>
        </div>
      </div>
    </form>
  );
};
