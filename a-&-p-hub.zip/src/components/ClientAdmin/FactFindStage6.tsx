import React from 'react';
import { 
  Target, 
  Compass, 
  Clock, 
  ShieldCheck, 
  Leaf, 
  Plus, 
  Trash2, 
  AlertCircle, 
  CheckCircle2, 
  Info,
  Sliders,
  TrendingUp,
  Sparkles,
  Award
} from 'lucide-react';
import { 
  FactFindPrimaryGoal, 
  FactFindTimeHorizon, 
  FactFindAttitudeToRisk, 
  FactFindYesNoQuestion 
} from '../../types';

export interface Stage6ObjectivesRiskState {
  primaryGoals?: FactFindPrimaryGoal[];
  primaryGoal?: string;
  timeHorizon: FactFindTimeHorizon | '';
  objective1: string;
  objective2: string;
  objective3: string;
  hasObjective3: boolean;
  attitudeToRisk: FactFindAttitudeToRisk | '';
  ethicalEsgPreferences: FactFindYesNoQuestion;
}

export interface FactFindStage6Props {
  data: Stage6ObjectivesRiskState;
  onChangeData?: (data: Stage6ObjectivesRiskState) => void;
  setData?: React.Dispatch<React.SetStateAction<Stage6ObjectivesRiskState>> | ((data: Stage6ObjectivesRiskState) => void);
  fieldErrors?: Record<string, boolean>;
  onClearFieldError?: (key: string) => void;
  c1FullName?: string;
  c2FullName?: string;
  client1Name?: string;
  client2Name?: string;
  hasSecondClient?: boolean;
  adviser?: string;
  adviserName?: string;
  onBackToStage5: () => void;
  onSubmit: (e: React.FormEvent) => void;
}

const PRIMARY_GOALS: { value: FactFindPrimaryGoal; label: string; desc: string; icon: string }[] = [
  { value: 'Growth', label: 'Growth', desc: 'Focus on long-term capital appreciation and compounding returns.', icon: '📈' },
  { value: 'Income', label: 'Income', desc: 'Generate a reliable, recurring yield from dividends and interest distributions.', icon: '💰' },
  { value: 'Preservation', label: 'Preservation', desc: 'Protect capital against inflation and minimize downside market volatility.', icon: '🛡️' },
  { value: 'IHT Planning', label: 'IHT Planning', desc: 'Mitigate inheritance tax exposure and structure intergenerational wealth transfer.', icon: '🏛️' }
];

const TIME_HORIZONS: { value: FactFindTimeHorizon; label: string; desc: string }[] = [
  { value: '0-5 Years', label: '0–5 Years', desc: 'Short term / near-term liquidity & transition period' },
  { value: '5-10 Years', label: '5–10 Years', desc: 'Medium term strategy over market cycles' },
  { value: '10+ Years', label: '10+ Years', desc: 'Long term compounding & intergenerational planning' }
];

const RISK_LEVELS: { value: FactFindAttitudeToRisk; label: string; badge: string; desc: string; color: string }[] = [
  { 
    value: 'Conservative', 
    label: 'Conservative', 
    badge: 'Lower Risk', 
    desc: 'Prioritizes capital security with low equity exposure; minimal risk tolerance for capital loss.',
    color: 'emerald'
  },
  { 
    value: 'Moderate', 
    label: 'Moderate', 
    badge: 'Balanced Risk', 
    desc: 'Balanced exposure between equities and fixed income; accepts modest volatility for steady growth.',
    color: 'blue'
  },
  { 
    value: 'Dynamic', 
    label: 'Dynamic', 
    badge: 'Higher Growth', 
    desc: 'Higher equity weighting seeking above-average capital growth; comfortable with medium-high volatility.',
    color: 'indigo'
  },
  { 
    value: 'Adventurous', 
    label: 'Adventurous', 
    badge: 'Maximum Growth', 
    desc: 'High to 100% equity weighting targeting maximum growth; fully comfortable with significant volatility.',
    color: 'purple'
  }
];

export const FactFindStage6: React.FC<FactFindStage6Props> = ({
  data,
  onChangeData,
  setData,
  fieldErrors = {},
  onClearFieldError,
  c1FullName,
  c2FullName,
  client1Name,
  client2Name,
  hasSecondClient,
  adviser,
  adviserName,
  onSubmit
}) => {
  const primaryClient = c1FullName || client1Name || 'Primary Client';
  const secondClient = c2FullName || client2Name;
  const leadAdviser = adviser || adviserName || 'Lead Adviser';
  const isJoint = hasSecondClient !== undefined ? hasSecondClient : Boolean(secondClient);

  const notifyChange = (updated: Stage6ObjectivesRiskState) => {
    if (typeof onChangeData === 'function') {
      onChangeData(updated);
    }
    if (typeof setData === 'function') {
      setData(updated);
    }
  };

  const handleUpdate = (partial: Partial<Stage6ObjectivesRiskState>) => {
    const nextData: Stage6ObjectivesRiskState = {
      ...data,
      ...partial
    };
    notifyChange(nextData);

    // Clear matching field error if resolved
    if (onClearFieldError) {
      if (partial.primaryGoals && partial.primaryGoals.length > 0) {
        onClearFieldError('primaryGoal');
      }
      if (partial.primaryGoal && partial.primaryGoal.trim()) {
        onClearFieldError('primaryGoal');
      }
      Object.keys(partial).forEach(key => {
        if (fieldErrors[key]) {
          const val = (partial as Record<string, unknown>)[key];
          if (typeof val === 'string' && val.trim()) {
            onClearFieldError(key);
          } else if (Array.isArray(val) && val.length > 0) {
            onClearFieldError(key);
          } else if (key === 'ethicalEsgPreferences') {
            onClearFieldError(key);
          }
        }
      });
    }
  };

  return (
    <form id="fact-find-stage6-form" onSubmit={onSubmit} className="space-y-8 animate-in fade-in duration-150">
      
      {/* Context Summary Header Banner */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-blue-100 text-blue-700 rounded-xl shrink-0">
            <Compass className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-900 flex items-center gap-2">
              <span>Stage 6: Objectives / Risk &amp; Investment Preferences</span>
              <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-full">
                Final Fact Find Stage
              </span>
            </h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Client: <span className="font-semibold text-slate-800">{primaryClient}</span> {isJoint && secondClient ? `& ${secondClient}` : ''} • Adviser: {leadAdviser}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1 text-xs font-bold bg-blue-600 text-white rounded-lg shadow-xs flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            Suitability Alignment
          </span>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* SUBSECTION 1: OBJECTIVES                                                  */}
      {/* ========================================================================= */}
      <section className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 shadow-xs space-y-6">
        
        {/* Subsection Header */}
        <div className="flex items-center justify-between border-b border-slate-200/80 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-blue-50 text-blue-700 rounded-lg">
              <Target className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900">
                Objectives
              </h4>
              <p className="text-[11px] text-slate-500">
                Identify primary financial goals, investment horizons, and explicit client target milestones.
              </p>
            </div>
          </div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-2.5 py-1 rounded-md border border-blue-200/60">
            Subsection 1 of 2
          </span>
        </div>

        {/* 1. Primary Goal (Tickboxes - Multi-select, at least 1, can select all) */}
        <div className="space-y-2.5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <label className="block text-xs font-bold text-slate-900">
                Primary Goal <span className="text-rose-500">* (Select at least 1, multiple allowed)</span>
              </label>
              {(() => {
                const currentGoals = data.primaryGoals && data.primaryGoals.length > 0
                  ? data.primaryGoals
                  : data.primaryGoal
                  ? data.primaryGoal.split(',').map(s => s.trim() as FactFindPrimaryGoal).filter(Boolean)
                  : [];
                if (currentGoals.length > 0) {
                  return (
                    <span className="px-2 py-0.5 text-[10px] font-bold bg-blue-100 text-blue-800 rounded-full">
                      {currentGoals.length} {currentGoals.length === 1 ? 'goal' : 'goals'} selected
                    </span>
                  );
                }
                return null;
              })()}
            </div>

            {/* Quick Actions: Select All / Clear All */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  const allGoals: FactFindPrimaryGoal[] = ['Growth', 'Income', 'Preservation', 'IHT Planning'];
                  handleUpdate({
                    primaryGoals: allGoals,
                    primaryGoal: allGoals.join(', ')
                  });
                }}
                className="text-[11px] font-bold text-blue-700 hover:text-blue-800 hover:underline cursor-pointer transition"
              >
                Select All
              </button>
              <span className="text-slate-300 text-xs">•</span>
              <button
                type="button"
                onClick={() => {
                  handleUpdate({
                    primaryGoals: [],
                    primaryGoal: ''
                  });
                }}
                className="text-[11px] font-semibold text-slate-500 hover:text-slate-700 cursor-pointer transition"
              >
                Clear
              </button>
            </div>
          </div>

          {fieldErrors['primaryGoal'] && (
            <span className="text-[11px] font-semibold text-rose-600 flex items-center gap-1">
              <AlertCircle className="w-3.5 h-3.5" /> Please select at least 1 primary goal
            </span>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {PRIMARY_GOALS.map((goal) => {
              const currentGoals = data.primaryGoals && data.primaryGoals.length > 0
                ? data.primaryGoals
                : data.primaryGoal
                ? data.primaryGoal.split(',').map(s => s.trim() as FactFindPrimaryGoal).filter(Boolean)
                : [];
              const isSelected = currentGoals.includes(goal.value);

              return (
                <button
                  key={goal.value}
                  type="button"
                  onClick={() => {
                    const updated = isSelected
                      ? currentGoals.filter(g => g !== goal.value)
                      : [...currentGoals, goal.value];
                    handleUpdate({
                      primaryGoals: updated,
                      primaryGoal: updated.join(', ')
                    });
                  }}
                  className={`p-3.5 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between gap-2.5 relative ${
                    isSelected
                      ? 'bg-blue-50/50 border-blue-600 ring-2 ring-blue-600/20 shadow-xs'
                      : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/50'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-base">{goal.icon}</span>
                      <span className={`text-xs font-bold ${isSelected ? 'text-blue-900' : 'text-slate-900'}`}>
                        {goal.label}
                      </span>
                    </div>

                    {/* Tickbox Indicator */}
                    <div className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 transition ${
                      isSelected
                        ? 'bg-blue-600 border-blue-600 text-white'
                        : 'border-slate-300 bg-white'
                    }`}>
                      {isSelected && <CheckCircle2 className="w-3.5 h-3.5" />}
                    </div>
                  </div>

                  <p className="text-[10px] text-slate-500 leading-snug">
                    {goal.desc}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* 2. Time Horizon (Tickboxes - Options: 0-5 Years, 5-10 Years, 10+ Years) */}
        <div className="space-y-2.5 pt-2">
          <div className="flex items-center justify-between">
            <label className="block text-xs font-bold text-slate-900">
              Time Horizon <span className="text-rose-500">* (Select 1)</span>
            </label>
            {fieldErrors['timeHorizon'] && (
              <span className="text-[11px] font-semibold text-rose-600 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" /> Please select an investment time horizon
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {TIME_HORIZONS.map((th) => {
              const isSelected = data.timeHorizon === th.value;
              return (
                <button
                  key={th.value}
                  type="button"
                  onClick={() => handleUpdate({ timeHorizon: th.value })}
                  className={`p-3.5 rounded-xl border text-left transition cursor-pointer flex items-center justify-between gap-3 ${
                    isSelected
                      ? 'bg-blue-50/50 border-blue-600 ring-2 ring-blue-600/20 shadow-xs'
                      : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/50'
                  }`}
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <Clock className={`w-3.5 h-3.5 ${isSelected ? 'text-blue-600' : 'text-slate-400'}`} />
                      <span className={`text-xs font-bold ${isSelected ? 'text-blue-900' : 'text-slate-900'}`}>
                        {th.label}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-500">
                      {th.desc}
                    </p>
                  </div>

                  {/* Tickbox Indicator */}
                  <div className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 transition ${
                    isSelected
                      ? 'bg-blue-600 border-blue-600 text-white'
                      : 'border-slate-300 bg-white'
                  }`}>
                    {isSelected && <CheckCircle2 className="w-3.5 h-3.5" />}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* 3. Objectives Textboxes (Objective 1 Mandatory, Objective 2 Mandatory, Objective 3 Optional) */}
        <div className="space-y-4 pt-2 border-t border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <h5 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                Specific Client Objectives
              </h5>
              <p className="text-[11px] text-slate-500">
                Detail the specific milestones, retirement age targets, purchase plans, or income goals.
              </p>
            </div>
            {!data.hasObjective3 && (
              <button
                type="button"
                onClick={() => handleUpdate({ hasObjective3: true })}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Objective 3</span>
              </button>
            )}
          </div>

          {/* Objective 1 (Mandatory) */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-slate-900">
                Objective 1 <span className="text-rose-500">* (Mandatory)</span>
              </label>
              {fieldErrors['objective1'] && (
                <span className="text-[11px] font-semibold text-rose-600 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" /> Objective 1 details required
                </span>
              )}
            </div>
            <textarea
              rows={2}
              value={data.objective1 || ''}
              onChange={(e) => handleUpdate({ objective1: e.target.value })}
              placeholder="e.g., Retire at age 60 with a sustainable net pension income of £45,000 p.a. while preserving capital for family inheritance."
              className={`w-full p-3 text-xs rounded-xl border bg-white focus:outline-none transition leading-relaxed ${
                fieldErrors['objective1']
                  ? 'border-rose-400 focus:border-rose-500 focus:ring-2 focus:ring-rose-200'
                  : 'border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-100'
              }`}
              required
            />
          </div>

          {/* Objective 2 (Mandatory) */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-slate-900">
                Objective 2 <span className="text-rose-500">* (Mandatory)</span>
              </label>
              {fieldErrors['objective2'] && (
                <span className="text-[11px] font-semibold text-rose-600 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" /> Objective 2 details required
                </span>
              )}
            </div>
            <textarea
              rows={2}
              value={data.objective2 || ''}
              onChange={(e) => handleUpdate({ objective2: e.target.value })}
              placeholder="e.g., Consolidate multiple legacy DC pension pots into a modern SIPP wrapper with lower ongoing charges and automated rebalancing."
              className={`w-full p-3 text-xs rounded-xl border bg-white focus:outline-none transition leading-relaxed ${
                fieldErrors['objective2']
                  ? 'border-rose-400 focus:border-rose-500 focus:ring-2 focus:ring-rose-200'
                  : 'border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-100'
              }`}
              required
            />
          </div>

          {/* Objective 3 (Optional / Toggleable) */}
          {data.hasObjective3 && (
            <div className="space-y-1.5 pt-1 animate-in fade-in slide-in-from-top-2">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-bold text-slate-900">
                  Objective 3 <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <button
                  type="button"
                  onClick={() => handleUpdate({ hasObjective3: false, objective3: '' })}
                  className="text-xs text-rose-600 hover:text-rose-700 flex items-center gap-1 font-semibold cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Remove Objective 3</span>
                </button>
              </div>
              <textarea
                rows={2}
                value={data.objective3 || ''}
                onChange={(e) => handleUpdate({ objective3: e.target.value })}
                placeholder="e.g., Assist adult children with a £30,000 property deposit gift within the next 24 months without impacting core retirement lifestyle."
                className="w-full p-3 text-xs rounded-xl border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 bg-white focus:outline-none transition leading-relaxed"
              />
            </div>
          )}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SUBSECTION 2: RISK & INVESTMENT PREFERENCES                               */}
      {/* ========================================================================= */}
      <section className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 shadow-xs space-y-6">
        
        {/* Subsection Header */}
        <div className="flex items-center justify-between border-b border-slate-200/80 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-50 text-indigo-700 rounded-lg">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900">
                Risk &amp; Investment Preferences
              </h4>
              <p className="text-[11px] text-slate-500">
                Establish the client’s risk profile, capacity for loss, and sustainable investing criteria.
              </p>
            </div>
          </div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-md border border-indigo-200/60">
            Subsection 2 of 2
          </span>
        </div>

        {/* 1. Attitude to Risk Level (Adventurous, Dynamic, Moderate, Conservative) */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between">
            <label className="block text-xs font-bold text-slate-900">
              Attitude to Risk Level <span className="text-rose-500">* (Select 1)</span>
            </label>
            {fieldErrors['attitudeToRisk'] && (
              <span className="text-[11px] font-semibold text-rose-600 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" /> Please select an Attitude to Risk Level
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {RISK_LEVELS.map((risk) => {
              const isSelected = data.attitudeToRisk === risk.value;
              return (
                <button
                  key={risk.value}
                  type="button"
                  onClick={() => handleUpdate({ attitudeToRisk: risk.value })}
                  className={`p-4 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between gap-3 ${
                    isSelected
                      ? 'bg-indigo-50/50 border-indigo-600 ring-2 ring-indigo-600/20 shadow-xs'
                      : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/50'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className={`text-xs font-bold block ${isSelected ? 'text-indigo-900' : 'text-slate-900'}`}>
                        {risk.label}
                      </span>
                      <span className="inline-block mt-0.5 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider rounded-md bg-slate-100 text-slate-600 border border-slate-200">
                        {risk.badge}
                      </span>
                    </div>

                    {/* Tickbox Indicator */}
                    <div className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 transition ${
                      isSelected
                        ? 'bg-indigo-600 border-indigo-600 text-white'
                        : 'border-slate-300 bg-white'
                    }`}>
                      {isSelected && <CheckCircle2 className="w-3.5 h-3.5" />}
                    </div>
                  </div>

                  <p className="text-[10px] text-slate-500 leading-snug">
                    {risk.desc}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* 2. Ethical / ESG Preferences? (Yes/No with Textbox appearing if Yes) */}
        <div className="space-y-3 pt-3 border-t border-slate-100">
          <div className={`rounded-xl border transition-all p-4 bg-white ${
            fieldErrors['ethicalEsgPreferences']
              ? 'border-rose-400 bg-rose-50/20 ring-2 ring-rose-400/20'
              : data.ethicalEsgPreferences?.answered === 'yes'
              ? 'border-emerald-200 bg-emerald-50/20 shadow-xs'
              : 'border-slate-200'
          }`}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-start gap-3 flex-1">
                <div className={`p-2 rounded-lg shrink-0 mt-0.5 ${
                  data.ethicalEsgPreferences?.answered === 'yes' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'
                }`}>
                  <Leaf className="w-4 h-4" />
                </div>
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900">
                      Ethical / ESG Preferences?
                    </span>
                    {data.ethicalEsgPreferences?.answered === 'yes' && (
                      <span className="px-2 py-0.2 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                        Details Required
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-600">
                    Does the client have specific sustainability, ethical exclusions (e.g. tobacco, weapons, fossil fuels), or ESG impact investment mandates?
                  </p>
                </div>
              </div>

              {/* Yes / No Choice Buttons */}
              <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                {/* Yes Button */}
                <button
                  type="button"
                  onClick={() => {
                    handleUpdate({
                      ethicalEsgPreferences: {
                        answered: 'yes',
                        details: data.ethicalEsgPreferences?.details || ''
                      }
                    });
                  }}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
                    data.ethicalEsgPreferences?.answered === 'yes'
                      ? 'bg-emerald-600 border-emerald-600 text-white shadow-xs'
                      : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                    data.ethicalEsgPreferences?.answered === 'yes' ? 'border-white bg-white' : 'border-slate-400'
                  }`}>
                    {data.ethicalEsgPreferences?.answered === 'yes' && <div className="w-1.5 h-1.5 rounded-full bg-emerald-600" />}
                  </div>
                  <span>Yes</span>
                </button>

                {/* No Button */}
                <button
                  type="button"
                  onClick={() => {
                    handleUpdate({
                      ethicalEsgPreferences: {
                        answered: 'no',
                        details: ''
                      }
                    });
                  }}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
                    data.ethicalEsgPreferences?.answered === 'no'
                      ? 'bg-slate-700 border-slate-700 text-white shadow-xs'
                      : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                    data.ethicalEsgPreferences?.answered === 'no' ? 'border-white bg-white' : 'border-slate-400'
                  }`}>
                    {data.ethicalEsgPreferences?.answered === 'no' && <div className="w-1.5 h-1.5 rounded-full bg-slate-700" />}
                  </div>
                  <span>No</span>
                </button>
              </div>
            </div>

            {/* Textbox when Yes is selected */}
            {data.ethicalEsgPreferences?.answered === 'yes' && (
              <div className="mt-3.5 pt-3 border-t border-emerald-200/60 animate-in fade-in slide-in-from-top-1 space-y-1.5">
                <label className="block text-xs font-bold text-slate-900">
                  Ethical / ESG Mandate &amp; Exclusion Criteria <span className="text-rose-500">* (Mandatory)</span>
                </label>
                <textarea
                  rows={2}
                  value={data.ethicalEsgPreferences?.details || ''}
                  onChange={(e) => {
                    handleUpdate({
                      ethicalEsgPreferences: {
                        answered: 'yes',
                        details: e.target.value
                      }
                    });
                  }}
                  placeholder="e.g., Strict negative screening against thermal coal extraction, armaments, and tobacco; preference for Article 8/9 sustainable impact funds."
                  className={`w-full p-2.5 text-xs rounded-lg border bg-white focus:outline-none transition leading-relaxed ${
                    fieldErrors['ethicalEsgPreferences']
                      ? 'border-rose-400 focus:border-rose-500 focus:ring-2 focus:ring-rose-200 text-slate-900'
                      : 'border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 text-slate-900'
                  }`}
                  required
                />
                {fieldErrors['ethicalEsgPreferences'] && (
                  <p className="text-[11px] text-rose-600 font-semibold flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    Please specify the client’s Ethical / ESG preferences because &ldquo;Yes&rdquo; was selected.
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Completion Banner */}
      <div className="p-4 bg-emerald-50/80 border border-emerald-200 rounded-2xl flex items-start gap-3 text-emerald-950">
        <div className="p-2 bg-emerald-600 text-white rounded-xl shrink-0 mt-0.5">
          <Award className="w-4 h-4" />
        </div>
        <div className="space-y-0.5">
          <h5 className="text-xs font-bold text-emerald-950">
            Final Fact Find Sign-off &amp; Completion
          </h5>
          <p className="text-[11px] text-emerald-900 leading-relaxed">
            Completing Stage 6 finishes all 6 sections of the Client Fact Find. All objectives, risk profiles, wealth assets, and income schedules will be locked into the client’s permanent file for paraplanning suitability report generation.
          </p>
        </div>
      </div>

    </form>
  );
};
