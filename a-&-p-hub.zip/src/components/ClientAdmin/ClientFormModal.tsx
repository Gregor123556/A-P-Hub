import React, { useState, useEffect } from 'react';
import { X, UserPlus, Users, Briefcase, Calendar, PoundSterling, AlertCircle, Sparkles, TrendingUp, Percent } from 'lucide-react';
import { ClientAdminEntry, ClientCategory } from '../../types';
import { getTodayDDMMYYYY } from '../../utils/dateUtils';
import { generateStepsForCategory } from '../../data/mockClientAdmin';
import { formatPoundSterling, normalizeServiceScope } from '../../utils/currencyUtils';

interface ClientFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Omit<ClientAdminEntry, 'id' | 'createdAt' | 'updatedAt'>, existingId?: string) => Promise<void>;
  editingClient?: ClientAdminEntry | null;
  defaultCategory?: ClientCategory;
}

export const ClientFormModal: React.FC<ClientFormModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  editingClient,
  defaultCategory = 'potential'
}) => {
  const [clientName, setClientName] = useState('');
  const [category, setCategory] = useState<ClientCategory>(defaultCategory);
  const [adviserName, setAdviserName] = useState('Sam Adams');
  const [serviceType, setServiceType] = useState('Pension');
  const [estimatedValue, setEstimatedValue] = useState('');
  
  // Potential Clients specific fields
  const [potentialSelectedFund, setPotentialSelectedFund] = useState('');
  const [proposedFeeInitial, setProposedFeeInitial] = useState('3%');
  const [proposedFeeOngoing, setProposedFeeOngoing] = useState('1%');

  // Ongoing / On-Hold fields
  const [signUpDate, setSignUpDate] = useState(getTodayDDMMYYYY());
  const [targetCompletionDate, setTargetCompletionDate] = useState('');
  const [nextAction, setNextAction] = useState('Issue Client Agreement & Fee Disclosure');
  const [nextActionDueDate, setNextActionDueDate] = useState('');
  const [onHoldReason, setOnHoldReason] = useState('');
  const [moneyLanded, setMoneyLanded] = useState(false);
  const [servicingSetUp, setServicingSetUp] = useState(false);
  
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (editingClient) {
      setClientName(editingClient.clientName);
      setCategory(editingClient.category);
      setAdviserName(editingClient.adviserName || 'Sam Adams');
      setServiceType(normalizeServiceScope(editingClient.serviceType));
      setEstimatedValue(formatPoundSterling(editingClient.estimatedValue) || editingClient.estimatedValue || '');
      setPotentialSelectedFund(editingClient.potentialSelectedFund || '');
      setProposedFeeInitial(editingClient.proposedFeeInitial || '3%');
      setProposedFeeOngoing(editingClient.proposedFeeOngoing || '1%');
      setSignUpDate(editingClient.signUpDate || getTodayDDMMYYYY());
      setTargetCompletionDate(editingClient.targetCompletionDate || '');
      setNextAction(editingClient.nextAction || '');
      setNextActionDueDate(editingClient.nextActionDueDate || '');
      setOnHoldReason(editingClient.onHoldReason || '');
      setMoneyLanded(Boolean(editingClient.moneyLanded));
      setServicingSetUp(Boolean(editingClient.servicingSetUp));
      setEmail(editingClient.email || '');
      setPhone(editingClient.phone || '');
      setNotes(editingClient.notes || '');
    } else {
      setClientName('');
      setCategory(defaultCategory);
      setAdviserName('Sam Adams');
      setServiceType('Pension');
      setEstimatedValue('');
      setPotentialSelectedFund('');
      setProposedFeeInitial('3%');
      setProposedFeeOngoing('1%');
      setSignUpDate(getTodayDDMMYYYY());
      setTargetCompletionDate('');
      setNextAction(
        defaultCategory === 'potential'
          ? 'Contact Client & Record Initial Enquiry'
          : defaultCategory === 'ongoing'
          ? 'Complete AML/KYC Identity Check'
          : defaultCategory === 'onboarded'
          ? 'Confirm funds landing & configure ongoing servicing'
          : defaultCategory === 'completed'
          ? 'File completed and archived in dormant database'
          : 'Document reason for temporary pause'
      );
      setNextActionDueDate('');
      setOnHoldReason('');
      setMoneyLanded(false);
      setServicingSetUp(false);
      setEmail('');
      setPhone('');
      setNotes('');
    }
  }, [editingClient, defaultCategory, isOpen]);

  const handleEstimatedValueBlur = () => {
    if (estimatedValue.trim()) {
      setEstimatedValue(formatPoundSterling(estimatedValue));
    }
  };

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientName.trim()) return;

    try {
      setIsSubmitting(true);
      const steps = editingClient
        ? editingClient.steps
        : generateStepsForCategory(category);

      await onSubmit({
        clientName: clientName.trim(),
        category,
        adviserName: adviserName.trim(),
        serviceType: normalizeServiceScope(serviceType),
        estimatedValue: formatPoundSterling(estimatedValue),
        // Potential client fields
        potentialSelectedFund: category === 'potential' ? potentialSelectedFund.trim() : (editingClient?.potentialSelectedFund || ''),
        proposedFeeInitial: category === 'potential' ? (proposedFeeInitial.trim() || '3%') : (editingClient?.proposedFeeInitial || '3%'),
        proposedFeeOngoing: category === 'potential' ? (proposedFeeOngoing.trim() || '1%') : (editingClient?.proposedFeeOngoing || '1%'),
        // Ongoing / Onboarded / On-hold dates & actions
        signUpDate: category === 'potential' ? '' : (signUpDate.trim() || getTodayDDMMYYYY()),
        targetCompletionDate: category === 'potential' ? '' : targetCompletionDate.trim(),
        nextAction: category === 'potential' ? 'Issue Client Agreement & Fee Disclosure' : (nextAction.trim() || 'Review admin status'),
        nextActionDueDate: category === 'potential' ? '' : nextActionDueDate.trim(),
        onHoldReason: category === 'on_hold' ? onHoldReason.trim() : '',
        moneyLanded: category === 'onboarded' ? moneyLanded : Boolean(editingClient?.moneyLanded),
        servicingSetUp: category === 'onboarded' ? servicingSetUp : Boolean(editingClient?.servicingSetUp),
        email: email.trim(),
        phone: phone.trim(),
        notes: notes.trim(),
        steps
      }, editingClient?.id);

      onClose();
    } catch (err) {
      console.error('Error saving client:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl relative overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="border-b border-slate-200 p-5 bg-slate-50 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-blue-100 text-blue-700 rounded-lg">
              {editingClient ? <Users className="w-5 h-5" /> : <UserPlus className="w-5 h-5" />}
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {editingClient ? 'Edit Client Admin File' : 'Add New Client to Admin Process'}
              </h2>
              <p className="text-xs text-slate-500">
                Adams &amp; Poole Financial Services • Client Administration Workflow
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-4 text-xs text-slate-700">
          
          {/* Target List / Category Selector */}
          <div>
            <label className="block font-semibold text-slate-800 mb-1.5">
              Client Admin Category / List <span className="text-rose-500">*</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              <button
                type="button"
                onClick={() => setCategory('potential')}
                className={`py-2 px-3 rounded-lg border text-center font-medium transition ${
                  category === 'potential'
                    ? 'bg-amber-50 border-amber-300 text-amber-900 shadow-2xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                Potential
              </button>
              <button
                type="button"
                onClick={() => setCategory('ongoing')}
                className={`py-2 px-3 rounded-lg border text-center font-medium transition ${
                  category === 'ongoing'
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-900 shadow-2xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                Ongoing
              </button>
              <button
                type="button"
                onClick={() => setCategory('onboarded')}
                className={`py-2 px-3 rounded-lg border text-center font-medium transition ${
                  category === 'onboarded'
                    ? 'bg-indigo-50 border-indigo-300 text-indigo-900 shadow-2xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                Onboarded
              </button>
              <button
                type="button"
                onClick={() => setCategory('completed')}
                className={`py-2 px-3 rounded-lg border text-center font-medium transition ${
                  category === 'completed'
                    ? 'bg-teal-50 border-teal-300 text-teal-900 shadow-2xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                Completed
              </button>
              <button
                type="button"
                onClick={() => setCategory('on_hold')}
                className={`py-2 px-3 rounded-lg border text-center font-medium transition ${
                  category === 'on_hold'
                    ? 'bg-slate-100 border-slate-400 text-slate-900 shadow-2xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                On Hold
              </button>
            </div>
          </div>

          {/* Client Name & Adviser */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-800 mb-1">
                Client Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. David & Margaret Jenkins"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-800 mb-1">
                Lead Adviser <span className="text-rose-500">*</span>
              </label>
              <select
                value={adviserName}
                onChange={(e) => setAdviserName(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="Sam Adams">Sam Adams</option>
                <option value="Anthony Poole">Anthony Poole</option>
              </select>
            </div>
          </div>

          {/* Service Type & Est Value */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-800 mb-1">
                Service / Advice Scope
              </label>
              <select
                value={serviceType}
                onChange={(e) => setServiceType(normalizeServiceScope(e.target.value))}
                className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="ISA & GIA">ISA & GIA</option>
                <option value="CIB">CIB</option>
                <option value="Pension">Pension</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-800 mb-1 flex items-center justify-between">
                <span>Estimated Portfolio Value</span>
                <span className="text-[10px] text-slate-400 font-normal">GBP (£)</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-slate-500 font-semibold">
                  <span>£</span>
                </div>
                <input
                  type="text"
                  placeholder="e.g. 450,000"
                  value={estimatedValue.startsWith('£') ? estimatedValue.slice(1) : estimatedValue}
                  onChange={(e) => setEstimatedValue(e.target.value)}
                  onBlur={handleEstimatedValueBlur}
                  className="w-full bg-white border border-slate-300 rounded-lg py-2 pl-7 pr-3 text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>

          {/* POTENTIAL CLIENTS: Potential Selected Fund & Proposed Fee (Initial 3%, Ongoing 1%) */}
          {category === 'potential' && (
            <div className="space-y-3">
              {/* Potential Selected Fund */}
              <div>
                <label className="block font-semibold text-slate-800 mb-1">
                  Potential Selected Fund
                </label>
                <input
                  type="text"
                  placeholder="e.g. Vanguard LifeStrategy 60% Equity"
                  value={potentialSelectedFund}
                  onChange={(e) => setPotentialSelectedFund(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Proposed Fee (2 Subfields: Ongoing 1%, Initial 3%) */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block font-semibold text-slate-800 flex items-center gap-1.5">
                    <Percent className="w-3.5 h-3.5 text-blue-600" />
                    <span>Proposed Fee</span>
                  </label>
                  <span className="text-[10px] text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded font-medium">
                    Default: Initial 3% • Ongoing 1%
                  </span>
                </div>
                
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-slate-50/70 border border-slate-200 rounded-lg p-2.5">
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Initial Proposed Fee
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        placeholder="3%"
                        value={proposedFeeInitial}
                        onChange={(e) => setProposedFeeInitial(e.target.value)}
                        className="w-full bg-white border border-slate-300 rounded-md p-1.5 pr-6 text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      <span className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-xs pointer-events-none">
                        %
                      </span>
                    </div>
                  </div>

                  <div className="bg-slate-50/70 border border-slate-200 rounded-lg p-2.5">
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Ongoing Proposed Fee
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        placeholder="1%"
                        value={proposedFeeOngoing}
                        onChange={(e) => setProposedFeeOngoing(e.target.value)}
                        className="w-full bg-white border border-slate-300 rounded-md p-1.5 pr-6 text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      <span className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-xs pointer-events-none">
                        %
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ONGOING CLIENTS: Dates & Next Immediate Admin Action */}
          {category === 'ongoing' && (
            <>
              {/* Sign Up Date & Target Completion Date */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-800 mb-1">
                    Signed / Engagement Date (DD-MM-YYYY)
                  </label>
                  <input
                    type="text"
                    placeholder="DD-MM-YYYY"
                    value={signUpDate}
                    onChange={(e) => setSignUpDate(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 font-mono focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-800 mb-1">
                    Target Completion Date (DD-MM-YYYY)
                  </label>
                  <input
                    type="text"
                    placeholder="DD-MM-YYYY"
                    value={targetCompletionDate}
                    onChange={(e) => setTargetCompletionDate(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 font-mono focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* Next Immediate Action & Due Date */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block font-semibold text-slate-800 mb-1">
                    Next Immediate Admin Action
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Complete AML verification & dispatch LoAs"
                    value={nextAction}
                    onChange={(e) => setNextAction(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-800 mb-1">
                    Action Due Date
                  </label>
                  <input
                    type="text"
                    placeholder="DD-MM-YYYY"
                    value={nextActionDueDate}
                    onChange={(e) => setNextActionDueDate(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 font-mono focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            </>
          )}

          {/* ONBOARDED CLIENTS: Money Landed? and Servicing Set Up? */}
          {category === 'onboarded' && (
            <div className="p-3.5 bg-indigo-50/70 border border-indigo-200 rounded-xl space-y-3">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-indigo-600" />
                <h4 className="font-bold text-indigo-950 text-xs">Onboarded Handover Checklist</h4>
              </div>
              <p className="text-[11px] text-indigo-800">
                All ongoing administration stages are complete. Verify client funds and servicing setup below:
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <label className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition ${
                  moneyLanded ? 'bg-white border-emerald-300 shadow-2xs' : 'bg-white/80 border-slate-200 hover:border-slate-300'
                }`}>
                  <input
                    type="checkbox"
                    checked={moneyLanded}
                    onChange={(e) => setMoneyLanded(e.target.checked)}
                    className="mt-0.5 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                  />
                  <div>
                    <span className="font-semibold text-slate-900 block text-xs">Money Landed?</span>
                    <span className="text-[11px] text-slate-500 block mt-0.5">
                      Confirm client funds / transfer proceeds have arrived in destination accounts.
                    </span>
                  </div>
                </label>

                <label className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition ${
                  servicingSetUp ? 'bg-white border-emerald-300 shadow-2xs' : 'bg-white/80 border-slate-200 hover:border-slate-300'
                }`}>
                  <input
                    type="checkbox"
                    checked={servicingSetUp}
                    onChange={(e) => setServicingSetUp(e.target.checked)}
                    className="mt-0.5 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                  />
                  <div>
                    <span className="font-semibold text-slate-900 block text-xs">Servicing Set Up?</span>
                    <span className="text-[11px] text-slate-500 block mt-0.5">
                      Confirm ongoing platform fees, adviser remuneration & review schedules are activated.
                    </span>
                  </div>
                </label>
              </div>
            </div>
          )}

          {/* ON HOLD CLIENTS: Reason for Hold & Next Action */}
          {category === 'on_hold' && (
            <div className="space-y-3">
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl space-y-1">
                <label className="block font-semibold text-amber-900">
                  Reason for Hold <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Awaiting Grant of Probate / Client abroad / Tax advice pending"
                  value={onHoldReason}
                  onChange={(e) => setOnHoldReason(e.target.value)}
                  className="w-full bg-white border border-amber-300 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block font-semibold text-slate-800 mb-1">
                    Next Review Action
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Contact probate solicitor for estate update"
                    value={nextAction}
                    onChange={(e) => setNextAction(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-800 mb-1">
                    Review Due Date
                  </label>
                  <input
                    type="text"
                    placeholder="DD-MM-YYYY"
                    value={nextActionDueDate}
                    onChange={(e) => setNextActionDueDate(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 font-mono focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Contact Details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-800 mb-1">
                Client Email
              </label>
              <input
                type="email"
                placeholder="client@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-800 mb-1">
                Client Phone
              </label>
              <input
                type="tel"
                placeholder="07700 900123"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block font-semibold text-slate-800 mb-1">
              Case Admin Notes &amp; Objectives
            </label>
            <textarea
              rows={2}
              placeholder="Record details of discovery discussions, platform preferences, or specific provider transfers..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Footer actions */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-3 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition shadow-xs flex items-center gap-2"
            >
              {isSubmitting ? 'Saving...' : editingClient ? 'Save Changes' : 'Create Client Record'}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
