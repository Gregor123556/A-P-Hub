import React, { useState, useEffect } from 'react';
import { 
  Users, 
  UserPlus, 
  CheckCircle2, 
  Search, 
  ChevronDown,
  ChevronUp,
  ChevronRight,
  Sparkles,
  Edit3, 
  Trash2, 
  FileCheck, 
  PauseCircle, 
  FolderOpen,
  TrendingUp,
  User,
  AlertTriangle,
  X,
  Loader2,
  BadgeCheck,
  CheckSquare,
  Square,
  Clock,
  Landmark,
  Settings,
  Archive,
  FileSpreadsheet,
  ArrowRight
} from 'lucide-react';
import { ClientAdminEntry, ClientCategory, LoAEntry } from '../../types';
import { ClientStepProgressModal } from './ClientStepProgressModal';
import { ClientFormModal } from './ClientFormModal';
import { FactFindModal } from './FactFindModal';
import { 
  createClient, 
  updateClient, 
  deleteClient, 
  moveClientCategory,
  updateOnboardedChecklist
} from '../../services/clientAdminService';
import { formatPoundSterling, normalizeServiceScope, parsePoundValue } from '../../utils/currencyUtils';

interface ClientAdminDashboardProps {
  clients: ClientAdminEntry[];
  loas: LoAEntry[];
  onRefresh?: () => void;
  selectedCategory?: ClientCategory;
  onSelectCategory?: (category: ClientCategory) => void;
}

type SortField = 'clientName' | 'category' | 'serviceType' | 'adviserName' | 'estimatedValue' | 'progress';

const LOCAL_STORAGE_CATEGORY_KEY = 'adams_poole_client_admin_selected_stage';

export const ClientAdminDashboard: React.FC<ClientAdminDashboardProps> = ({
  clients,
  loas,
  onRefresh,
  selectedCategory: controlledCategory,
  onSelectCategory
}) => {
  // Always maintain an active single stage ('potential' | 'ongoing' | 'onboarded' | 'completed' | 'on_hold')
  // Initialize from props, or localStorage, or default to 'potential'
  const [internalCategory, setInternalCategory] = useState<ClientCategory>(() => {
    if (controlledCategory) return controlledCategory;
    const saved = localStorage.getItem(LOCAL_STORAGE_CATEGORY_KEY);
    if (saved === 'potential' || saved === 'ongoing' || saved === 'onboarded' || saved === 'completed' || saved === 'on_hold') {
      return saved as ClientCategory;
    }
    return 'potential';
  });

  const activeCategory: ClientCategory = controlledCategory || internalCategory;

  const handleCategoryChange = (category: ClientCategory) => {
    // Only allow setting a valid single stage
    if (category === 'potential' || category === 'ongoing' || category === 'onboarded' || category === 'completed' || category === 'on_hold') {
      setInternalCategory(category);
      try {
        localStorage.setItem(LOCAL_STORAGE_CATEGORY_KEY, category);
      } catch (e) {
        console.error('Failed to save selected stage preference to localStorage', e);
      }
      if (onSelectCategory) {
        onSelectCategory(category);
      }
    }
  };

  // Sync internal state if controlledCategory changes from outside
  useEffect(() => {
    if (controlledCategory && controlledCategory !== internalCategory) {
      setInternalCategory(controlledCategory);
      try {
        localStorage.setItem(LOCAL_STORAGE_CATEGORY_KEY, controlledCategory);
      } catch (e) {
        console.error('Failed to save selected stage preference to localStorage', e);
      }
    }
  }, [controlledCategory]);

  const [selectedServiceType, setSelectedServiceType] = useState<string>('ALL');
  const [selectedAdviser, setSelectedAdviser] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<SortField>('clientName');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Modals state
  const [selectedStepClient, setSelectedStepClient] = useState<ClientAdminEntry | null>(null);
  const [selectedFactFindClient, setSelectedFactFindClient] = useState<ClientAdminEntry | null>(null);
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<ClientAdminEntry | null>(null);

  // In-app Delete & Hold Confirmation Modals (Replaces window.confirm & window.prompt for sandboxed iframes)
  const [deleteModal, setDeleteModal] = useState<{
    isOpen: boolean;
    id: string;
    name: string;
    isBatch?: boolean;
  }>({
    isOpen: false,
    id: '',
    name: '',
    isBatch: false
  });
  const [isDeleting, setIsDeleting] = useState(false);

  const [holdModal, setHoldModal] = useState<{
    isOpen: boolean;
    clientId?: string;
    clientName?: string;
    isBatch?: boolean;
  }>({
    isOpen: false
  });
  const [holdReasonInput, setHoldReasonInput] = useState('Awaiting third-party documentation / probate');
  const [defaultCategoryForNew, setDefaultCategoryForNew] = useState<ClientCategory>(activeCategory);

  // Counts across all stages
  const potentialClients = clients.filter(c => c.category === 'potential');
  const ongoingClients = clients.filter(c => c.category === 'ongoing');
  const onboardedClients = clients.filter(c => c.category === 'onboarded');
  const completedClients = clients.filter(c => c.category === 'completed');
  const onHoldClients = clients.filter(c => c.category === 'on_hold');

  // Fast toggle for Onboarded table checkboxes (Money Landed? / Servicing Set Up?)
  // Auto-transitions to 'completed' & feeds into Servicing pipeline when both are checked
  const handleToggleMoneyLanded = async (client: ClientAdminEntry) => {
    const nextVal = !client.moneyLanded;
    try {
      await updateOnboardedChecklist(client.id, {
        moneyLanded: nextVal
      });
    } catch (e) {
      console.error('Failed to toggle money landed:', e);
    }
  };

  const handleToggleServicingSetUp = async (client: ClientAdminEntry) => {
    const nextVal = !client.servicingSetUp;
    try {
      await updateOnboardedChecklist(client.id, {
        servicingSetUp: nextVal
      });
    } catch (e) {
      console.error('Failed to toggle servicing set up:', e);
    }
  };

  // Helper for LoAs linked to client
  const getLinkedLoAs = (clientName: string) => {
    const cleanName = clientName.toLowerCase().trim();
    return loas.filter(l => {
      const lName = l.clientName.toLowerCase().trim();
      return lName.includes(cleanName) || cleanName.includes(lName);
    });
  };

  // Filter clients strictly by the active single stage + search + scope + adviser
  const filteredClients = clients.filter(client => {
    // Strictly must match the current active single stage
    if (client.category !== activeCategory) {
      return false;
    }

    const term = searchTerm.toLowerCase();
    const normalizedScope = normalizeServiceScope(client.serviceType);
    const matchesSearch = 
      client.clientName.toLowerCase().includes(term) ||
      normalizedScope.toLowerCase().includes(term) ||
      client.serviceType.toLowerCase().includes(term) ||
      (client.adviserName && client.adviserName.toLowerCase().includes(term)) ||
      (client.potentialSelectedFund && client.potentialSelectedFund.toLowerCase().includes(term)) ||
      (client.nextAction && client.nextAction.toLowerCase().includes(term)) ||
      (client.estimatedValue && client.estimatedValue.toLowerCase().includes(term)) ||
      (client.email && client.email.toLowerCase().includes(term)) ||
      (client.notes && client.notes.toLowerCase().includes(term));

    const matchesService = 
      selectedServiceType === 'ALL' || normalizedScope === selectedServiceType || client.serviceType === selectedServiceType;

    const matchesAdviser = 
      selectedAdviser === 'ALL' || client.adviserName === selectedAdviser;

    return matchesSearch && matchesService && matchesAdviser;
  });

  // Calculate progress %
  const getClientProgress = (client: ClientAdminEntry) => {
    const total = client.steps?.length || 0;
    const completed = client.steps?.filter(s => s.isCompleted).length || 0;
    const percent = total > 0 ? Math.round((completed / total) * 100) : 0;
    return { completed, total, percent };
  };

  // Sort clients
  const sortedClients = [...filteredClients].sort((a, b) => {
    if (sortField === 'progress') {
      const progA = getClientProgress(a).percent;
      const progB = getClientProgress(b).percent;
      return sortOrder === 'asc' ? progA - progB : progB - progA;
    }

    if (sortField === 'estimatedValue') {
      const valA = parsePoundValue(a.estimatedValue);
      const valB = parsePoundValue(b.estimatedValue);
      return sortOrder === 'asc' ? valA - valB : valB - valA;
    }

    if (sortField === 'serviceType') {
      const scopeA = normalizeServiceScope(a.serviceType);
      const scopeB = normalizeServiceScope(b.serviceType);
      return sortOrder === 'asc' ? scopeA.localeCompare(scopeB) : scopeB.localeCompare(scopeA);
    }

    const aVal = (a[sortField] || '').toString().toLowerCase();
    const bVal = (b[sortField] || '').toString().toLowerCase();
    return sortOrder === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
  });

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  // Selection handlers
  const toggleSelectAll = () => {
    if (selectedIds.length === sortedClients.length && sortedClients.length > 0) {
      setSelectedIds([]);
    } else {
      setSelectedIds(sortedClients.map(c => c.id));
    }
  };

  const toggleSelectOne = (id: string) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  // Batch actions
  const handleBatchCategoryUpdate = async (newCat: ClientCategory) => {
    if (newCat === 'on_hold') {
      setHoldModal({
        isOpen: true,
        isBatch: true
      });
      return;
    }

    for (const id of selectedIds) {
      await moveClientCategory(id, newCat);
    }
    setSelectedIds([]);
  };

  const handleOpenBatchDelete = () => {
    setDeleteModal({
      isOpen: true,
      id: '',
      name: `${selectedIds.length} selected client files`,
      isBatch: true
    });
  };

  const handleConfirmDelete = async () => {
    setIsDeleting(true);
    try {
      if (deleteModal.isBatch) {
        for (const id of selectedIds) {
          await deleteClient(id);
        }
        setSelectedIds([]);
      } else if (deleteModal.id) {
        await deleteClient(deleteModal.id);
        setSelectedIds(prev => prev.filter(i => i !== deleteModal.id));
      }
    } catch (err) {
      console.error('Failed to delete client(s):', err);
    } finally {
      setIsDeleting(false);
      setDeleteModal({ isOpen: false, id: '', name: '', isBatch: false });
    }
  };

  const handleConfirmHoldReason = async () => {
    const reason = holdReasonInput.trim() || 'Placed on hold by adviser';
    if (holdModal.isBatch) {
      for (const id of selectedIds) {
        await moveClientCategory(id, 'on_hold', reason);
      }
      setSelectedIds([]);
    } else if (holdModal.clientId) {
      await moveClientCategory(holdModal.clientId, 'on_hold', reason);
    }
    setHoldModal({ isOpen: false });
  };

  // Handlers
  const handleSaveClient = async (
    data: Omit<ClientAdminEntry, 'id' | 'createdAt' | 'updatedAt'>,
    existingId?: string
  ) => {
    if (existingId) {
      await updateClient(existingId, data);
    } else {
      await createClient(data);
    }
  };

  const handleDelete = (id: string, name: string) => {
    setDeleteModal({
      isOpen: true,
      id,
      name,
      isBatch: false
    });
  };

  const handleMoveCategory = async (clientId: string, newCat: ClientCategory) => {
    if (newCat === 'on_hold') {
      const client = clients.find(c => c.id === clientId);
      setHoldModal({
        isOpen: true,
        clientId,
        clientName: client?.clientName || 'Client',
        isBatch: false
      });
    } else {
      await moveClientCategory(clientId, newCat);
    }
  };

  // Scope Badge Styling
  const getScopeBadge = (scope: string) => {
    const normalized = normalizeServiceScope(scope);
    switch (normalized) {
      case 'ISA & GIA':
        return 'bg-blue-50 text-blue-800 border-blue-200';
      case 'CIB':
        return 'bg-purple-50 text-purple-800 border-purple-200';
      case 'Pension':
      default:
        return 'bg-amber-50 text-amber-800 border-amber-200';
    }
  };

  // Category Badge / Select Styling
  const getCategoryBadge = (category: ClientCategory) => {
    switch (category) {
      case 'potential':
        return 'bg-amber-100 text-amber-900 border-amber-300';
      case 'ongoing':
        return 'bg-emerald-100 text-emerald-900 border-emerald-300';
      case 'onboarded':
        return 'bg-indigo-100 text-indigo-900 border-indigo-300';
      case 'completed':
        return 'bg-teal-100 text-teal-900 border-teal-300';
      case 'on_hold':
      default:
        return 'bg-slate-100 text-slate-800 border-slate-300';
    }
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      
      {/* 5 Metric Cards at Top for Stage Selection (Strictly 1 stage is always active; cannot be deselected) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5">
        
        {/* 1. Potential Clients */}
        <button 
          type="button"
          onClick={() => handleCategoryChange('potential')}
          className={`p-3.5 rounded-xl border transition-all text-left w-full cursor-pointer focus:outline-none ${
            activeCategory === 'potential'
              ? 'bg-amber-50/80 border-amber-400 ring-2 ring-amber-400 shadow-sm'
              : 'bg-white border-slate-200 hover:border-slate-300 shadow-2xs opacity-80 hover:opacity-100'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <span className={`w-2.5 h-2.5 rounded-full ${activeCategory === 'potential' ? 'bg-amber-600 ring-4 ring-amber-200' : 'bg-amber-400'}`} />
              <p className="text-xs font-bold text-amber-900 uppercase tracking-wider">Potential</p>
            </div>
            <span className={`p-1.5 rounded-lg ${activeCategory === 'potential' ? 'bg-amber-200 text-amber-900 font-bold' : 'bg-amber-100 text-amber-700'}`}>
              <Users className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-xl font-bold text-slate-900">{potentialClients.length}</span>
            <span className="text-[11px] text-slate-500 font-medium truncate">Fact Find Leads</span>
          </div>
          <p className="text-[11px] text-slate-600 mt-1 line-clamp-2">
            Client Fact Find &amp; discovery process.
          </p>
        </button>

        {/* 2. Ongoing Clients */}
        <button 
          type="button"
          onClick={() => handleCategoryChange('ongoing')}
          className={`p-3.5 rounded-xl border transition-all text-left w-full cursor-pointer focus:outline-none ${
            activeCategory === 'ongoing'
              ? 'bg-emerald-50/80 border-emerald-400 ring-2 ring-emerald-400 shadow-sm'
              : 'bg-white border-slate-200 hover:border-slate-300 shadow-2xs opacity-80 hover:opacity-100'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <span className={`w-2.5 h-2.5 rounded-full ${activeCategory === 'ongoing' ? 'bg-emerald-600 ring-4 ring-emerald-200' : 'bg-emerald-400'}`} />
              <p className="text-xs font-bold text-emerald-900 uppercase tracking-wider">Ongoing</p>
            </div>
            <span className={`p-1.5 rounded-lg ${activeCategory === 'ongoing' ? 'bg-emerald-200 text-emerald-900 font-bold' : 'bg-emerald-100 text-emerald-700'}`}>
              <CheckCircle2 className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-xl font-bold text-slate-900">{ongoingClients.length}</span>
            <span className="text-[11px] text-slate-500 font-medium truncate">Active Process</span>
          </div>
          <p className="text-[11px] text-slate-600 mt-1 line-clamp-2">
            Active AML, LoAs, advice reports &amp; execution.
          </p>
        </button>

        {/* 3. Onboarded */}
        <button 
          type="button"
          onClick={() => handleCategoryChange('onboarded')}
          className={`p-3.5 rounded-xl border transition-all text-left w-full cursor-pointer focus:outline-none ${
            activeCategory === 'onboarded'
              ? 'bg-indigo-50/80 border-indigo-400 ring-2 ring-indigo-400 shadow-sm'
              : 'bg-white border-slate-200 hover:border-slate-300 shadow-2xs opacity-80 hover:opacity-100'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <span className={`w-2.5 h-2.5 rounded-full ${activeCategory === 'onboarded' ? 'bg-indigo-600 ring-4 ring-indigo-200' : 'bg-indigo-400'}`} />
              <p className="text-xs font-bold text-indigo-900 uppercase tracking-wider">Onboarded</p>
            </div>
            <span className={`p-1.5 rounded-lg ${activeCategory === 'onboarded' ? 'bg-indigo-200 text-indigo-900 font-bold' : 'bg-indigo-100 text-indigo-700'}`}>
              <BadgeCheck className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-xl font-bold text-slate-900">{onboardedClients.length}</span>
            <span className="text-[11px] text-slate-500 font-medium truncate">Checklist Handover</span>
          </div>
          <p className="text-[11px] text-slate-600 mt-1 line-clamp-2">
            Track Money Landed &amp; Servicing Setup.
          </p>
        </button>

        {/* 4. Completed (Dormant Database for Complete Files) */}
        <button 
          type="button"
          onClick={() => handleCategoryChange('completed')}
          className={`p-3.5 rounded-xl border transition-all text-left w-full cursor-pointer focus:outline-none ${
            activeCategory === 'completed'
              ? 'bg-teal-50/80 border-teal-400 ring-2 ring-teal-400 shadow-sm'
              : 'bg-white border-slate-200 hover:border-slate-300 shadow-2xs opacity-80 hover:opacity-100'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <span className={`w-2.5 h-2.5 rounded-full ${activeCategory === 'completed' ? 'bg-teal-600 ring-4 ring-teal-200' : 'bg-teal-400'}`} />
              <p className="text-xs font-bold text-teal-900 uppercase tracking-wider">Completed</p>
            </div>
            <span className={`p-1.5 rounded-lg ${activeCategory === 'completed' ? 'bg-teal-200 text-teal-900 font-bold' : 'bg-teal-100 text-teal-700'}`}>
              <Archive className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-xl font-bold text-slate-900">{completedClients.length}</span>
            <span className="text-[11px] text-slate-500 font-medium truncate">Dormant Database</span>
          </div>
          <p className="text-[11px] text-slate-600 mt-1 line-clamp-2">
            Complete files archived • Active in Servicing.
          </p>
        </button>

        {/* 5. On Hold */}
        <button 
          type="button"
          onClick={() => handleCategoryChange('on_hold')}
          className={`p-3.5 rounded-xl border transition-all text-left w-full cursor-pointer focus:outline-none ${
            activeCategory === 'on_hold'
              ? 'bg-slate-100 border-slate-500 ring-2 ring-slate-400 shadow-sm'
              : 'bg-white border-slate-200 hover:border-slate-300 shadow-2xs opacity-80 hover:opacity-100'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <span className={`w-2.5 h-2.5 rounded-full ${activeCategory === 'on_hold' ? 'bg-slate-700 ring-4 ring-slate-300' : 'bg-slate-400'}`} />
              <p className="text-xs font-bold text-slate-800 uppercase tracking-wider">On Hold</p>
            </div>
            <span className={`p-1.5 rounded-lg ${activeCategory === 'on_hold' ? 'bg-slate-300 text-slate-900 font-bold' : 'bg-slate-200 text-slate-700'}`}>
              <PauseCircle className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-xl font-bold text-slate-900">{onHoldClients.length}</span>
            <span className="text-[11px] text-slate-500 font-medium truncate">Paused Files</span>
          </div>
          <p className="text-[11px] text-slate-600 mt-1 line-clamp-2">
            Paused for probate grants or tax advice.
          </p>
        </button>

      </div>

      {/* Main Table Container (Mirrors LoA Dashboard Table) */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden flex flex-col">
        
        {/* Control & Filter Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-white space-y-4">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            
            {/* Search Box */}
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                placeholder={`Search ${activeCategory === 'potential' ? 'potential' : activeCategory === 'ongoing' ? 'ongoing' : activeCategory === 'onboarded' ? 'onboarded' : activeCategory === 'completed' ? 'completed' : 'on hold'} clients...`}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg py-2 pl-9 pr-4 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition"
              />
            </div>

            {/* Filters & Actions */}
            <div className="flex flex-wrap items-center gap-2 text-xs">
              
              {/* Category / Stage Selector Dropdown (Strictly 1 stage option; no "ALL" option) */}
              <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
                <span className="text-slate-500 font-medium">Viewing Stage:</span>
                <select
                  value={activeCategory}
                  onChange={(e) => handleCategoryChange(e.target.value as ClientCategory)}
                  className="bg-transparent text-slate-900 focus:outline-none cursor-pointer font-bold"
                >
                  <option value="potential">Potential ({potentialClients.length})</option>
                  <option value="ongoing">Ongoing ({ongoingClients.length})</option>
                  <option value="onboarded">Onboarded ({onboardedClients.length})</option>
                  <option value="completed">Completed ({completedClients.length})</option>
                  <option value="on_hold">On Hold ({onHoldClients.length})</option>
                </select>
              </div>

              {/* Scope Filter */}
              <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
                <span className="text-slate-500 font-medium">Scope:</span>
                <select
                  value={selectedServiceType}
                  onChange={(e) => setSelectedServiceType(e.target.value)}
                  className="bg-transparent text-slate-800 focus:outline-none cursor-pointer font-medium"
                >
                  <option value="ALL">All Scopes</option>
                  <option value="ISA & GIA">ISA &amp; GIA</option>
                  <option value="CIB">CIB</option>
                  <option value="Pension">Pension</option>
                </select>
              </div>

              {/* Adviser Filter */}
              <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
                <span className="text-slate-500 font-medium">Adviser:</span>
                <select
                  value={selectedAdviser}
                  onChange={(e) => setSelectedAdviser(e.target.value)}
                  className="bg-transparent text-slate-800 focus:outline-none cursor-pointer font-medium"
                >
                  <option value="ALL">All Advisers</option>
                  <option value="Sam Adams">Sam Adams</option>
                  <option value="Anthony Poole">Anthony Poole</option>
                </select>
              </div>

              <div className="h-4 w-px bg-slate-200 mx-1 hidden sm:block" />

              {/* Add Client Button */}
              <button
                onClick={() => {
                  setEditingClient(null);
                  setDefaultCategoryForNew(activeCategory);
                  setIsFormModalOpen(true);
                }}
                className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition flex items-center gap-1.5 shadow-2xs"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>+ Add Client</span>
              </button>

            </div>
          </div>

          {/* Batch Selection Action Bar (Matches LoATable batch action bar) */}
          {selectedIds.length > 0 && (
            <div className="p-2.5 bg-blue-50 border border-blue-200 rounded-lg flex flex-wrap items-center justify-between gap-2 text-xs">
              <span className="text-blue-900 font-semibold px-2">
                {selectedIds.length} client{selectedIds.length > 1 ? 's' : ''} selected
              </span>
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-slate-600 font-medium">Move Selected to:</span>
                {activeCategory !== 'ongoing' && (
                  <button
                    onClick={() => handleBatchCategoryUpdate('ongoing')}
                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-medium transition"
                  >
                    Ongoing
                  </button>
                )}
                {activeCategory !== 'potential' && (
                  <button
                    onClick={() => handleBatchCategoryUpdate('potential')}
                    className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded font-medium transition"
                  >
                    Potential
                  </button>
                )}
                {activeCategory !== 'onboarded' && (
                  <button
                    onClick={() => handleBatchCategoryUpdate('onboarded')}
                    className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded font-medium transition"
                  >
                    Onboarded
                  </button>
                )}
                {activeCategory !== 'completed' && (
                  <button
                    onClick={() => handleBatchCategoryUpdate('completed')}
                    className="px-2.5 py-1 bg-teal-600 hover:bg-teal-700 text-white rounded font-medium transition"
                  >
                    Completed
                  </button>
                )}
                {activeCategory !== 'on_hold' && (
                  <button
                    onClick={() => handleBatchCategoryUpdate('on_hold')}
                    className="px-2.5 py-1 bg-slate-600 hover:bg-slate-700 text-white rounded font-medium transition"
                  >
                    On Hold
                  </button>
                )}

                <div className="h-4 w-px bg-blue-200 mx-1 hidden sm:block" />

                <button
                  onClick={handleOpenBatchDelete}
                  className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded font-medium transition flex items-center gap-1.5 shadow-2xs cursor-pointer"
                  title="Bulk delete selected clients"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete Selected</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Content Area: Standard Row-based Table View (Mirrors LoATable) */}
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200 text-left">
            <thead className="bg-slate-50">
              <tr>
                {/* Select All Checkbox */}
                <th className="px-4 py-3.5 w-10 text-center">
                  <input
                    type="checkbox"
                    checked={selectedIds.length === sortedClients.length && sortedClients.length > 0}
                    onChange={toggleSelectAll}
                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                </th>

                {/* Client Name */}
                <th 
                  className="px-5 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider cursor-pointer hover:text-slate-800"
                  onClick={() => toggleSort('clientName')}
                >
                  <div className="flex items-center gap-1">
                    <span>Client Name</span>
                    {sortField === 'clientName' && (sortOrder === 'asc' ? <ChevronUp className="w-3.5 h-3.5 text-blue-600" /> : <ChevronDown className="w-3.5 h-3.5 text-blue-600" />)}
                  </div>
                </th>

                {/* Stage / Status */}
                <th 
                  className="px-4 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider text-center cursor-pointer hover:text-slate-800"
                  onClick={() => toggleSort('category')}
                >
                  <div className="flex items-center justify-center gap-1">
                    <span>Stage</span>
                    {sortField === 'category' && (sortOrder === 'asc' ? <ChevronUp className="w-3.5 h-3.5 text-blue-600" /> : <ChevronDown className="w-3.5 h-3.5 text-blue-600" />)}
                  </div>
                </th>

                {/* Scope */}
                <th 
                  className="px-4 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider cursor-pointer hover:text-slate-800"
                  onClick={() => toggleSort('serviceType')}
                >
                  <div className="flex items-center gap-1">
                    <span>Service Scope</span>
                    {sortField === 'serviceType' && (sortOrder === 'asc' ? <ChevronUp className="w-3.5 h-3.5 text-blue-600" /> : <ChevronDown className="w-3.5 h-3.5 text-blue-600" />)}
                  </div>
                </th>

                {/* Assigned Adviser */}
                <th 
                  className="px-4 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider cursor-pointer hover:text-slate-800"
                  onClick={() => toggleSort('adviserName')}
                >
                  <div className="flex items-center gap-1">
                    <span>Adviser</span>
                    {sortField === 'adviserName' && (sortOrder === 'asc' ? <ChevronUp className="w-3.5 h-3.5 text-blue-600" /> : <ChevronDown className="w-3.5 h-3.5 text-blue-600" />)}
                  </div>
                </th>

                {/* Est. Portfolio Value */}
                <th 
                  className="px-4 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider cursor-pointer hover:text-slate-800"
                  onClick={() => toggleSort('estimatedValue')}
                >
                  <div className="flex items-center gap-1">
                    <span>Est. Portfolio</span>
                    {sortField === 'estimatedValue' && (sortOrder === 'asc' ? <ChevronUp className="w-3.5 h-3.5 text-blue-600" /> : <ChevronDown className="w-3.5 h-3.5 text-blue-600" />)}
                  </div>
                </th>

                {/* Key Specifics: Fund & Fee / Next Action / Hold Reason / Onboarded Handover / Completed Archived */}
                <th className="px-5 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  {activeCategory === 'potential' 
                    ? 'Proposed Fund & Fees' 
                    : activeCategory === 'ongoing' 
                    ? 'Next Step & Key Dates' 
                    : activeCategory === 'onboarded'
                    ? 'Onboarded Status & Handover'
                    : activeCategory === 'completed'
                    ? 'Completed Status & Servicing'
                    : 'Hold Reason & Review Date'}
                </th>

                {/* Steps Progress or Onboarded Checkboxes or Fact Find */}
                {activeCategory === 'onboarded' ? (
                  <>
                    <th className="px-4 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider text-center">
                      Money Landed?
                    </th>
                    <th className="px-4 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider text-center">
                      Servicing Set Up?
                    </th>
                  </>
                ) : activeCategory === 'potential' ? (
                  <th className="px-4 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider text-center">
                    Client Fact Find
                  </th>
                ) : (
                  <th 
                    className="px-4 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider cursor-pointer hover:text-slate-800"
                    onClick={() => toggleSort('progress')}
                  >
                    <div className="flex items-center gap-1">
                      <span>Admin Steps</span>
                      {sortField === 'progress' && (sortOrder === 'asc' ? <ChevronUp className="w-3.5 h-3.5 text-blue-600" /> : <ChevronDown className="w-3.5 h-3.5 text-blue-600" />)}
                    </div>
                  </th>
                )}

                {/* Actions */}
                <th className="px-5 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider text-right">
                  Actions
                </th>
              </tr>
            </thead>
            
            <tbody className="bg-white divide-y divide-slate-200">
              {sortedClients.length === 0 ? (
                <tr>
                  <td colSpan={activeCategory === 'onboarded' ? 10 : 9} className="py-12 text-center text-slate-400">
                    <FolderOpen className="w-8 h-8 mx-auto mb-2 opacity-40 text-slate-400" />
                    <p className="font-medium text-slate-600">
                      No {activeCategory === 'potential' ? 'potential' : activeCategory === 'ongoing' ? 'ongoing' : activeCategory === 'onboarded' ? 'onboarded' : activeCategory === 'completed' ? 'completed' : 'on hold'} client files found.
                    </p>
                    <p className="text-xs text-slate-400 mt-1">
                      Try adjusting the scope or adviser filter, or clear your search terms.
                    </p>
                  </td>
                </tr>
              ) : (
                sortedClients.map((client) => {
                  const isSelected = selectedIds.includes(client.id);
                  const { completed, total, percent } = getClientProgress(client);
                  const linkedLoAs = getLinkedLoAs(client.clientName);

                  return (
                    <tr 
                      key={client.id}
                      className={`hover:bg-slate-50/80 transition-colors ${isSelected ? 'bg-blue-50/40' : ''}`}
                    >
                      {/* Select Checkbox */}
                      <td className="px-4 py-4 whitespace-nowrap text-center">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleSelectOne(client.id)}
                          className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                        />
                      </td>

                      {/* Client Name & Contact */}
                      <td className="px-5 py-4 whitespace-nowrap">
                        <div className="flex flex-col">
                          <span 
                            className="font-semibold text-slate-900 text-sm hover:text-blue-600 cursor-pointer" 
                            onClick={() => {
                              if (client.category === 'potential') {
                                setSelectedFactFindClient(client);
                              } else {
                                setSelectedStepClient(client);
                              }
                            }}
                          >
                            {client.clientName || 'Client'}
                          </span>
                          <div className="flex items-center gap-2 flex-wrap mt-0.5">
                            {(client.email || client.phone) && (
                              <span className="text-[11px] text-slate-500 flex items-center gap-1.5">
                                {client.email && <span>{client.email}</span>}
                                {client.email && client.phone && <span>•</span>}
                                {client.phone && <span>{client.phone}</span>}
                              </span>
                            )}
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedFactFindClient(client);
                              }}
                              className="inline-flex items-center gap-1 text-[11px] text-blue-600 hover:text-blue-800 hover:underline font-medium cursor-pointer"
                              title="View or edit Fact Find data"
                            >
                              <FileSpreadsheet className="w-3 h-3 text-blue-500" />
                              <span>View Fact Find {client.factFind?.status === 'completed' ? '(Done)' : ''}</span>
                            </button>
                          </div>
                        </div>
                      </td>

                      {/* Stage / Category Interactive Dropdown Pill */}
                      <td className="px-4 py-4 whitespace-nowrap text-center">
                        <select
                          value={client.category}
                          onChange={(e) => handleMoveCategory(client.id, e.target.value as ClientCategory)}
                          className={`px-2.5 py-1 text-xs font-semibold rounded-full border cursor-pointer focus:outline-none transition ${getCategoryBadge(client.category)}`}
                        >
                          <option value="potential" className="bg-white text-amber-900">Potential</option>
                          <option value="ongoing" className="bg-white text-emerald-900">Ongoing</option>
                          <option value="onboarded" className="bg-white text-indigo-900">Onboarded</option>
                          <option value="completed" className="bg-white text-teal-900">Completed</option>
                          <option value="on_hold" className="bg-white text-slate-800">On Hold</option>
                        </select>
                      </td>

                      {/* Service Scope */}
                      <td className="px-4 py-4 whitespace-nowrap text-sm">
                        <span className={`px-2.5 py-0.5 rounded text-xs font-semibold border ${getScopeBadge(client.serviceType)}`}>
                          {normalizeServiceScope(client.serviceType)}
                        </span>
                      </td>

                      {/* Assigned Adviser */}
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-slate-700 font-medium">
                        <div className="flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-slate-400" />
                          <span>{client.adviserName || 'Sam Adams'}</span>
                        </div>
                      </td>

                      {/* Est. Portfolio */}
                      <td className="px-4 py-4 whitespace-nowrap text-sm font-semibold text-slate-900">
                        {client.estimatedValue ? (
                          <span>{formatPoundSterling(client.estimatedValue)}</span>
                        ) : (
                          <span className="text-slate-400 font-normal italic text-xs">—</span>
                        )}
                      </td>

                      {/* Key Particulars / Fund & Fee / Next Action / Hold Reason / Onboarded Handover / Completed Archived */}
                      <td className="px-5 py-4 text-xs text-slate-700 max-w-xs">
                        {client.category === 'potential' ? (
                          <div className="space-y-0.5">
                            {client.potentialSelectedFund ? (
                              <div className="flex items-center gap-1 font-medium text-slate-900 truncate max-w-[220px]" title={client.potentialSelectedFund}>
                                <TrendingUp className="w-3 h-3 text-amber-700 shrink-0" />
                                <span className="truncate">{client.potentialSelectedFund}</span>
                              </div>
                            ) : (
                              <span className="text-slate-400 italic">No fund specified</span>
                            )}
                            <div className="text-[11px] text-amber-900 font-mono">
                              Fee: Init <strong>{client.proposedFeeInitial || '3%'}</strong> • Ongoing <strong>{client.proposedFeeOngoing || '1%'}</strong>
                            </div>
                          </div>
                        ) : client.category === 'ongoing' ? (
                          <div className="space-y-0.5">
                            {client.nextAction ? (
                              <div className="line-clamp-1 font-medium text-slate-800" title={client.nextAction}>
                                {client.nextAction}
                              </div>
                            ) : (
                              <span className="text-slate-400 italic">No action logged</span>
                            )}
                            <div className="text-[11px] text-slate-500 font-mono flex items-center gap-2">
                              {client.signUpDate && <span>Signed: {client.signUpDate}</span>}
                              {client.nextActionDueDate && <span className="text-blue-700">Due: {client.nextActionDueDate}</span>}
                            </div>
                          </div>
                        ) : client.category === 'onboarded' ? (
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-1.5 font-medium text-indigo-950">
                              <BadgeCheck className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                              <span>Admin Stages Completed</span>
                            </div>
                            <div className="text-[11px] text-slate-500 font-mono">
                              {client.moneyLanded && client.servicingSetUp ? (
                                <span className="text-emerald-700 font-semibold">✓ Ready for Servicing Pipeline</span>
                              ) : (
                                <span>Awaiting Final Handover Checklist</span>
                              )}
                            </div>
                          </div>
                        ) : client.category === 'completed' ? (
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-1.5 font-medium text-teal-950">
                              <Archive className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                              <span className="font-semibold">Complete (Dormant File)</span>
                            </div>
                            <div className="text-[11px] text-slate-500 font-mono flex items-center gap-2">
                              <span className="text-emerald-700 font-medium">✓ Active in Servicing</span>
                              {client.moneyLandedDate && <span>• Money Landed: {client.moneyLandedDate}</span>}
                            </div>
                          </div>
                        ) : (
                          <div className="space-y-0.5">
                            <span className="font-medium text-rose-900 line-clamp-1" title={client.onHoldReason}>
                              {client.onHoldReason || 'File placed on hold'}
                            </span>
                            {client.nextActionDueDate && (
                              <div className="text-[11px] text-slate-500 font-mono">
                                Review: {client.nextActionDueDate}
                              </div>
                            )}
                          </div>
                        )}
                      </td>

                      {/* Onboarded Columns OR Steps Progress */}
                      {client.category === 'onboarded' ? (
                        <>
                          {/* Money Landed Checkbox Column */}
                          <td className="px-4 py-4 whitespace-nowrap text-center">
                            <button
                              type="button"
                              onClick={() => handleToggleMoneyLanded(client)}
                              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold transition cursor-pointer ${
                                client.moneyLanded
                                  ? 'bg-emerald-50 text-emerald-800 border-emerald-300 shadow-2xs hover:bg-emerald-100'
                                  : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50 hover:border-slate-400'
                              }`}
                              title={client.moneyLanded ? `Money landed confirmed on ${client.moneyLandedDate || 'file'}` : 'Click to confirm money has landed'}
                            >
                              {client.moneyLanded ? (
                                <>
                                  <CheckSquare className="w-4 h-4 text-emerald-600" />
                                  <span>Yes {client.moneyLandedDate ? `(${client.moneyLandedDate})` : ''}</span>
                                </>
                              ) : (
                                <>
                                  <Square className="w-4 h-4 text-slate-400" />
                                  <span className="text-slate-500">Pending</span>
                                </>
                              )}
                            </button>
                          </td>

                          {/* Servicing Set Up Checkbox Column */}
                          <td className="px-4 py-4 whitespace-nowrap text-center">
                            <button
                              type="button"
                              onClick={() => handleToggleServicingSetUp(client)}
                              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold transition cursor-pointer ${
                                client.servicingSetUp
                                  ? 'bg-emerald-50 text-emerald-800 border-emerald-300 shadow-2xs hover:bg-emerald-100'
                                  : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50 hover:border-slate-400'
                              }`}
                              title={client.servicingSetUp ? `Servicing set up confirmed on ${client.servicingSetUpDate || 'file'}` : 'Click to confirm servicing is set up'}
                            >
                              {client.servicingSetUp ? (
                                <>
                                  <CheckSquare className="w-4 h-4 text-emerald-600" />
                                  <span>Yes {client.servicingSetUpDate ? `(${client.servicingSetUpDate})` : ''}</span>
                                </>
                              ) : (
                                <>
                                  <Square className="w-4 h-4 text-slate-400" />
                                  <span className="text-slate-500">Pending</span>
                                </>
                              )}
                            </button>
                          </td>
                        </>
                      ) : client.category === 'potential' ? (
                        /* Potential Leads: Fact Find Button & Stage Status */
                        <td className="px-4 py-4 whitespace-nowrap text-xs">
                          {client.factFind && client.factFind.status === 'completed' ? (
                            <div className="flex items-center gap-2 flex-wrap">
                              <button
                                type="button"
                                onClick={() => setSelectedFactFindClient(client)}
                                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-semibold transition cursor-pointer shadow-2xs group"
                                title="View completed Fact Find"
                              >
                                <FileCheck className="w-3.5 h-3.5 text-emerald-600 group-hover:scale-105 transition-transform" />
                                <span>Fact Find (Completed)</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => handleMoveCategory(client.id, 'ongoing')}
                                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold transition cursor-pointer shadow-xs group"
                                title="Move client into Ongoing and trigger administration checklist"
                              >
                                <Sparkles className="w-3.5 h-3.5 text-emerald-200" />
                                <span>Move into Ongoing</span>
                                <ArrowRight className="w-3 h-3 text-emerald-200 group-hover:translate-x-0.5 transition-transform" />
                              </button>
                            </div>
                          ) : client.factFind && client.factFind.status === 'in_progress' ? (
                            <button
                              type="button"
                              onClick={() => setSelectedFactFindClient(client)}
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 font-semibold transition cursor-pointer shadow-2xs group"
                              title="Continue Client Fact Find"
                            >
                              <FileCheck className="w-3.5 h-3.5 text-blue-600 group-hover:scale-105 transition-transform" />
                              <span>Stage {client.factFind.currentStage || 1}: Fact Find</span>
                              <ChevronRight className="w-3 h-3 text-blue-400 group-hover:translate-x-0.5 transition-transform" />
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => setSelectedFactFindClient(client)}
                              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold transition cursor-pointer shadow-xs group"
                              title="Start Client Fact Find"
                            >
                              <Sparkles className="w-3.5 h-3.5 text-blue-200" />
                              <span>Start Fact Find</span>
                              <ChevronRight className="w-3 h-3 text-blue-200 group-hover:translate-x-0.5 transition-transform" />
                            </button>
                          )}
                        </td>
                      ) : (
                        /* Admin Steps Progress with mini-bar and clickable button */
                        <td className="px-4 py-4 whitespace-nowrap text-xs">
                          <button
                            onClick={() => setSelectedStepClient(client)}
                            className="group flex flex-col items-start gap-1 p-1.5 -m-1.5 rounded-lg hover:bg-blue-50/80 transition text-left"
                            title="Click to view/update step-by-step checklist"
                          >
                            <div className="flex items-center gap-1.5 font-semibold text-slate-800 group-hover:text-blue-700">
                              <FileCheck className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                              <span>{completed}/{total}</span>
                              <span className="text-[11px] text-slate-500 font-normal">({percent}%)</span>
                            </div>
                            <div className="w-24 bg-slate-200 rounded-full h-1.5 overflow-hidden">
                              <div 
                                className={`h-full transition-all duration-300 rounded-full ${
                                  percent === 100 ? 'bg-emerald-500' : percent > 50 ? 'bg-blue-600' : 'bg-amber-500'
                                }`}
                                style={{ width: `${percent}%` }}
                              />
                            </div>
                          </button>
                        </td>
                      )}

                      {/* Actions (Track, View Fact Find, Edit, Delete) */}
                      <td className="px-5 py-4 whitespace-nowrap text-right text-sm">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Dedicated View Fact Find action button */}
                          <button
                            onClick={() => setSelectedFactFindClient(client)}
                            className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition cursor-pointer"
                            title="View Fact Find File"
                          >
                            <FileSpreadsheet className="w-4 h-4" />
                          </button>

                          {client.category !== 'potential' && (
                            <button
                              onClick={() => setSelectedStepClient(client)}
                              className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg transition cursor-pointer"
                              title="Track Admin Steps"
                            >
                              <FileCheck className="w-4 h-4" />
                            </button>
                          )}

                          <button
                            onClick={() => {
                              setEditingClient(client);
                              setIsFormModalOpen(true);
                            }}
                            className="p-1.5 text-slate-500 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                            title="Edit Client"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(client.id, client.clientName)}
                            className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition"
                            title="Delete Client"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Footer Info (Mirrors LoATable Footer) */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row justify-between items-center gap-2 text-xs text-slate-500 font-medium">
          <span>
            Showing {sortedClients.length} {activeCategory === 'potential' ? 'potential' : activeCategory === 'ongoing' ? 'ongoing' : activeCategory === 'onboarded' ? 'onboarded' : activeCategory === 'completed' ? 'completed' : 'on hold'} client files ({clients.length} total in practice)
          </span>
          <span>Adams &amp; Poole Financial Services • Client Administration</span>
        </div>

      </div>

      {/* Modals */}
      <FactFindModal
        client={selectedFactFindClient}
        isOpen={!!selectedFactFindClient}
        onClose={() => setSelectedFactFindClient(null)}
        onClientUpdated={onRefresh}
      />

      <ClientStepProgressModal
        client={selectedStepClient}
        isOpen={!!selectedStepClient}
        onClose={() => setSelectedStepClient(null)}
      />

      <ClientFormModal
        isOpen={isFormModalOpen}
        onClose={() => {
          setIsFormModalOpen(false);
          setEditingClient(null);
        }}
        onSubmit={handleSaveClient}
        editingClient={editingClient}
        defaultCategory={defaultCategoryForNew}
      />

      {/* In-App Delete Confirmation Modal */}
      {deleteModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150">
            <div className="flex items-start gap-3.5">
              <div className="p-3 bg-rose-100 text-rose-600 rounded-full shrink-0">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-slate-900">
                  {deleteModal.isBatch ? 'Delete Selected Client Files?' : 'Delete Client Record?'}
                </h3>
                <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                  Are you sure you want to permanently delete{' '}
                  <strong className="text-slate-900 font-semibold">{deleteModal.name}</strong>?
                  {deleteModal.isBatch 
                    ? ' All tracking steps and progress for these selected files will be permanently removed.' 
                    : ' This will remove the client file, fee terms, and all milestone tracking.'}
                </p>
              </div>
            </div>

            <div className="mt-6 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setDeleteModal({ isOpen: false, id: '', name: '', isBatch: false })}
                disabled={isDeleting}
                className="px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 border border-slate-300 rounded-lg transition"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={isDeleting}
                className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 disabled:opacity-50 rounded-lg transition flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                {isDeleting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Deleting...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete Record</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* In-App Hold Reason Modal */}
      {holdModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150">
            <div className="flex items-start justify-between gap-3 mb-3">
              <div className="flex items-center gap-2 text-slate-900 font-bold text-base">
                <PauseCircle className="w-5 h-5 text-slate-600" />
                <h3>Place Client File On Hold</h3>
              </div>
              <button
                onClick={() => setHoldModal({ isOpen: false })}
                className="text-slate-400 hover:text-slate-600 p-1 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-slate-600 mb-3">
              Please specify the operational reason for pausing activity on{' '}
              <strong className="text-slate-800">{holdModal.clientName || 'selected file(s)'}</strong>:
            </p>
            <textarea
              rows={3}
              value={holdReasonInput}
              onChange={(e) => setHoldReasonInput(e.target.value)}
              placeholder="e.g. Awaiting Grant of Probate / Awaiting client decision / Solicitor review"
              className="w-full text-xs p-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-400 font-sans"
              autoFocus
            />
            <div className="mt-4 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setHoldModal({ isOpen: false })}
                className="px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-100 border border-slate-300 rounded-lg transition"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmHoldReason}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-slate-700 hover:bg-slate-800 rounded-lg transition cursor-pointer"
              >
                Confirm On Hold
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
