import React, { useState, useEffect } from 'react';
import { 
  X, 
  CheckCircle2, 
  Circle, 
  Clock, 
  User, 
  Calendar, 
  Plus, 
  Trash2, 
  ArrowRight, 
  AlertCircle,
  FileCheck,
  Building2,
  ChevronRight,
  TrendingUp,
  Percent,
  Sparkles,
  FileSpreadsheet
} from 'lucide-react';
import { ClientAdminEntry, ClientAdminStep, ClientCategory } from '../../types';
import { updateClient } from '../../services/clientAdminService';
import { getTodayDDMMYYYY } from '../../utils/dateUtils';
import { generateStepsForCategory } from '../../data/mockClientAdmin';
import { formatPoundSterling, normalizeServiceScope } from '../../utils/currencyUtils';
import { FactFindModal } from './FactFindModal';

interface ClientStepProgressModalProps {
  client: ClientAdminEntry | null;
  isOpen: boolean;
  onClose: () => void;
  onClientUpdated?: () => void;
}

export const ClientStepProgressModal: React.FC<ClientStepProgressModalProps> = ({
  client,
  isOpen,
  onClose,
  onClientUpdated
}) => {
  const [steps, setSteps] = useState<ClientAdminStep[]>(client?.steps || []);
  const [currentCategory, setCurrentCategory] = useState<ClientCategory>(client?.category || 'potential');
  const [signUpDate, setSignUpDate] = useState<string>(client?.signUpDate || '');
  const [showPromotedBanner, setShowPromotedBanner] = useState(false);
  const [newStepTitle, setNewStepTitle] = useState('');
  const [newStepDescription, setNewStepDescription] = useState('');
  const [isAddingStep, setIsAddingStep] = useState(false);
  const [userRoleName, setUserRoleName] = useState('Sam Adams');
  const [isFactFindOpen, setIsFactFindOpen] = useState(false);

  // Keep state synchronized with incoming client prop
  useEffect(() => {
    if (client) {
      setSteps(client.steps || []);
      setCurrentCategory(client.category);
      setSignUpDate(client.signUpDate || '');
      setShowPromotedBanner(false);
    }
  }, [client]);

  if (!isOpen || !client) return null;

  const completedCount = steps.filter(s => s.isCompleted).length;
  const totalCount = steps.length;
  const percentComplete = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const handleToggleStep = async (stepId: string) => {
    const todayStr = getTodayDDMMYYYY();
    const updated = steps.map(s => {
      if (s.id === stepId) {
        const nextState = !s.isCompleted;
        return {
          ...s,
          isCompleted: nextState,
          completedAt: nextState ? todayStr : '',
          completedBy: nextState ? userRoleName : ''
        };
      }
      return s;
    });

    const isPotential = currentCategory === 'potential';
    const isOngoing = currentCategory === 'ongoing';
    const allStagesCompleted = updated.length > 0 && updated.every(s => s.isCompleted);

    if (isPotential && allStagesCompleted) {
      // Auto-promote potential client into Ongoing Clients
      const ongoingSteps = generateStepsForCategory('ongoing');
      const newSignUpDate = signUpDate || todayStr;
      
      setSteps(ongoingSteps);
      setCurrentCategory('ongoing');
      setSignUpDate(newSignUpDate);
      setShowPromotedBanner(true);

      try {
        await updateClient(client.id, {
          clientName: client.clientName,
          category: 'ongoing',
          signUpDate: newSignUpDate,
          nextAction: 'Complete AML/KYC Identity Verification & Dispatch LoAs',
          steps: ongoingSteps
        });
        if (onClientUpdated) onClientUpdated();
      } catch (e) {
        console.error('Failed to auto-advance client to ongoing:', e);
      }
    } else if (isOngoing && allStagesCompleted) {
      // Auto-promote ongoing client into Onboarded stage
      setCurrentCategory('onboarded');
      setSteps(updated);
      setShowPromotedBanner(true);

      try {
        await updateClient(client.id, {
          clientName: client.clientName,
          category: 'onboarded',
          steps: updated
        });
        if (onClientUpdated) onClientUpdated();
      } catch (e) {
        console.error('Failed to auto-advance client to onboarded:', e);
      }
    } else {
      setSteps(updated);
      try {
        await updateClient(client.id, { 
          clientName: client.clientName,
          steps: updated 
        });

        if (onClientUpdated) onClientUpdated();
      } catch (e) {
        console.error('Failed to update step:', e);
      }
    }
  };

  const handleAddCustomStep = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStepTitle.trim()) return;

    const newStep: ClientAdminStep = {
      id: `step-custom-${Date.now()}`,
      title: newStepTitle.trim(),
      description: newStepDescription.trim(),
      isCompleted: false
    };

    const updated = [...steps, newStep];
    setSteps(updated);
    setNewStepTitle('');
    setNewStepDescription('');
    setIsAddingStep(false);

    try {
      await updateClient(client.id, { 
        clientName: client.clientName,
        steps: updated 
      });
      if (onClientUpdated) onClientUpdated();
    } catch (e) {
      console.error('Failed to add custom step:', e);
    }
  };

  const handleDeleteStep = async (stepId: string) => {
    const updated = steps.filter(s => s.id !== stepId);
    setSteps(updated);
    try {
      await updateClient(client.id, { 
        clientName: client.clientName,
        steps: updated 
      });
      if (onClientUpdated) onClientUpdated();
    } catch (e) {
      console.error('Failed to remove step:', e);
    }
  };

  const categoryBadge = (cat: ClientCategory) => {
    switch (cat) {
      case 'potential':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">Potential Client</span>;
      case 'ongoing':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">Ongoing Client</span>;
      case 'onboarded':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">Onboarded</span>;
      case 'completed':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-teal-50 text-teal-700 border border-teal-200">Completed (Dormant)</span>;
      case 'on_hold':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-300">On Hold</span>;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl relative overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="border-b border-slate-200 p-5 sm:p-6 bg-slate-50 shrink-0">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1 flex-wrap">
                {categoryBadge(currentCategory)}
                {currentCategory === 'potential' ? (
                  <span className="text-xs text-amber-900 bg-amber-100/80 px-2 py-0.5 rounded font-mono font-medium">
                    Fee: Initial {client.proposedFeeInitial || '3%'} • Ongoing {client.proposedFeeOngoing || '1%'}
                  </span>
                ) : (
                  <span className="text-xs text-slate-600 font-medium font-mono bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 text-emerald-800">
                    Signed: {signUpDate || 'Recent'}
                  </span>
                )}
              </div>
              <h2 className="text-xl font-bold text-slate-900">
                {client.clientName}
              </h2>
              <p className="text-xs text-slate-600 mt-0.5">
                {normalizeServiceScope(client.serviceType)} • Lead Adviser: <span className="font-semibold text-slate-800">{client.adviserName}</span>
                {client.estimatedValue ? ` • Est. ${formatPoundSterling(client.estimatedValue)}` : ''}
              </p>
              {currentCategory === 'potential' && client.potentialSelectedFund && (
                <div className="mt-1 flex items-center gap-1.5 text-xs text-slate-700">
                  <TrendingUp className="w-3.5 h-3.5 text-amber-700" />
                  <span><strong>Potential Fund:</strong> {client.potentialSelectedFund}</span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsFactFindOpen(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-xl transition cursor-pointer"
                title="View full Fact Find details"
              >
                <FileSpreadsheet className="w-4 h-4 text-blue-600" />
                <span>View Fact Find</span>
              </button>

              <button
                onClick={onClose}
                className="p-1.5 text-slate-400 hover:text-slate-600 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Progress Overview Bar */}
          <div className="mt-4 pt-3 border-t border-slate-200 flex flex-col gap-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-700 flex items-center gap-1.5">
                <FileCheck className="w-4 h-4 text-blue-600" />
                Administrative Process Milestones ({completedCount} of {totalCount} Completed)
              </span>
              <span className="font-bold text-blue-600">{percentComplete}%</span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-2.5 overflow-hidden">
              <div 
                className={`h-full transition-all duration-300 rounded-full ${
                  percentComplete === 100 
                    ? 'bg-emerald-500' 
                    : percentComplete > 50 
                    ? 'bg-blue-600' 
                    : 'bg-amber-500'
                }`}
                style={{ width: `${percentComplete}%` }}
              />
            </div>
          </div>
        </div>

        {/* Promotion Banner when client completed all potential milestones or ongoing checklist */}
        {showPromotedBanner && (
          <div className="bg-emerald-50 border-b border-emerald-200 px-6 py-3 flex items-start gap-2.5 text-xs text-emerald-900 animate-in fade-in duration-200">
            <Sparkles className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-emerald-950">
                {currentCategory === 'onboarded'
                  ? 'Admin Checklist Complete — Moved to Onboarded!'
                  : 'Milestones Complete — Moved to Ongoing Clients!'}
              </p>
              <p className="text-emerald-800 text-[11px] mt-0.5">
                {currentCategory === 'onboarded'
                  ? 'Client has completed all ongoing administrative stages and has been placed into the Onboarded pipeline.'
                  : 'Client has officially signed up. The workflow has automatically advanced to the Ongoing Client onboarding & administration checklist below.'}
              </p>
            </div>
          </div>
        )}

        {/* Action / Hold notice banner if on hold */}
        {currentCategory === 'on_hold' && client.onHoldReason && (
          <div className="bg-amber-50 border-b border-amber-200 px-6 py-2.5 flex items-center gap-2 text-xs text-amber-800">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
            <span><strong>Reason for Hold:</strong> {client.onHoldReason}</span>
          </div>
        )}

        {/* Steps List */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-3">
          {/* Fact Find Banner for Potential Leads */}
          {currentCategory === 'potential' && (
            <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-2xs mb-2">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-blue-600 text-white rounded-lg shrink-0 mt-0.5">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">
                    Client Fact Find &amp; Discovery Process
                  </h4>
                  <p className="text-[11px] text-slate-600 mt-0.5">
                    {client.factFind?.stage1?.client1?.fullName ? (
                      <span>
                        Fact Find {client.factFind.status === 'completed' ? 'Completed (Stages 1–8)' : `In Progress (Stage ${client.factFind.currentStage || 1} of 8)`} • {client.factFind.stage1.hasSecondClient ? 'Joint Application' : 'Single Client'} • Adviser: {client.factFind.stage1.adviser || client.adviserName}
                      </span>
                    ) : (
                      <span>Full Fact Find replaces individual lead contact steps. Stages 1–8 capture client details, personal circumstances, employment/income, assets &amp; liabilities, investment capacity, objectives/risk preferences, additional notes, and review &amp; submit.</span>
                    )}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsFactFindOpen(true)}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl transition shadow-xs flex items-center gap-1.5 shrink-0 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{client.factFind?.stage1?.client1?.fullName ? 'Open / Edit Fact Find' : 'Start Fact Find'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div className="flex items-center gap-2 text-xs text-slate-600">
              <span>Sign-off Role:</span>
              <select
                value={userRoleName}
                onChange={(e) => setUserRoleName(e.target.value)}
                className="bg-slate-100 border border-slate-300 rounded px-2 py-0.5 font-medium text-slate-800 text-xs focus:ring-1 focus:ring-blue-500"
              >
                <option value="Sam Adams">Sam Adams (Adviser)</option>
                <option value="Anthony Poole">Anthony Poole (Adviser)</option>
                <option value="Paraplanning Desk">Paraplanning Desk</option>
                <option value="Practice Admin">Practice Admin</option>
              </select>
            </div>

            <button
              type="button"
              onClick={() => setIsAddingStep(!isAddingStep)}
              className="px-2.5 py-1 text-xs bg-blue-50 hover:bg-blue-100 text-blue-700 font-medium rounded-lg transition flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isAddingStep ? 'Cancel' : 'Add Custom Step'}</span>
            </button>
          </div>

          {/* Add Custom Step Form */}
          {isAddingStep && (
            <form onSubmit={handleAddCustomStep} className="p-3 bg-blue-50/60 border border-blue-200 rounded-xl space-y-2 text-xs animate-in fade-in duration-150">
              <h4 className="font-semibold text-blue-900">Add Practice-Specific Admin Step</h4>
              <input
                type="text"
                required
                placeholder="e.g. Request P60 / State Pension Forecast from DWP"
                value={newStepTitle}
                onChange={(e) => setNewStepTitle(e.target.value)}
                className="w-full bg-white border border-blue-200 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <input
                type="text"
                placeholder="Optional detail or guidance note"
                value={newStepDescription}
                onChange={(e) => setNewStepDescription(e.target.value)}
                className="w-full bg-white border border-blue-200 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsAddingStep(false)}
                  className="px-3 py-1 bg-white border border-slate-200 rounded text-slate-600 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3 py-1 bg-blue-600 text-white rounded font-medium hover:bg-blue-700"
                >
                  Add Step
                </button>
              </div>
            </form>
          )}

          {/* Step items */}
          <div className="space-y-2">
            {steps.length === 0 && currentCategory === 'potential' ? (
              <div className="text-center py-6 px-4 bg-slate-50 border border-slate-200 rounded-xl">
                <p className="text-xs text-slate-600 font-medium">
                  Contact steps have been replaced by the full Client Fact Find.
                </p>
                <p className="text-[11px] text-slate-400 mt-1">
                  Click &ldquo;Start Fact Find&rdquo; above to enter client details, or add practice-specific custom steps if needed.
                </p>
              </div>
            ) : (
              steps.map((step, idx) => (
                <div
                  key={`${step.id || 'step'}-${idx}`}
                  onClick={() => handleToggleStep(step.id)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-start justify-between gap-3 ${
                    step.isCompleted
                      ? 'bg-emerald-50/40 border-emerald-200 hover:bg-emerald-50'
                      : 'bg-white border-slate-200 hover:border-blue-300 hover:bg-slate-50/60'
                  }`}
                >
                  <div className="flex items-start gap-3 flex-1">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleToggleStep(step.id);
                      }}
                      className="mt-0.5 shrink-0 transition"
                    >
                      {step.isCompleted ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-600 fill-emerald-100" />
                      ) : (
                        <Circle className="w-5 h-5 text-slate-300 hover:text-blue-500" />
                      )}
                    </button>

                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono text-slate-400 font-semibold">{idx + 1}.</span>
                        <h4 className={`text-xs font-semibold leading-tight ${
                          step.isCompleted ? 'text-slate-800 line-through text-opacity-70' : 'text-slate-900'
                        }`}>
                          {step.title}
                        </h4>
                      </div>

                      {step.description && (
                        <p className="text-[11px] text-slate-500 leading-snug pl-5">
                          {step.description}
                        </p>
                      )}

                      {step.notes && (
                        <div className="text-[10px] text-blue-700 bg-blue-50/80 px-2 py-0.5 rounded border border-blue-100 mt-1 inline-block ml-5">
                          Note: {step.notes}
                        </div>
                      )}

                      {step.isCompleted && step.completedAt && (
                        <div className="flex items-center gap-2 text-[10px] text-emerald-700 pt-0.5 pl-5 font-mono">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3 text-emerald-600" />
                            Done: {step.completedAt}
                          </span>
                          {step.completedBy && (
                            <span className="flex items-center gap-1">
                              <User className="w-3 h-3 text-emerald-600" />
                              By: {step.completedBy}
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteStep(step.id);
                    }}
                    className="p-1 text-slate-300 hover:text-rose-500 hover:bg-rose-50 rounded transition"
                    title="Remove step"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-slate-200 p-4 sm:p-5 bg-slate-50 flex items-center justify-between shrink-0">
          <div className="text-xs text-slate-500">
            {currentCategory === 'potential' 
              ? 'Stage 1 Fact Find details are saved to the client record.' 
              : 'Click any milestone to mark complete / incomplete'}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium text-xs rounded-lg transition shadow-xs cursor-pointer"
          >
            Done
          </button>
        </div>

      </div>

      <FactFindModal
        client={client}
        isOpen={isFactFindOpen}
        onClose={() => setIsFactFindOpen(false)}
        onClientUpdated={onClientUpdated}
      />
    </div>
  );
};
