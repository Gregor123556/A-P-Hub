import React from 'react';
import { 
  CheckCircle2, 
  User, 
  Users, 
  FileText, 
  Briefcase, 
  Coins, 
  ShieldAlert, 
  Target, 
  Edit3, 
  Calendar,
  Sparkles,
  HeartHandshake,
  Receipt,
  Building2,
  PoundSterling,
  SlidersHorizontal,
  ArrowRight
} from 'lucide-react';
import { 
  FactFindPrimaryGoal, 
  FactFindYesNoQuestion,
  FactFindMaritalStatus,
  FactFindEmploymentStatus,
  FactFindAssetItem,
  FactFindLiabilityItem,
  FactFindIncomeStream,
  FactFindExpenditureItem,
  FactFindStage2Personal
} from '../../types';
import { Stage5CapacityState } from './FactFindStage5';
import { Stage6ObjectivesRiskState } from './FactFindStage6';
import { Stage7AdditionalNotesState } from './FactFindStage7';

export interface FactFindStage8Props {
  // Stage 1
  c1FullName?: string;
  c1Dob?: string;
  c1Email?: string;
  c1Phone?: string;
  c1Address?: string;

  hasSecondClient?: boolean;
  c2FullName?: string;
  c2Dob?: string;
  c2Email?: string;
  c2Phone?: string;
  c2Address?: string;

  meetingDate?: string;
  adviser?: string;

  // Stage 2
  maritalStatus?: FactFindMaritalStatus | '';
  vulnerability?: FactFindYesNoQuestion;
  pepSanctions?: FactFindYesNoQuestion;
  dependants?: FactFindYesNoQuestion;
  willInPlace?: FactFindYesNoQuestion;
  powerOfAttorney?: FactFindYesNoQuestion;
  expectedLifeChanges?: FactFindYesNoQuestion;
  c1Stage2?: FactFindStage2Personal;
  c2Stage2?: FactFindStage2Personal;

  // Stage 3
  incomeStreams?: FactFindIncomeStream[];
  expenditureItems?: FactFindExpenditureItem[];
  monthlyExpenses?: string;
  c1EmploymentStatus?: FactFindEmploymentStatus | '';
  c1Employer?: string;
  c1AnnualIncome?: string;
  c1MonthlyExpenses?: string;
  c1OtherIncome?: FactFindYesNoQuestion;

  c2EmploymentStatus?: FactFindEmploymentStatus | '';
  c2Employer?: string;
  c2AnnualIncome?: string;
  c2MonthlyExpenses?: string;
  c2OtherIncome?: FactFindYesNoQuestion;

  // Stage 4
  assets?: FactFindAssetItem[];
  liabilities?: FactFindYesNoQuestion;
  liabilityItems?: FactFindLiabilityItem[];

  // Stage 5
  stage5Data?: Stage5CapacityState;
  c1Stage5?: Stage5CapacityState;
  c2Stage5?: Stage5CapacityState;

  // Stage 6
  stage6Data: Stage6ObjectivesRiskState;

  // Stage 7
  stage7Data: Stage7AdditionalNotesState;

  // Actions & Status
  isCompleted?: boolean;
  clientCategory?: string;
  onMoveToOngoing?: () => void;
  onNavigateToStage: (stage: number) => void;
  onBackToStage7: () => void;
  onSubmit: (e: React.FormEvent) => void;
  isSaving?: boolean;
}

export const FactFindStage8: React.FC<FactFindStage8Props> = ({
  c1FullName,
  c1Dob,
  c1Email,
  c1Phone,
  c1Address,

  hasSecondClient,
  c2FullName,
  c2Dob,
  c2Email,
  c2Phone,
  c2Address,

  meetingDate,
  adviser,

  maritalStatus,
  vulnerability,
  pepSanctions,
  dependants,
  willInPlace,
  powerOfAttorney,
  expectedLifeChanges,
  c1Stage2,
  c2Stage2,

  incomeStreams,
  expenditureItems,
  monthlyExpenses,
  c1EmploymentStatus,
  c1Employer,
  c1AnnualIncome,
  c1MonthlyExpenses,
  c1OtherIncome: _c1OtherIncome,

  c2EmploymentStatus: _c2EmploymentStatus,
  c2Employer: _c2Employer,
  c2AnnualIncome: _c2AnnualIncome,
  c2MonthlyExpenses: _c2MonthlyExpenses,
  c2OtherIncome: _c2OtherIncome,

  assets = [],
  liabilities,
  liabilityItems = [],

  stage5Data,
  c1Stage5,
  c2Stage5,
  stage6Data,
  stage7Data,

  isCompleted,
  clientCategory,
  onMoveToOngoing,
  onNavigateToStage,
  onBackToStage7: _onBackToStage7,
  onSubmit,
  isSaving: _isSaving
}) => {
  const primaryName = c1FullName || 'Primary Client';
  const secondaryName = c2FullName || 'Second Client';

  const getFirstName = (fullName?: string, fallback = 'Client'): string => {
    const trimmed = (fullName || '').trim();
    if (!trimmed) return fallback;
    const first = trimmed.split(/\s+/)[0];
    return first || fallback;
  };

  const c1FirstName = getFirstName(c1FullName, 'Client 1');
  const c2FirstName = getFirstName(c2FullName, 'Client 2');

  // Determine effective income streams
  const effectiveIncomeStreams: FactFindIncomeStream[] = incomeStreams && incomeStreams.length > 0
    ? incomeStreams
    : [
        {
          id: 'fallback-1',
          employmentStatus: c1EmploymentStatus || 'Employed',
          employerBusiness: c1Employer || '',
          annualIncome: c1AnnualIncome || ''
        }
      ];

  const effectiveMonthlyExpenses = monthlyExpenses || c1MonthlyExpenses || '—';

  // Calculate live total annual income
  const totalAnnualIncome = effectiveIncomeStreams.reduce((sum, item) => {
    if (!item.annualIncome) return sum;
    const cleanNum = item.annualIncome.replace(/[^0-9.]/g, '');
    const val = parseFloat(cleanNum);
    return isNaN(val) ? sum : sum + val;
  }, 0);

  // Safe assets handling & calculations
  const safeAssets = Array.isArray(assets) ? assets : [];
  const populatedAssets = safeAssets.filter(a => 
    Boolean((a.approxValue && a.approxValue.trim()) || 
            (a.providerPlatform && a.providerPlatform.trim()) || 
            (a.notes && a.notes.trim()) || 
            (a.assetType === 'Other' && a.otherAssetType && a.otherAssetType.trim()))
  );
  const displayAssets = populatedAssets.length > 0 ? populatedAssets : safeAssets;

  // Calculate Asset Totals
  const totalAssetsValue = safeAssets.reduce((sum, item) => {
    if (!item.approxValue) return sum;
    const raw = item.approxValue.replace(/[^0-9.]/g, '');
    const num = parseFloat(raw) || 0;
    return sum + num;
  }, 0);

  const formatGBP = (amount: number) => {
    return new Intl.NumberFormat('en-GB', {
      style: 'currency',
      currency: 'GBP',
      maximumFractionDigits: 0
    }).format(amount);
  };

  // Determine Goals
  const primaryGoals: FactFindPrimaryGoal[] = stage6Data.primaryGoals && stage6Data.primaryGoals.length > 0
    ? stage6Data.primaryGoals
    : stage6Data.primaryGoal
    ? (stage6Data.primaryGoal.split(',').map(s => s.trim() as FactFindPrimaryGoal)).filter(Boolean)
    : [];

  return (
    <form id="fact-find-stage8-form" onSubmit={onSubmit} className="space-y-6 pb-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-blue-600 text-white rounded-2xl p-5 sm:p-6 shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-3 bg-white/20 backdrop-blur-md text-white rounded-xl shadow-inner shrink-0 mt-0.5">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-white/30 text-white rounded-md backdrop-blur-xs">
                  Stage 8 of 8
                </span>
                <h3 className="text-base sm:text-lg font-bold">
                  Review &amp; Submit Fact Find
                </h3>
              </div>
              <p className="text-xs text-white/90 mt-1 max-w-2xl leading-relaxed">
                Review the consolidated summary across all 7 stages below. You can click "Edit" on any section to jump directly back to that stage before final submission.
              </p>
            </div>
          </div>

          <div className="flex flex-col gap-1 text-xs bg-black/15 backdrop-blur-sm p-3 rounded-xl border border-white/20 self-start sm:self-auto shrink-0 min-w-[200px]">
            <div className="flex items-center justify-between gap-2">
              <span className="text-white/80">Application:</span>
              <span className="font-semibold">{hasSecondClient ? 'Joint Application' : 'Single Client'}</span>
            </div>
            <div className="flex items-center justify-between gap-2">
              <span className="text-white/80">Adviser:</span>
              <span className="font-semibold">{adviser || 'Sam Adams'}</span>
            </div>
            <div className="flex items-center justify-between gap-2">
              <span className="text-white/80">Date:</span>
              <span className="font-semibold">{meetingDate || 'Today'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Review Grid / Bento layout */}
      <div className="space-y-5">
        
        {/* ============================================================ */}
        {/* STAGE 1: CLIENT DETAILS                                     */}
        {/* ============================================================ */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3.5 bg-slate-50 border-b border-slate-200">
            <div className="flex items-center gap-2.5">
              <div className="p-1.5 bg-blue-100 text-blue-700 rounded-lg">
                <User className="w-4 h-4" />
              </div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Stage 1: Client Personal Details
              </h4>
            </div>
            <button
              type="button"
              onClick={() => onNavigateToStage(1)}
              className="inline-flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-800 hover:underline cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit Stage 1</span>
            </button>
          </div>

          <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Primary Client */}
            <div className="space-y-2.5 bg-slate-50/60 p-4 rounded-xl border border-slate-200/80">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-blue-600" />
                  Primary Client: {primaryName}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-slate-500 block text-[11px]">Date of Birth</span>
                  <span className="font-semibold text-slate-800">{c1Dob || '—'}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[11px]">Telephone</span>
                  <span className="font-semibold text-slate-800">{c1Phone || '—'}</span>
                </div>
                <div className="col-span-2">
                  <span className="text-slate-500 block text-[11px]">Email</span>
                  <span className="font-semibold text-slate-800 truncate block">{c1Email || '—'}</span>
                </div>
                <div className="col-span-2">
                  <span className="text-slate-500 block text-[11px]">Address</span>
                  <span className="font-semibold text-slate-800">{c1Address || '—'}</span>
                </div>
              </div>
            </div>

            {/* Second Client (if applicable) */}
            {hasSecondClient ? (
              <div className="space-y-2.5 bg-slate-50/60 p-4 rounded-xl border border-slate-200/80">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-indigo-600" />
                    Second Client: {secondaryName}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-slate-500 block text-[11px]">Date of Birth</span>
                    <span className="font-semibold text-slate-800">{c2Dob || '—'}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">Telephone</span>
                    <span className="font-semibold text-slate-800">{c2Phone || '—'}</span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-slate-500 block text-[11px]">Email</span>
                    <span className="font-semibold text-slate-800 truncate block">{c2Email || '—'}</span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-slate-500 block text-[11px]">Address</span>
                    <span className="font-semibold text-slate-800">{c2Address || '—'}</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center p-6 border border-dashed border-slate-200 rounded-xl text-center text-xs text-slate-400 bg-slate-50/30">
                <User className="w-6 h-6 text-slate-300 mb-1" />
                <span className="font-semibold text-slate-600">Single Client Application</span>
                <span className="text-[11px]">No secondary applicant attached to this Fact Find.</span>
              </div>
            )}
          </div>
        </div>

        {/* ============================================================ */}
        {/* STAGE 2: PERSONAL CIRCUMSTANCES & FAMILY                     */}
        {/* ============================================================ */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3.5 bg-slate-50 border-b border-slate-200">
            <div className="flex items-center gap-2.5">
              <div className="p-1.5 bg-indigo-100 text-indigo-700 rounded-lg">
                <HeartHandshake className="w-4 h-4" />
              </div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Stage 2: Personal Circumstances &amp; Family
              </h4>
            </div>
            <button
              type="button"
              onClick={() => onNavigateToStage(2)}
              className="inline-flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-800 hover:underline cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit Stage 2</span>
            </button>
          </div>

          <div className="p-5 space-y-4">
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-500 font-medium">Marital Status:</span>
              <span className="px-2.5 py-0.5 font-bold bg-slate-100 text-slate-800 rounded-full border border-slate-200">
                {maritalStatus || 'Not Specified'}
              </span>
            </div>

            {hasSecondClient ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                {/* Client 1 Review */}
                {(() => {
                  const q = c1Stage2 || {
                    vulnerability,
                    pepSanctions,
                    dependants,
                    willInPlace,
                    powerOfAttorney,
                    expectedLifeChanges
                  };
                  return (
                    <div className="border border-blue-200 rounded-xl p-4 bg-blue-50/20 space-y-3">
                      <div className="flex items-center justify-between pb-2 border-b border-blue-100">
                        <span className="text-xs font-bold text-blue-950 flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-blue-600" />
                          Client 1: {primaryName}
                        </span>
                        <span className="text-[10px] font-bold px-2 py-0.5 bg-blue-100 text-blue-800 rounded-full">
                          Primary
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                        {/* Vulnerability */}
                        <div className="p-2.5 bg-white rounded-lg border border-slate-200/80">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-semibold text-slate-700 text-[11px]">Vulnerability</span>
                            <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q.vulnerability?.answered === 'yes' ? 'bg-amber-100 text-amber-800' : 'bg-slate-200 text-slate-700'}`}>
                              {q.vulnerability?.answered ? q.vulnerability.answered.toUpperCase() : 'NO'}
                            </span>
                          </div>
                          {q.vulnerability?.details && (
                            <p className="text-[10px] text-slate-600 italic line-clamp-2">"{q.vulnerability.details}"</p>
                          )}
                        </div>

                        {/* PEP Sanctions */}
                        <div className="p-2.5 bg-white rounded-lg border border-slate-200/80">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-semibold text-slate-700 text-[11px]">PEP / Sanctions</span>
                            <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q.pepSanctions?.answered === 'yes' ? 'bg-amber-100 text-amber-800' : 'bg-slate-200 text-slate-700'}`}>
                              {q.pepSanctions?.answered ? q.pepSanctions.answered.toUpperCase() : 'NO'}
                            </span>
                          </div>
                          {q.pepSanctions?.answered === 'yes' && q.pepSanctions.details && (
                            <p className="text-[10px] text-slate-600 italic line-clamp-2">"{q.pepSanctions.details}"</p>
                          )}
                        </div>

                        {/* Dependants */}
                        <div className="p-2.5 bg-white rounded-lg border border-slate-200/80">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-semibold text-slate-700 text-[11px]">Dependants</span>
                            <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q.dependants?.answered === 'yes' ? 'bg-amber-100 text-amber-800' : 'bg-slate-200 text-slate-700'}`}>
                              {q.dependants?.answered ? q.dependants.answered.toUpperCase() : 'NO'}
                            </span>
                          </div>
                          {q.dependants?.answered === 'yes' && q.dependants.details && (
                            <p className="text-[10px] text-slate-600 italic line-clamp-2">"{q.dependants.details}"</p>
                          )}
                        </div>

                        {/* Will */}
                        <div className="p-2.5 bg-white rounded-lg border border-slate-200/80">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-semibold text-slate-700 text-[11px]">Will in Place</span>
                            <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q.willInPlace?.answered === 'yes' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'}`}>
                              {q.willInPlace?.answered ? q.willInPlace.answered.toUpperCase() : 'NO'}
                            </span>
                          </div>
                          {q.willInPlace?.answered === 'yes' && q.willInPlace.details && (
                            <p className="text-[10px] text-slate-600 italic line-clamp-2">"{q.willInPlace.details}"</p>
                          )}
                        </div>

                        {/* LPA */}
                        <div className="p-2.5 bg-white rounded-lg border border-slate-200/80">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-semibold text-slate-700 text-[11px]">Power of Attorney</span>
                            <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q.powerOfAttorney?.answered === 'yes' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'}`}>
                              {q.powerOfAttorney?.answered ? q.powerOfAttorney.answered.toUpperCase() : 'NO'}
                            </span>
                          </div>
                          {q.powerOfAttorney?.answered === 'yes' && q.powerOfAttorney.details && (
                            <p className="text-[10px] text-slate-600 italic line-clamp-2">"{q.powerOfAttorney.details}"</p>
                          )}
                        </div>

                        {/* 5-Yr Life Changes */}
                        <div className="p-2.5 bg-white rounded-lg border border-slate-200/80">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-semibold text-slate-700 text-[11px]">5-Yr Life Changes</span>
                            <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q.expectedLifeChanges?.answered === 'yes' ? 'bg-blue-100 text-blue-800' : 'bg-slate-200 text-slate-700'}`}>
                              {q.expectedLifeChanges?.answered ? q.expectedLifeChanges.answered.toUpperCase() : 'NO'}
                            </span>
                          </div>
                          {q.expectedLifeChanges?.answered === 'yes' && q.expectedLifeChanges.details && (
                            <p className="text-[10px] text-slate-600 italic line-clamp-2">"{q.expectedLifeChanges.details}"</p>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })()}

                {/* Client 2 Review */}
                {(() => {
                  const q2 = c2Stage2 || {
                    vulnerability: { answered: '', details: '' },
                    pepSanctions: { answered: '', details: '' },
                    dependants: { answered: '', details: '' },
                    willInPlace: { answered: '', details: '' },
                    powerOfAttorney: { answered: '', details: '' },
                    expectedLifeChanges: { answered: '', details: '' }
                  };
                  return (
                    <div className="border border-indigo-200 rounded-xl p-4 bg-indigo-50/20 space-y-3">
                      <div className="flex items-center justify-between pb-2 border-b border-indigo-100">
                        <span className="text-xs font-bold text-indigo-950 flex items-center gap-1.5">
                          <Users className="w-3.5 h-3.5 text-indigo-600" />
                          Client 2: {secondaryName}
                        </span>
                        <span className="text-[10px] font-bold px-2 py-0.5 bg-indigo-100 text-indigo-800 rounded-full">
                          Partner / Spouse
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                        {/* Vulnerability */}
                        <div className="p-2.5 bg-white rounded-lg border border-slate-200/80">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-semibold text-slate-700 text-[11px]">Vulnerability</span>
                            <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q2.vulnerability?.answered === 'yes' ? 'bg-amber-100 text-amber-800' : 'bg-slate-200 text-slate-700'}`}>
                              {q2.vulnerability?.answered ? q2.vulnerability.answered.toUpperCase() : 'NO'}
                            </span>
                          </div>
                          {q2.vulnerability?.details && (
                            <p className="text-[10px] text-slate-600 italic line-clamp-2">"{q2.vulnerability.details}"</p>
                          )}
                        </div>

                        {/* PEP Sanctions */}
                        <div className="p-2.5 bg-white rounded-lg border border-slate-200/80">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-semibold text-slate-700 text-[11px]">PEP / Sanctions</span>
                            <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q2.pepSanctions?.answered === 'yes' ? 'bg-amber-100 text-amber-800' : 'bg-slate-200 text-slate-700'}`}>
                              {q2.pepSanctions?.answered ? q2.pepSanctions.answered.toUpperCase() : 'NO'}
                            </span>
                          </div>
                          {q2.pepSanctions?.answered === 'yes' && q2.pepSanctions.details && (
                            <p className="text-[10px] text-slate-600 italic line-clamp-2">"{q2.pepSanctions.details}"</p>
                          )}
                        </div>

                        {/* Dependants */}
                        <div className="p-2.5 bg-white rounded-lg border border-slate-200/80">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-semibold text-slate-700 text-[11px]">Dependants</span>
                            <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q2.dependants?.answered === 'yes' ? 'bg-amber-100 text-amber-800' : 'bg-slate-200 text-slate-700'}`}>
                              {q2.dependants?.answered ? q2.dependants.answered.toUpperCase() : 'NO'}
                            </span>
                          </div>
                          {q2.dependants?.answered === 'yes' && q2.dependants.details && (
                            <p className="text-[10px] text-slate-600 italic line-clamp-2">"{q2.dependants.details}"</p>
                          )}
                        </div>

                        {/* Will */}
                        <div className="p-2.5 bg-white rounded-lg border border-slate-200/80">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-semibold text-slate-700 text-[11px]">Will in Place</span>
                            <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q2.willInPlace?.answered === 'yes' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'}`}>
                              {q2.willInPlace?.answered ? q2.willInPlace.answered.toUpperCase() : 'NO'}
                            </span>
                          </div>
                          {q2.willInPlace?.answered === 'yes' && q2.willInPlace.details && (
                            <p className="text-[10px] text-slate-600 italic line-clamp-2">"{q2.willInPlace.details}"</p>
                          )}
                        </div>

                        {/* LPA */}
                        <div className="p-2.5 bg-white rounded-lg border border-slate-200/80">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-semibold text-slate-700 text-[11px]">Power of Attorney</span>
                            <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q2.powerOfAttorney?.answered === 'yes' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'}`}>
                              {q2.powerOfAttorney?.answered ? q2.powerOfAttorney.answered.toUpperCase() : 'NO'}
                            </span>
                          </div>
                          {q2.powerOfAttorney?.answered === 'yes' && q2.powerOfAttorney.details && (
                            <p className="text-[10px] text-slate-600 italic line-clamp-2">"{q2.powerOfAttorney.details}"</p>
                          )}
                        </div>

                        {/* 5-Yr Life Changes */}
                        <div className="p-2.5 bg-white rounded-lg border border-slate-200/80">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-semibold text-slate-700 text-[11px]">5-Yr Life Changes</span>
                            <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q2.expectedLifeChanges?.answered === 'yes' ? 'bg-blue-100 text-blue-800' : 'bg-slate-200 text-slate-700'}`}>
                              {q2.expectedLifeChanges?.answered ? q2.expectedLifeChanges.answered.toUpperCase() : 'NO'}
                            </span>
                          </div>
                          {q2.expectedLifeChanges?.answered === 'yes' && q2.expectedLifeChanges.details && (
                            <p className="text-[10px] text-slate-600 italic line-clamp-2">"{q2.expectedLifeChanges.details}"</p>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
                {/* Vulnerability */}
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-slate-700">Vulnerability Identified</span>
                    <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${vulnerability?.answered === 'yes' ? 'bg-amber-100 text-amber-800' : 'bg-slate-200 text-slate-700'}`}>
                      {vulnerability?.answered ? vulnerability.answered.toUpperCase() : 'NO'}
                    </span>
                  </div>
                  {vulnerability?.details && (
                    <p className="text-[11px] text-slate-600 mt-1 italic line-clamp-3">"{vulnerability.details}"</p>
                  )}
                </div>

                {/* PEP Sanctions */}
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-slate-700">PEP / Sanctions</span>
                    <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${pepSanctions?.answered === 'yes' ? 'bg-amber-100 text-amber-800' : 'bg-slate-200 text-slate-700'}`}>
                      {pepSanctions?.answered ? pepSanctions.answered.toUpperCase() : 'NO'}
                    </span>
                  </div>
                  {pepSanctions?.answered === 'yes' && pepSanctions.details && (
                    <p className="text-[11px] text-slate-600 mt-1 italic line-clamp-2">"{pepSanctions.details}"</p>
                  )}
                </div>

                {/* Dependants */}
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-slate-700">Dependants</span>
                    <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${dependants?.answered === 'yes' ? 'bg-amber-100 text-amber-800' : 'bg-slate-200 text-slate-700'}`}>
                      {dependants?.answered ? dependants.answered.toUpperCase() : 'NO'}
                    </span>
                  </div>
                  {dependants?.answered === 'yes' && dependants.details && (
                    <p className="text-[11px] text-slate-600 mt-1 italic line-clamp-2">"{dependants.details}"</p>
                  )}
                </div>

                {/* Wills */}
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-slate-700">Will in Place</span>
                    <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${willInPlace?.answered === 'yes' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'}`}>
                      {willInPlace?.answered ? willInPlace.answered.toUpperCase() : 'NO'}
                    </span>
                  </div>
                  {willInPlace?.answered === 'yes' && willInPlace.details && (
                    <p className="text-[11px] text-slate-600 mt-1 italic line-clamp-2">"{willInPlace.details}"</p>
                  )}
                </div>

                {/* Power of Attorney */}
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-slate-700">Power of Attorney</span>
                    <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${powerOfAttorney?.answered === 'yes' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'}`}>
                      {powerOfAttorney?.answered ? powerOfAttorney.answered.toUpperCase() : 'NO'}
                    </span>
                  </div>
                  {powerOfAttorney?.answered === 'yes' && powerOfAttorney.details && (
                    <p className="text-[11px] text-slate-600 mt-1 italic line-clamp-2">"{powerOfAttorney.details}"</p>
                  )}
                </div>

                {/* Expected Life Changes */}
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-slate-700">Expected 5-Yr Life Changes</span>
                    <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${expectedLifeChanges?.answered === 'yes' ? 'bg-blue-100 text-blue-800' : 'bg-slate-200 text-slate-700'}`}>
                      {expectedLifeChanges?.answered ? expectedLifeChanges.answered.toUpperCase() : 'NO'}
                    </span>
                  </div>
                  {expectedLifeChanges?.answered === 'yes' && expectedLifeChanges.details && (
                    <p className="text-[11px] text-slate-600 mt-1 italic line-clamp-2">"{expectedLifeChanges.details}"</p>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* ============================================================ */}
        {/* STAGE 3: EMPLOYMENT, INCOME & EXPENDITURE                   */}
        {/* ============================================================ */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3.5 bg-slate-50 border-b border-slate-200">
            <div className="flex items-center gap-2.5">
              <div className="p-1.5 bg-emerald-100 text-emerald-700 rounded-lg">
                <Briefcase className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                  Stage 3: Employment, Income &amp; Expenditure
                </h4>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-lg text-right hidden sm:block">
                <span className="text-[10px] uppercase font-bold text-emerald-800 tracking-wider">
                  Total Income: <span className="font-mono text-emerald-950 font-bold">£{Math.round(totalAnnualIncome).toLocaleString('en-GB')}</span>
                </span>
              </div>
              <button
                type="button"
                onClick={() => onNavigateToStage(3)}
                className="inline-flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-800 hover:underline cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit Stage 3</span>
              </button>
            </div>
          </div>

          <div className="p-5 space-y-4 text-xs">
            {/* Income Streams Schedule Table */}
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <div className="bg-slate-50 px-4 py-2.5 border-b border-slate-200 flex items-center justify-between">
                <span className="font-bold text-slate-800 text-xs">
                  Income Streams ({effectiveIncomeStreams.length})
                </span>
                <span className="text-[11px] text-slate-500 font-medium">
                  Total Annual: £{Math.round(totalAnnualIncome).toLocaleString('en-GB')}
                </span>
              </div>
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-100/70 text-[10px] font-bold text-slate-600 uppercase tracking-wider border-b border-slate-200">
                    <th className="py-2.5 px-3 w-10 text-center">#</th>
                    <th className="py-2.5 px-3">Income Stream</th>
                    <th className="py-2.5 px-3">Employer / Business</th>
                    <th className="py-2.5 px-3 text-right">Annual Income</th>
                    {hasSecondClient && (
                      <th className="py-2.5 px-3 text-center">Client</th>
                    )}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {effectiveIncomeStreams.map((stream, idx) => (
                    <tr key={stream.id || idx} className="hover:bg-slate-50/60">
                      <td className="py-2.5 px-3 text-center text-slate-400 font-mono">{idx + 1}</td>
                      <td className="py-2.5 px-3 font-semibold text-slate-800">
                        {stream.employmentStatus || 'Employed'}
                      </td>
                      <td className="py-2.5 px-3 text-slate-700">
                        {stream.employerBusiness || '—'}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-semibold text-slate-900">
                        {stream.annualIncome || '—'}
                      </td>
                      {hasSecondClient && (
                        <td className="py-2.5 px-3 text-center">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                            {stream.owner === 'Client 2'
                              ? c2FirstName
                              : stream.owner === 'Joint'
                              ? 'Joint'
                              : c1FirstName}
                          </span>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Monthly Expenditure Schedule Table */}
            {expenditureItems && expenditureItems.length > 0 ? (
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="bg-slate-50 px-4 py-2.5 border-b border-slate-200 flex items-center justify-between">
                  <span className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                    <Receipt className="w-3.5 h-3.5 text-amber-600" />
                    Monthly Expenditure ({expenditureItems.length})
                  </span>
                  <span className="text-[11px] text-slate-500 font-medium">
                    Total Outgoings: {effectiveMonthlyExpenses}
                  </span>
                </div>
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-100/70 text-[10px] font-bold text-slate-600 uppercase tracking-wider border-b border-slate-200">
                      <th className="py-2.5 px-3 w-10 text-center">#</th>
                      <th className="py-2.5 px-3">Expenditure Type</th>
                      <th className="py-2.5 px-3 text-right">Monthly Amount</th>
                      <th className="py-2.5 px-3">Notes</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {expenditureItems.map((item, idx) => (
                      <tr key={item.id || idx} className="hover:bg-slate-50/60">
                        <td className="py-2.5 px-3 text-center text-slate-400 font-mono">{idx + 1}</td>
                        <td className="py-2.5 px-3 font-semibold text-slate-800">
                          {item.expenditureType || 'General Expenditure'}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono font-semibold text-slate-900">
                          {item.monthlyAmount || '—'}
                        </td>
                        <td className="py-2.5 px-3 text-slate-600 italic">
                          {item.notes || '—'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              /* Single Monthly Expenses Bar */
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Receipt className="w-4 h-4 text-amber-600" />
                  <span className="font-semibold text-slate-700">Monthly Expenses:</span>
                </div>
                <span className="font-mono font-bold text-slate-900 text-xs">
                  {effectiveMonthlyExpenses}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* ============================================================ */}
        {/* STAGE 4: ASSETS & LIABILITIES                               */}
        {/* ============================================================ */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3.5 bg-slate-50 border-b border-slate-200">
            <div className="flex items-center gap-2.5">
              <div className="p-1.5 bg-amber-100 text-amber-700 rounded-lg">
                <Coins className="w-4 h-4" />
              </div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Stage 4: Existing Assets &amp; Liabilities
              </h4>
            </div>
            <button
              type="button"
              onClick={() => onNavigateToStage(4)}
              className="inline-flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-800 hover:underline cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit Stage 4</span>
            </button>
          </div>

          <div className="p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-blue-50/70 border border-blue-200/80 rounded-xl">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-blue-900">Total Recorded Portfolio Assets:</span>
                <span className="text-sm font-bold text-blue-800">{formatGBP(totalAssetsValue)}</span>
              </div>
              <div className="text-xs text-blue-700 font-medium">
                {displayAssets.length} {displayAssets.length === 1 ? 'asset record' : 'asset records'}
              </div>
            </div>

            {/* Assets Table Summary */}
            {displayAssets.length > 0 ? (
              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold">
                    <tr>
                      <th className="py-2.5 px-3 w-12 text-center">#</th>
                      <th className="py-2.5 px-3">Asset Type</th>
                      <th className="py-2.5 px-3">Provider / Platform</th>
                      <th className="py-2.5 px-3 text-right">Approx Value</th>
                      {hasSecondClient && (
                        <th className="py-2.5 px-3 text-center">Client</th>
                      )}
                      <th className="py-2.5 px-3">Notes</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {displayAssets.map((asset, i) => {
                      const displayType = asset.assetType === 'Other' && asset.otherAssetType
                        ? `Other (${asset.otherAssetType})`
                        : (asset.assetType || 'Residential Property');
                      return (
                        <tr key={asset.id || i} className="hover:bg-slate-50/50">
                          <td className="py-2 px-3 text-center text-slate-400 font-mono">{i + 1}</td>
                          <td className="py-2 px-3 font-semibold text-slate-800">{displayType}</td>
                          <td className="py-2 px-3 text-slate-600">{asset.providerPlatform || '—'}</td>
                          <td className="py-2 px-3 text-right font-bold text-slate-900">{asset.approxValue || '—'}</td>
                          {hasSecondClient && (
                            <td className="py-2 px-3 text-center">
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                                {asset.owner === 'Client 2'
                                  ? c2FirstName
                                  : asset.owner === 'Joint'
                                  ? 'Joint'
                                  : c1FirstName}
                              </span>
                            </td>
                          )}
                          <td className="py-2 px-3 text-slate-500 text-[11px]">{asset.notes || '—'}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-xs text-slate-400 italic">No assets recorded in Stage 4.</p>
            )}

            {/* Liabilities Section */}
            {liabilities?.answered === 'yes' ? (
              <div className="space-y-2 pt-2 border-t border-slate-200">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800">
                    Existing Liabilities Schedule
                  </span>
                  <span className="text-xs font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                    {liabilityItems.length} {liabilityItems.length === 1 ? 'record' : 'records'}
                  </span>
                </div>
                {liabilityItems.length > 0 ? (
                  <div className="overflow-x-auto border border-slate-200 rounded-xl">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold">
                        <tr>
                          <th className="py-2.5 px-3 w-12 text-center">#</th>
                          <th className="py-2.5 px-3">Liability Type</th>
                          <th className="py-2.5 px-3 text-right">Amount Outstanding</th>
                          <th className="py-2.5 px-3 text-right">Monthly Repayment</th>
                          {hasSecondClient && (
                            <th className="py-2.5 px-3 text-center">Client</th>
                          )}
                          <th className="py-2.5 px-3">Notes</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {liabilityItems.map((item, i) => (
                          <tr key={item.id || i} className="hover:bg-slate-50/50">
                            <td className="py-2 px-3 text-center text-slate-400 font-mono">{i + 1}</td>
                            <td className="py-2 px-3 font-semibold text-slate-800">{item.liabilityType || 'Mortgage'}</td>
                            <td className="py-2 px-3 text-right font-bold text-rose-800">{item.amountOutstanding || '—'}</td>
                            <td className="py-2 px-3 text-right font-medium text-slate-900">{item.monthlyRepayment || '—'}</td>
                            {hasSecondClient && (
                              <td className="py-2 px-3 text-center">
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                                  {item.owner === 'Client 2'
                                    ? c2FirstName
                                    : item.owner === 'Joint'
                                    ? 'Joint'
                                    : c1FirstName}
                                </span>
                              </td>
                            )}
                            <td className="py-2 px-3 text-slate-500 text-[11px]">{item.notes || '—'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="p-3 bg-amber-50/50 rounded-xl border border-amber-200 text-xs text-amber-900">
                    {liabilities.details || 'Yes (No specific items recorded)'}
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center justify-between text-xs p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-600">Existing Mortgages &amp; Liabilities:</span>
                <span className="font-bold text-slate-700">No known liabilities</span>
              </div>
            )}
          </div>
        </div>

        {/* ============================================================ */}
        {/* STAGE 5: CAPACITY FOR INVESTMENT                             */}
        {/* ============================================================ */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3.5 bg-slate-50 border-b border-slate-200">
            <div className="flex items-center gap-2.5">
              <div className="p-1.5 bg-rose-100 text-rose-700 rounded-lg">
                <ShieldAlert className="w-4 h-4" />
              </div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Stage 5: Capacity for Investment &amp; Allowances
              </h4>
            </div>
            <button
              type="button"
              onClick={() => onNavigateToStage(5)}
              className="inline-flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-800 hover:underline cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit Stage 5</span>
            </button>
          </div>

          {hasSecondClient ? (
            <div className="p-5 grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Client 1 Review Column */}
              {(() => {
                const q1 = c1Stage5 || stage5Data;
                return (
                  <div className="border border-blue-200 rounded-xl p-4 bg-blue-50/20 space-y-3">
                    <div className="flex items-center justify-between pb-2 border-b border-blue-200/60">
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full bg-blue-600 text-white text-[10px] font-bold flex items-center justify-center">1</span>
                        <span className="font-bold text-xs text-blue-950">{c1FullName || 'Client 1 (Primary)'}</span>
                      </div>
                      <span className="text-[9px] font-bold uppercase px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 border border-blue-200">
                        Primary Client
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                      {/* Lump Sum */}
                      <div className="p-2.5 bg-white rounded-lg border border-slate-200/80">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-semibold text-slate-700 text-[11px]">Lump Sum</span>
                          <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q1?.availableLumpSum?.answered === 'yes' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'}`}>
                            {q1?.availableLumpSum?.answered ? q1.availableLumpSum.answered.toUpperCase() : 'NO'}
                          </span>
                        </div>
                        {q1?.availableLumpSum?.answered === 'yes' && q1.availableLumpSum.details && (
                          <p className="text-[11px] text-slate-900 font-bold font-mono">{q1.availableLumpSum.details}</p>
                        )}
                      </div>

                      {/* Monthly Investment */}
                      <div className="p-2.5 bg-white rounded-lg border border-slate-200/80">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-semibold text-slate-700 text-[11px]">Monthly Capacity</span>
                          <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q1?.availableMonthlyInvestment?.answered === 'yes' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'}`}>
                            {q1?.availableMonthlyInvestment?.answered ? q1.availableMonthlyInvestment.answered.toUpperCase() : 'NO'}
                          </span>
                        </div>
                        {q1?.availableMonthlyInvestment?.answered === 'yes' && q1.availableMonthlyInvestment.details && (
                          <p className="text-[11px] text-slate-900 font-bold font-mono">{q1.availableMonthlyInvestment.details}</p>
                        )}
                      </div>

                      {/* ISA Allowance */}
                      <div className="p-2.5 bg-white rounded-lg border border-slate-200/80">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-semibold text-slate-700 text-[11px]">ISA Used</span>
                          <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q1?.isaAllowanceUsed?.answered === 'yes' ? 'bg-blue-100 text-blue-800' : 'bg-slate-200 text-slate-700'}`}>
                            {q1?.isaAllowanceUsed?.answered ? q1.isaAllowanceUsed.answered.toUpperCase() : 'NO'}
                          </span>
                        </div>
                        {q1?.isaAllowanceUsed?.answered === 'yes' && q1.isaAllowanceUsed.details && (
                          <p className="text-[11px] text-slate-900 font-bold font-mono">{q1.isaAllowanceUsed.details}</p>
                        )}
                      </div>

                      {/* CGT Allowance */}
                      <div className="p-2.5 bg-white rounded-lg border border-slate-200/80">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-semibold text-slate-700 text-[11px]">CGT Used</span>
                          <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q1?.cgtAllowanceUsed?.answered === 'yes' ? 'bg-amber-100 text-amber-800' : 'bg-slate-200 text-slate-700'}`}>
                            {q1?.cgtAllowanceUsed?.answered ? q1.cgtAllowanceUsed.answered.toUpperCase() : 'NO'}
                          </span>
                        </div>
                        {q1?.cgtAllowanceUsed?.answered === 'yes' && q1.cgtAllowanceUsed.details && (
                          <p className="text-[11px] text-slate-900 font-bold font-mono">{q1.cgtAllowanceUsed.details}</p>
                        )}
                      </div>

                      {/* Gift Allowance */}
                      <div className="p-2.5 bg-white rounded-lg border border-slate-200/80 sm:col-span-2">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-semibold text-slate-700 text-[11px]">Gift Allowance Used</span>
                          <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q1?.giftAllowanceUsed?.answered === 'yes' ? 'bg-purple-100 text-purple-800' : 'bg-slate-200 text-slate-700'}`}>
                            {q1?.giftAllowanceUsed?.answered ? q1.giftAllowanceUsed.answered.toUpperCase() : 'NO'}
                          </span>
                        </div>
                        {q1?.giftAllowanceUsed?.answered === 'yes' && (
                          <div className="space-y-1.5 pt-0.5">
                            {q1.giftAllowanceUsed.details && (
                              <p className="text-[11px] text-slate-900 font-bold font-mono">Total: {q1.giftAllowanceUsed.details}</p>
                            )}
                            {q1.gifts && q1.gifts.length > 0 && q1.gifts.some(g => g.recipient || g.amountGifted) && (
                              <div className="border border-slate-200 rounded-lg overflow-hidden bg-slate-50/50 mt-1">
                                <table className="w-full text-left text-[10px]">
                                  <thead className="bg-slate-100 text-slate-600 font-semibold border-b border-slate-200">
                                    <tr>
                                      <th className="py-1 px-2">Recipient</th>
                                      <th className="py-1 px-2">Date</th>
                                      <th className="py-1 px-2 text-right">Amount</th>
                                    </tr>
                                  </thead>
                                  <tbody className="divide-y divide-slate-100">
                                    {q1.gifts.filter(g => g.recipient || g.amountGifted).map((g, idx) => (
                                      <tr key={g.id || idx}>
                                        <td className="py-1 px-2 font-medium text-slate-800 truncate max-w-[100px]">{g.recipient || '—'}</td>
                                        <td className="py-1 px-2 text-slate-500">{g.dateGifted || '—'}</td>
                                        <td className="py-1 px-2 text-right font-mono font-bold text-slate-900">{g.amountGifted || '—'}</td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Client 2 Review Column */}
              {(() => {
                const q2 = c2Stage5;
                return (
                  <div className="border border-indigo-200 rounded-xl p-4 bg-indigo-50/15 space-y-3">
                    <div className="flex items-center justify-between pb-2 border-b border-indigo-200/60">
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full bg-indigo-600 text-white text-[10px] font-bold flex items-center justify-center">2</span>
                        <span className="font-bold text-xs text-indigo-950">{c2FullName || 'Client 2 (Partner)'}</span>
                      </div>
                      <span className="text-[9px] font-bold uppercase px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 border border-indigo-200">
                        Partner / Spouse
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                      {/* Lump Sum */}
                      <div className="p-2.5 bg-white rounded-lg border border-slate-200/80">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-semibold text-slate-700 text-[11px]">Lump Sum</span>
                          <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q2?.availableLumpSum?.answered === 'yes' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'}`}>
                            {q2?.availableLumpSum?.answered ? q2.availableLumpSum.answered.toUpperCase() : 'NO'}
                          </span>
                        </div>
                        {q2?.availableLumpSum?.answered === 'yes' && q2.availableLumpSum.details && (
                          <p className="text-[11px] text-slate-900 font-bold font-mono">{q2.availableLumpSum.details}</p>
                        )}
                      </div>

                      {/* Monthly Investment */}
                      <div className="p-2.5 bg-white rounded-lg border border-slate-200/80">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-semibold text-slate-700 text-[11px]">Monthly Capacity</span>
                          <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q2?.availableMonthlyInvestment?.answered === 'yes' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'}`}>
                            {q2?.availableMonthlyInvestment?.answered ? q2.availableMonthlyInvestment.answered.toUpperCase() : 'NO'}
                          </span>
                        </div>
                        {q2?.availableMonthlyInvestment?.answered === 'yes' && q2.availableMonthlyInvestment.details && (
                          <p className="text-[11px] text-slate-900 font-bold font-mono">{q2.availableMonthlyInvestment.details}</p>
                        )}
                      </div>

                      {/* ISA Allowance */}
                      <div className="p-2.5 bg-white rounded-lg border border-slate-200/80">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-semibold text-slate-700 text-[11px]">ISA Used</span>
                          <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q2?.isaAllowanceUsed?.answered === 'yes' ? 'bg-blue-100 text-blue-800' : 'bg-slate-200 text-slate-700'}`}>
                            {q2?.isaAllowanceUsed?.answered ? q2.isaAllowanceUsed.answered.toUpperCase() : 'NO'}
                          </span>
                        </div>
                        {q2?.isaAllowanceUsed?.answered === 'yes' && q2.isaAllowanceUsed.details && (
                          <p className="text-[11px] text-slate-900 font-bold font-mono">{q2.isaAllowanceUsed.details}</p>
                        )}
                      </div>

                      {/* CGT Allowance */}
                      <div className="p-2.5 bg-white rounded-lg border border-slate-200/80">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-semibold text-slate-700 text-[11px]">CGT Used</span>
                          <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q2?.cgtAllowanceUsed?.answered === 'yes' ? 'bg-amber-100 text-amber-800' : 'bg-slate-200 text-slate-700'}`}>
                            {q2?.cgtAllowanceUsed?.answered ? q2.cgtAllowanceUsed.answered.toUpperCase() : 'NO'}
                          </span>
                        </div>
                        {q2?.cgtAllowanceUsed?.answered === 'yes' && q2.cgtAllowanceUsed.details && (
                          <p className="text-[11px] text-slate-900 font-bold font-mono">{q2.cgtAllowanceUsed.details}</p>
                        )}
                      </div>

                      {/* Gift Allowance */}
                      <div className="p-2.5 bg-white rounded-lg border border-slate-200/80 sm:col-span-2">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-semibold text-slate-700 text-[11px]">Gift Allowance Used</span>
                          <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${q2?.giftAllowanceUsed?.answered === 'yes' ? 'bg-purple-100 text-purple-800' : 'bg-slate-200 text-slate-700'}`}>
                            {q2?.giftAllowanceUsed?.answered ? q2.giftAllowanceUsed.answered.toUpperCase() : 'NO'}
                          </span>
                        </div>
                        {q2?.giftAllowanceUsed?.answered === 'yes' && (
                          <div className="space-y-1.5 pt-0.5">
                            {q2.giftAllowanceUsed.details && (
                              <p className="text-[11px] text-slate-900 font-bold font-mono">Total: {q2.giftAllowanceUsed.details}</p>
                            )}
                            {q2.gifts && q2.gifts.length > 0 && q2.gifts.some(g => g.recipient || g.amountGifted) && (
                              <div className="border border-slate-200 rounded-lg overflow-hidden bg-slate-50/50 mt-1">
                                <table className="w-full text-left text-[10px]">
                                  <thead className="bg-slate-100 text-slate-600 font-semibold border-b border-slate-200">
                                    <tr>
                                      <th className="py-1 px-2">Recipient</th>
                                      <th className="py-1 px-2">Date</th>
                                      <th className="py-1 px-2 text-right">Amount</th>
                                    </tr>
                                  </thead>
                                  <tbody className="divide-y divide-slate-100">
                                    {q2.gifts.filter(g => g.recipient || g.amountGifted).map((g, idx) => (
                                      <tr key={g.id || idx}>
                                        <td className="py-1 px-2 font-medium text-slate-800 truncate max-w-[100px]">{g.recipient || '—'}</td>
                                        <td className="py-1 px-2 text-slate-500">{g.dateGifted || '—'}</td>
                                        <td className="py-1 px-2 text-right font-mono font-bold text-slate-900">{g.amountGifted || '—'}</td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>
          ) : (
            <div className="p-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
              {/* Available Lump Sum */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70 space-y-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-slate-700">Available Lump Sum</span>
                  <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${(stage5Data || c1Stage5)?.availableLumpSum?.answered === 'yes' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'}`}>
                    {(stage5Data || c1Stage5)?.availableLumpSum?.answered ? (stage5Data || c1Stage5)!.availableLumpSum!.answered!.toUpperCase() : 'NO'}
                  </span>
                </div>
                {(stage5Data || c1Stage5)?.availableLumpSum?.answered === 'yes' && (stage5Data || c1Stage5)?.availableLumpSum?.details && (
                  <p className="text-[11px] text-slate-800 font-bold mt-1">Amount: {(stage5Data || c1Stage5)!.availableLumpSum!.details}</p>
                )}
              </div>

              {/* Monthly Investment */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70 space-y-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-slate-700">Monthly Investment</span>
                  <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${(stage5Data || c1Stage5)?.availableMonthlyInvestment?.answered === 'yes' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'}`}>
                    {(stage5Data || c1Stage5)?.availableMonthlyInvestment?.answered ? (stage5Data || c1Stage5)!.availableMonthlyInvestment!.answered!.toUpperCase() : 'NO'}
                  </span>
                </div>
                {(stage5Data || c1Stage5)?.availableMonthlyInvestment?.answered === 'yes' && (stage5Data || c1Stage5)?.availableMonthlyInvestment?.details && (
                  <p className="text-[11px] text-slate-800 font-bold mt-1">Capacity: {(stage5Data || c1Stage5)!.availableMonthlyInvestment!.details}</p>
                )}
              </div>

              {/* ISA Allowance Used */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70 space-y-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-slate-700">ISA Allowance Used</span>
                  <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${(stage5Data || c1Stage5)?.isaAllowanceUsed?.answered === 'yes' ? 'bg-blue-100 text-blue-800' : 'bg-slate-200 text-slate-700'}`}>
                    {(stage5Data || c1Stage5)?.isaAllowanceUsed?.answered ? (stage5Data || c1Stage5)!.isaAllowanceUsed!.answered!.toUpperCase() : 'NO'}
                  </span>
                </div>
                {(stage5Data || c1Stage5)?.isaAllowanceUsed?.answered === 'yes' && (stage5Data || c1Stage5)?.isaAllowanceUsed?.details && (
                  <p className="text-[11px] text-slate-800 font-bold mt-1">Amount: {(stage5Data || c1Stage5)!.isaAllowanceUsed!.details}</p>
                )}
              </div>

              {/* CGT Allowance Used */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70 space-y-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-slate-700">CGT Allowance Used</span>
                  <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${(stage5Data || c1Stage5)?.cgtAllowanceUsed?.answered === 'yes' ? 'bg-amber-100 text-amber-800' : 'bg-slate-200 text-slate-700'}`}>
                    {(stage5Data || c1Stage5)?.cgtAllowanceUsed?.answered ? (stage5Data || c1Stage5)!.cgtAllowanceUsed!.answered!.toUpperCase() : 'NO'}
                  </span>
                </div>
                {(stage5Data || c1Stage5)?.cgtAllowanceUsed?.answered === 'yes' && (stage5Data || c1Stage5)?.cgtAllowanceUsed?.details && (
                  <p className="text-[11px] text-slate-800 font-bold mt-1">Amount: {(stage5Data || c1Stage5)!.cgtAllowanceUsed!.details}</p>
                )}
              </div>

              {/* Gift Allowance Used */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70 space-y-1 sm:col-span-2 lg:col-span-2">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-slate-700">Gift Allowance Used</span>
                  <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${(stage5Data || c1Stage5)?.giftAllowanceUsed?.answered === 'yes' ? 'bg-purple-100 text-purple-800' : 'bg-slate-200 text-slate-700'}`}>
                    {(stage5Data || c1Stage5)?.giftAllowanceUsed?.answered ? (stage5Data || c1Stage5)!.giftAllowanceUsed!.answered!.toUpperCase() : 'NO'}
                  </span>
                </div>
                {(stage5Data || c1Stage5)?.giftAllowanceUsed?.answered === 'yes' && (
                  <div className="space-y-2 pt-1">
                    {(stage5Data || c1Stage5)?.giftAllowanceUsed?.details && (
                      <p className="text-[11px] text-slate-800 font-bold">Total Gifted: {(stage5Data || c1Stage5)!.giftAllowanceUsed!.details}</p>
                    )}
                    {(stage5Data || c1Stage5)?.gifts && (stage5Data || c1Stage5)!.gifts!.length > 0 && (stage5Data || c1Stage5)!.gifts!.some(g => g.recipient || g.amountGifted) && (
                      <div className="border border-slate-200 rounded-lg overflow-hidden bg-white mt-1.5">
                        <table className="w-full text-left text-[11px]">
                          <thead className="bg-slate-100/70 border-b border-slate-200 text-slate-600 font-semibold">
                            <tr>
                              <th className="py-1.5 px-2.5 w-8 text-center">#</th>
                              <th className="py-1.5 px-2.5">Recipient</th>
                              <th className="py-1.5 px-2.5">Date Gifted</th>
                              <th className="py-1.5 px-2.5 text-right">Amount Gifted</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {(stage5Data || c1Stage5)!.gifts!.filter(g => g.recipient || g.amountGifted).map((g, idx) => (
                              <tr key={g.id || idx} className="hover:bg-slate-50/50">
                                <td className="py-1 px-2.5 text-center text-slate-400 font-mono">{idx + 1}</td>
                                <td className="py-1 px-2.5 font-semibold text-slate-800">{g.recipient || '—'}</td>
                                <td className="py-1 px-2.5 text-slate-600">{g.dateGifted || '—'}</td>
                                <td className="py-1 px-2.5 text-right font-bold font-mono text-slate-900">{g.amountGifted || '—'}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* ============================================================ */}
        {/* STAGE 6: OBJECTIVES / RISK & INVESTMENT PREFERENCES          */}
        {/* ============================================================ */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3.5 bg-slate-50 border-b border-slate-200">
            <div className="flex items-center gap-2.5">
              <div className="p-1.5 bg-purple-100 text-purple-700 rounded-lg">
                <Target className="w-4 h-4" />
              </div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Stage 6: Objectives / Risk &amp; Investment Preferences
              </h4>
            </div>
            <button
              type="button"
              onClick={() => onNavigateToStage(6)}
              className="inline-flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-800 hover:underline cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit Stage 6</span>
            </button>
          </div>

          <div className="p-5 space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Primary Goals */}
              <div className="bg-slate-50/60 p-3.5 rounded-xl border border-slate-200/80 space-y-1.5">
                <span className="text-slate-500 text-[11px] block font-medium">Primary Goals</span>
                <div className="flex flex-wrap gap-1.5">
                  {primaryGoals.length > 0 ? (
                    primaryGoals.map(goal => (
                      <span key={goal} className="px-2 py-0.5 bg-blue-100 text-blue-800 font-bold rounded-md text-[11px]">
                        {goal}
                      </span>
                    ))
                  ) : (
                    <span className="text-slate-400 italic">None selected</span>
                  )}
                </div>
              </div>

              {/* Time Horizon */}
              <div className="bg-slate-50/60 p-3.5 rounded-xl border border-slate-200/80 space-y-1.5">
                <span className="text-slate-500 text-[11px] block font-medium">Time Horizon</span>
                <span className="px-2 py-0.5 bg-slate-200 text-slate-800 font-bold rounded-md inline-block">
                  {stage6Data.timeHorizon || '5-10 Years'}
                </span>
              </div>

              {/* Attitude to Risk */}
              <div className="bg-slate-50/60 p-3.5 rounded-xl border border-slate-200/80 space-y-1.5">
                <span className="text-slate-500 text-[11px] block font-medium">Attitude to Risk</span>
                <span className="px-2.5 py-0.5 bg-purple-100 text-purple-800 font-bold rounded-md inline-block">
                  {stage6Data.attitudeToRisk || 'Moderate'}
                </span>
              </div>
            </div>

            {/* Documented Objectives */}
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <span className="font-bold text-slate-900 block text-xs">Specific Client Objectives</span>
              <div className="space-y-1 text-slate-700 text-xs">
                <div className="flex items-start gap-2">
                  <span className="w-4 h-4 bg-blue-600 text-white rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">1</span>
                  <p className="leading-relaxed">{stage6Data.objective1 || 'Not specified'}</p>
                </div>
                <div className="flex items-start gap-2">
                  <span className="w-4 h-4 bg-blue-600 text-white rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">2</span>
                  <p className="leading-relaxed">{stage6Data.objective2 || 'Not specified'}</p>
                </div>
                {stage6Data.hasObjective3 && stage6Data.objective3 && (
                  <div className="flex items-start gap-2">
                    <span className="w-4 h-4 bg-blue-600 text-white rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">3</span>
                    <p className="leading-relaxed">{stage6Data.objective3}</p>
                  </div>
                )}
              </div>
            </div>

            {/* Ethical ESG */}
            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-slate-600">Ethical / ESG Investment Preferences:</span>
              <span className="font-semibold text-slate-800">
                {stage6Data.ethicalEsgPreferences?.answered === 'yes'
                  ? `Yes (${stage6Data.ethicalEsgPreferences.details || 'Specified'})`
                  : 'No specific requirements'}
              </span>
            </div>
          </div>
        </div>

        {/* ============================================================ */}
        {/* STAGE 7: ADDITIONAL NOTES                                    */}
        {/* ============================================================ */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3.5 bg-slate-50 border-b border-slate-200">
            <div className="flex items-center gap-2.5">
              <div className="p-1.5 bg-slate-100 text-slate-700 rounded-lg">
                <FileText className="w-4 h-4" />
              </div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Stage 7: Adviser Fact Find Notes
              </h4>
            </div>
            <button
              type="button"
              onClick={() => onNavigateToStage(7)}
              className="inline-flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-800 hover:underline cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit Stage 7</span>
            </button>
          </div>

          <div className="p-5">
            {stage7Data.additionalNotes ? (
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-800 whitespace-pre-wrap leading-relaxed">
                {stage7Data.additionalNotes}
              </div>
            ) : (
              <p className="text-xs text-slate-400 italic">No additional notes entered.</p>
            )}
          </div>
        </div>

      </div>

      {/* Confirmation / Completion Callout */}
      <div className="p-5 bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-emerald-600 text-white rounded-xl shadow-xs shrink-0">
            {isCompleted ? <CheckCircle2 className="w-5 h-5" /> : <Sparkles className="w-5 h-5" />}
          </div>
          <div>
            <h4 className="text-xs font-bold text-emerald-950 uppercase tracking-wider">
              {isCompleted ? 'Client Fact Find Completed & Verified' : 'Ready for Confirmation & Client Record Seal'}
            </h4>
            <p className="text-xs text-emerald-800 mt-0.5">
              {isCompleted 
                ? 'All 7 discovery stages are complete and saved. You can advance this client to the Ongoing category to activate their administrative checklist.'
                : 'Clicking "Complete & Save Fact Find" will lock in all 7 stages, update the client’s administrative profile, and enable the "Move into Ongoing" workflow.'}
            </p>
          </div>
        </div>

        {isCompleted && (clientCategory === 'potential' || !clientCategory) && onMoveToOngoing && (
          <button
            type="button"
            onClick={onMoveToOngoing}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer shrink-0"
          >
            <span>Move into Ongoing</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </form>
  );
};

