import React from 'react';
import { 
  Briefcase, 
  Plus, 
  Trash2, 
  PoundSterling, 
  Building2, 
  Receipt,
  Wallet,
  AlertCircle
} from 'lucide-react';
import { 
  FactFindIncomeStream, 
  FactFindEmploymentStatus,
  FactFindExpenditureItem,
  FactFindExpenditureType
} from '../../types';

export const EMPLOYMENT_STATUS_OPTIONS: { value: FactFindEmploymentStatus; label: string; description: string }[] = [
  { value: 'Employed', label: 'Employed', description: 'Full-time, part-time or fixed-term PAYE contract' },
  { value: 'Self-Employed', label: 'Self-Employed', description: 'Sole trader or partnership partner' },
  { value: 'Director / Business Owner', label: 'Director / Business Owner', description: 'Limited company director / shareholder' },
  { value: 'Retired', label: 'Retired', description: 'Drawing state, DB, or defined contribution pensions' },
  { value: 'Not Employed', label: 'Not Employed', description: 'Homemaker, student, or currently seeking employment' },
  { value: 'Other', label: 'Other', description: 'Other employment or contractor status' }
];

export const EXPENDITURE_TYPE_OPTIONS: { value: FactFindExpenditureType; label: string }[] = [
  { value: 'Utilities', label: 'Utilities' },
  { value: 'Rent/Mortgage', label: 'Rent/Mortgage' },
  { value: 'General Expenditure', label: 'General Expenditure' },
  { value: 'Other', label: 'Other' }
];

export const DEFAULT_1_INCOME_STREAM_ROW: FactFindIncomeStream = {
  id: 'income-stream-1',
  employmentStatus: 'Employed',
  employerBusiness: '',
  annualIncome: '',
  owner: 'Client 1'
};

export const DEFAULT_1_EXPENDITURE_ROW: FactFindExpenditureItem = {
  id: 'expenditure-1',
  expenditureType: 'General Expenditure',
  monthlyAmount: '',
  notes: ''
};

interface FactFindStage3Props {
  incomeStreams: FactFindIncomeStream[];
  onChangeIncomeStreams?: (streams: FactFindIncomeStream[]) => void;
  setIncomeStreams?: React.Dispatch<React.SetStateAction<FactFindIncomeStream[]>> | ((streams: FactFindIncomeStream[]) => void);
  expenditureItems?: FactFindExpenditureItem[];
  onChangeExpenditureItems?: (items: FactFindExpenditureItem[]) => void;
  setExpenditureItems?: React.Dispatch<React.SetStateAction<FactFindExpenditureItem[]>> | ((items: FactFindExpenditureItem[]) => void);
  monthlyExpenses: string;
  onChangeMonthlyExpenses?: (val: string) => void;
  setMonthlyExpenses?: React.Dispatch<React.SetStateAction<string>> | ((val: string) => void);
  fieldErrors?: Record<string, boolean>;
  onClearFieldError?: (key: string) => void;
  c1FullName?: string;
  c2FullName?: string;
  client1Name?: string;
  client2Name?: string;
  hasSecondClient?: boolean;
  adviser?: string;
  adviserName?: string;
  onBackToStage2: () => void;
  onSubmit: (e: React.FormEvent) => void;
}

export const FactFindStage3: React.FC<FactFindStage3Props> = ({
  incomeStreams,
  onChangeIncomeStreams,
  setIncomeStreams,
  expenditureItems,
  onChangeExpenditureItems,
  setExpenditureItems,
  monthlyExpenses,
  onChangeMonthlyExpenses,
  setMonthlyExpenses,
  fieldErrors = {},
  onClearFieldError,
  c1FullName,
  c2FullName,
  client1Name,
  client2Name,
  hasSecondClient,
  adviser,
  adviserName,
  onBackToStage2,
  onSubmit
}) => {
  const currentStreams = incomeStreams && incomeStreams.length > 0 ? incomeStreams : [DEFAULT_1_INCOME_STREAM_ROW];

  // Resolve effective expenditure columns (default initial view is 1 column with General Expenditure)
  const currentExpenditures: FactFindExpenditureItem[] = expenditureItems && expenditureItems.length > 0
    ? expenditureItems
    : [{
        id: 'expenditure-1',
        expenditureType: 'General Expenditure',
        monthlyAmount: monthlyExpenses || '',
        notes: ''
      }];
  const primaryClient = c1FullName || client1Name || 'Primary Client';
  const secondClient = c2FullName || client2Name;
  const leadAdviser = adviser || adviserName || 'Lead Adviser';
  const isJoint = hasSecondClient !== undefined ? hasSecondClient : Boolean(secondClient);

  // Extract first names for Client 1 & Client 2 dropdown
  const getFirstName = (fullName?: string, fallback = 'Client'): string => {
    const trimmed = (fullName || '').trim();
    if (!trimmed) return fallback;
    const first = trimmed.split(/\s+/)[0];
    return first || fallback;
  };

  const c1FirstName = getFirstName(c1FullName || client1Name, 'Client 1');
  const c2FirstName = getFirstName(c2FullName || client2Name, 'Client 2');

  const notifyChangeStreams = (updated: FactFindIncomeStream[]) => {
    if (typeof onChangeIncomeStreams === 'function') {
      onChangeIncomeStreams(updated);
    }
    if (typeof setIncomeStreams === 'function') {
      setIncomeStreams(updated);
    }
  };

  const notifyChangeExpenditures = (updated: FactFindExpenditureItem[]) => {
    if (typeof onChangeExpenditureItems === 'function') {
      onChangeExpenditureItems(updated);
    }
    if (typeof setExpenditureItems === 'function') {
      setExpenditureItems(updated);
    }

    // Keep monthlyExpenses string in sync as the formatted sum
    const totalExp = updated.reduce((sum, item) => {
      if (!item.monthlyAmount) return sum;
      const cleanNum = item.monthlyAmount.replace(/[^0-9.]/g, '');
      const val = parseFloat(cleanNum);
      return isNaN(val) ? sum : sum + val;
    }, 0);

    const formattedTotal = totalExp > 0 ? `£${Math.round(totalExp).toLocaleString('en-GB')}` : (updated[0]?.monthlyAmount || '');
    if (typeof onChangeMonthlyExpenses === 'function') {
      onChangeMonthlyExpenses(formattedTotal);
    }
    if (typeof setMonthlyExpenses === 'function') {
      setMonthlyExpenses(formattedTotal);
    }
  };

  const handleUpdateRow = (index: number, updates: Partial<FactFindIncomeStream>) => {
    const updated = [...currentStreams];
    updated[index] = { ...updated[index], ...updates };
    notifyChangeStreams(updated);
    if (updates.annualIncome && fieldErrors[`income-val-${index}`] && onClearFieldError) {
      onClearFieldError(`income-val-${index}`);
    }
  };

  const handleAddRow = () => {
    const newRow: FactFindIncomeStream = {
      id: `income-stream-${Date.now()}`,
      employmentStatus: 'Employed',
      employerBusiness: '',
      annualIncome: '',
      owner: 'Client 1'
    };
    notifyChangeStreams([...currentStreams, newRow]);
  };

  const handleRemoveRow = (index: number) => {
    if (currentStreams.length <= 1) {
      // Reset single row instead of empty
      notifyChangeStreams([{
        id: `income-stream-${Date.now()}`,
        employmentStatus: 'Employed',
        employerBusiness: '',
        annualIncome: '',
        owner: 'Client 1'
      }]);
      return;
    }
    const updated = currentStreams.filter((_, i) => i !== index);
    notifyChangeStreams(updated);
  };

  // Helper to format currency string on blur
  const formatPoundsOnBlur = (index: number, rawVal: string) => {
    if (!rawVal || !rawVal.trim()) return;
    const cleanNum = rawVal.replace(/[^0-9.]/g, '');
    const num = parseFloat(cleanNum);
    if (!isNaN(num)) {
      const formatted = '£' + Math.round(num).toLocaleString('en-GB');
      handleUpdateRow(index, { annualIncome: formatted });
    }
  };

  // Expenditure Handlers
  const handleUpdateExpenditure = (index: number, updates: Partial<FactFindExpenditureItem>) => {
    const updated = [...currentExpenditures];
    updated[index] = { ...updated[index], ...updates };
    notifyChangeExpenditures(updated);
    if (updates.monthlyAmount && (fieldErrors[`expenditure-val-${index}`] || fieldErrors['monthlyExpenses']) && onClearFieldError) {
      onClearFieldError(`expenditure-val-${index}`);
      onClearFieldError('monthlyExpenses');
    }
  };

  const handleAddExpenditureRow = () => {
    const newRow: FactFindExpenditureItem = {
      id: `expenditure-${Date.now()}`,
      expenditureType: 'General Expenditure',
      monthlyAmount: '',
      notes: ''
    };
    notifyChangeExpenditures([...currentExpenditures, newRow]);
  };

  const handleRemoveExpenditureRow = (index: number) => {
    if (currentExpenditures.length <= 1) {
      notifyChangeExpenditures([{
        id: `expenditure-${Date.now()}`,
        expenditureType: 'General Expenditure',
        monthlyAmount: '',
        notes: ''
      }]);
      return;
    }
    const updated = currentExpenditures.filter((_, i) => i !== index);
    notifyChangeExpenditures(updated);
  };

  const formatExpenditureAmountOnBlur = (index: number, rawVal: string) => {
    if (!rawVal || !rawVal.trim()) return;
    const cleanNum = rawVal.replace(/[^0-9.]/g, '');
    const num = parseFloat(cleanNum);
    if (!isNaN(num)) {
      const formatted = '£' + Math.round(num).toLocaleString('en-GB');
      handleUpdateExpenditure(index, { monthlyAmount: formatted });
    }
  };

  // Calculate live total annual income
  const totalAnnualIncome = currentStreams.reduce((sum, item) => {
    if (!item.annualIncome) return sum;
    const cleanNum = item.annualIncome.replace(/[^0-9.]/g, '');
    const val = parseFloat(cleanNum);
    return isNaN(val) ? sum : sum + val;
  }, 0);

  // Calculate live total monthly expenditure
  const totalMonthlyExpenditure = currentExpenditures.reduce((sum, item) => {
    if (!item.monthlyAmount) return sum;
    const cleanNum = item.monthlyAmount.replace(/[^0-9.]/g, '');
    const val = parseFloat(cleanNum);
    return isNaN(val) ? sum : sum + val;
  }, 0);

  return (
    <form id="fact-find-stage3-form" onSubmit={onSubmit} className="space-y-6 animate-in fade-in duration-150">
      
      {/* Context Summary Banner */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-100 text-blue-700 rounded-lg shrink-0">
            <Wallet className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-900">
              Stage 3: Employment, Income &amp; Expenditure
            </h3>
            <p className="text-[11px] text-slate-500">
              Client: <span className="font-semibold text-slate-800">{primaryClient}</span> {isJoint && secondClient ? `& ${secondClient}` : ''} • Adviser: {leadAdviser}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 self-start sm:self-auto flex-wrap sm:flex-nowrap">
          <div className="bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-xl text-right">
            <span className="text-[10px] uppercase font-bold text-emerald-800 tracking-wider block">
              Total Annual Income
            </span>
            <span className="text-sm font-bold text-emerald-950 font-mono">
              £{Math.round(totalAnnualIncome).toLocaleString('en-GB')}
            </span>
          </div>

          <div className="bg-amber-50 border border-amber-200 px-3 py-1.5 rounded-xl text-right">
            <span className="text-[10px] uppercase font-bold text-amber-800 tracking-wider block">
              Total Monthly Outgoings
            </span>
            <span className="text-sm font-bold text-amber-950 font-mono">
              £{Math.round(totalMonthlyExpenditure).toLocaleString('en-GB')}
            </span>
          </div>

          <button
            type="button"
            onClick={onBackToStage2}
            className="text-xs font-semibold text-blue-600 hover:text-blue-800 hover:underline flex items-center gap-1 shrink-0 cursor-pointer ml-1"
          >
            ← Back to Stage 2
          </button>
        </div>
      </div>

      {/* Income Streams Table Container */}
      <div className="border border-slate-200 rounded-xl bg-white shadow-2xs overflow-hidden">
        
        {/* Table Header Controls */}
        <div className="p-4 border-b border-slate-100 bg-slate-50/70 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h4 className="text-xs font-bold text-slate-900 flex items-center gap-2">
              <span>Income Streams Schedule</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-100 text-blue-800 border border-blue-200">
                {currentStreams.length} {currentStreams.length === 1 ? 'Stream' : 'Streams'} Listed
              </span>
            </h4>
            <p className="text-[11px] text-slate-500">
              Capture employment, self-employment, pensions, dividends, and recurring income streams.
            </p>
          </div>

          <button
            type="button"
            onClick={handleAddRow}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition cursor-pointer self-start sm:self-auto"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ Add Income Stream</span>
          </button>
        </div>

        {/* Responsive Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-100/80 text-[11px] font-bold text-slate-700 uppercase tracking-wider border-b border-slate-200">
                <th className="py-3 px-3 w-10 text-center">#</th>
                <th className="py-3 px-3 min-w-[200px] w-1/3">
                  Income Stream <span className="text-rose-500">*</span>
                </th>
                <th className="py-3 px-3 min-w-[200px] w-1/3">
                  Employer / Business
                </th>
                <th className="py-3 px-3 min-w-[160px] w-1/4">
                  Annual Income <span className="text-rose-500">*</span> <span className="text-slate-400 font-normal font-sans">(£)</span>
                </th>
                {isJoint && (
                  <th className="py-3 px-3 min-w-[140px] w-1/5">
                    Client
                  </th>
                )}
                <th className="py-3 px-3 w-12 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {currentStreams.map((stream, index) => {
                const valError = fieldErrors[`income-val-${index}`];

                return (
                  <tr 
                    key={stream.id || `income-${index}`} 
                    className="hover:bg-slate-50/70 transition-colors group align-top"
                  >
                    {/* Row Index */}
                    <td className="py-3.5 px-3 text-center text-slate-400 font-mono font-medium pt-4">
                      {index + 1}
                    </td>

                    {/* Column 1: Income Stream Dropdown */}
                    <td className="py-3 px-3 space-y-1">
                      <select
                        value={stream.employmentStatus || 'Employed'}
                        onChange={(e) => {
                          const val = e.target.value as FactFindEmploymentStatus;
                          handleUpdateRow(index, { employmentStatus: val });
                        }}
                        className="w-full py-2 px-2.5 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-900 font-medium cursor-pointer"
                      >
                        {EMPLOYMENT_STATUS_OPTIONS.map((opt) => (
                          <option key={opt.value} value={opt.value}>
                            {opt.label}
                          </option>
                        ))}
                      </select>
                    </td>

                    {/* Column 2: Employer / Business (Non-mandatory) */}
                    <td className="py-3 px-3 space-y-1">
                      <div className="relative">
                        <Building2 className="w-3.5 h-3.5 absolute left-2.5 top-2.5 pointer-events-none text-slate-400" />
                        <input
                          type="text"
                          value={stream.employerBusiness || ''}
                          onChange={(e) => handleUpdateRow(index, { employerBusiness: e.target.value })}
                          placeholder="e.g. Acme Corp Ltd / Self-Employed"
                          className="w-full py-1.5 pl-8 pr-2.5 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-900 transition"
                        />
                      </div>
                    </td>

                    {/* Column 3: Annual Income */}
                    <td className="py-3 px-3 space-y-1">
                      <div className="relative">
                        <PoundSterling className={`w-3.5 h-3.5 absolute left-2.5 top-2.5 pointer-events-none ${valError ? 'text-rose-500' : 'text-slate-400'}`} />
                        <input
                          type="text"
                          value={stream.annualIncome || ''}
                          onChange={(e) => handleUpdateRow(index, { annualIncome: e.target.value })}
                          onBlur={(e) => formatPoundsOnBlur(index, e.target.value)}
                          placeholder="e.g. £55,000"
                          className={`w-full py-1.5 pl-8 pr-2.5 text-xs rounded-lg border bg-white focus:outline-none transition font-mono font-medium ${
                            valError
                              ? 'border-rose-400 focus:ring-2 focus:ring-rose-200 bg-rose-50/20 text-slate-900'
                              : 'border-slate-300 focus:ring-2 focus:ring-blue-500 text-slate-900'
                          }`}
                        />
                      </div>
                      {valError && (
                        <p className="text-[10px] text-rose-600 font-semibold flex items-center gap-1">
                          <AlertCircle className="w-3 h-3 shrink-0" />
                          Annual income is required
                        </p>
                      )}
                    </td>

                    {/* Column 4: Client (Rendered if 2 clients in Stage 1) */}
                    {isJoint && (
                      <td className="py-3 px-3 space-y-1">
                        <select
                          value={stream.owner || 'Client 1'}
                          onChange={(e) => handleUpdateRow(index, { owner: e.target.value })}
                          className="w-full py-2 px-2.5 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-900 font-medium cursor-pointer"
                        >
                          <option value="Client 1">{c1FirstName}</option>
                          <option value="Client 2">{c2FirstName}</option>
                          <option value="Joint">Joint</option>
                        </select>
                      </td>
                    )}

                    {/* Action: Delete */}
                    <td className="py-3 px-3 text-center">
                      <button
                        type="button"
                        onClick={() => handleRemoveRow(index)}
                        title={currentStreams.length <= 1 ? 'Clear row' : 'Remove income stream'}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Table Footer Helper */}
        <div className="p-3 bg-slate-50/80 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between text-[11px] text-slate-500 gap-2">
          <span>Click &ldquo;+ Add Income Stream&rdquo; to record secondary employment, pensions, or other revenue streams.</span>
          <span className="font-semibold text-slate-700">
            Total Annual: <span className="font-mono text-slate-900">£{Math.round(totalAnnualIncome).toLocaleString('en-GB')}</span>
          </span>
        </div>
      </div>

      {/* ============================================================ */}
      {/* SECTION 2: MONTHLY EXPENDITURE SCHEDULE (ROW-BASED TABLE)    */}
      {/* ============================================================ */}
      <div className="border border-slate-200 rounded-xl overflow-hidden bg-white shadow-2xs">
        
        {/* Table Header Controls */}
        <div className="p-4 border-b border-slate-100 bg-slate-50/70 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h4 className="text-xs font-bold text-slate-900 flex items-center gap-2">
              <span>Monthly Expenditure Schedule</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-100 text-amber-800 border border-amber-200">
                {currentExpenditures.length} {currentExpenditures.length === 1 ? 'Outgoing' : 'Outgoings'} Listed
              </span>
            </h4>
            <p className="text-[11px] text-slate-500">
              Record committed living costs (utilities, rent/mortgage, general outgoings).
            </p>
          </div>

          <button
            type="button"
            onClick={handleAddExpenditureRow}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-lg transition cursor-pointer self-start sm:self-auto"
          >
            <Plus className="w-3.5 h-3.5 text-amber-700" />
            <span>+ Add Expenditure</span>
          </button>
        </div>

        {/* Responsive Row-based Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-100/80 text-[11px] font-bold text-slate-700 uppercase tracking-wider border-b border-slate-200">
                <th className="py-3 px-3 w-10 text-center">#</th>
                <th className="py-3 px-3 min-w-[200px] w-1/3">
                  Expenditure Type <span className="text-rose-500">*</span>
                </th>
                <th className="py-3 px-3 min-w-[160px] w-1/4">
                  Monthly Amount <span className="text-rose-500">*</span> <span className="text-slate-400 font-normal font-sans">(£)</span>
                </th>
                <th className="py-3 px-3 min-w-[220px]">
                  Notes
                </th>
                <th className="py-3 px-3 w-12 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {currentExpenditures.map((item, index) => {
                const valError = fieldErrors[`expenditure-val-${index}`] || (index === 0 && fieldErrors['monthlyExpenses']);

                return (
                  <tr
                    key={item.id || `expenditure-${index}`}
                    className="hover:bg-slate-50/70 transition-colors group align-top"
                  >
                    {/* Row Index */}
                    <td className="py-3.5 px-3 text-center text-slate-400 font-mono font-medium pt-4">
                      {index + 1}
                    </td>

                    {/* Column 1: Expenditure Type Dropdown */}
                    <td className="py-3 px-3 space-y-1">
                      <select
                        value={item.expenditureType || 'General Expenditure'}
                        onChange={(e) => {
                          const val = e.target.value as FactFindExpenditureType;
                          handleUpdateExpenditure(index, { expenditureType: val });
                        }}
                        className="w-full py-2 px-2.5 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-900 font-medium cursor-pointer"
                      >
                        {EXPENDITURE_TYPE_OPTIONS.map((opt) => (
                          <option key={opt.value} value={opt.value}>
                            {opt.label}
                          </option>
                        ))}
                      </select>
                    </td>

                    {/* Column 2: Monthly Amount */}
                    <td className="py-3 px-3 space-y-1">
                      <div className="relative">
                        <PoundSterling className={`w-3.5 h-3.5 absolute left-2.5 top-2.5 pointer-events-none ${valError ? 'text-rose-500' : 'text-slate-400'}`} />
                        <input
                          type="text"
                          value={item.monthlyAmount || ''}
                          onChange={(e) => handleUpdateExpenditure(index, { monthlyAmount: e.target.value })}
                          onBlur={(e) => formatExpenditureAmountOnBlur(index, e.target.value)}
                          placeholder="e.g. £1,500"
                          className={`w-full py-1.5 pl-8 pr-2.5 text-xs rounded-lg border bg-white focus:outline-none transition font-mono font-medium ${
                            valError
                              ? 'border-rose-400 focus:ring-2 focus:ring-rose-200 bg-rose-50/20 text-slate-900'
                              : 'border-slate-300 focus:ring-2 focus:ring-blue-500 text-slate-900'
                          }`}
                        />
                      </div>
                      {valError && (
                        <p className="text-[10px] text-rose-600 font-semibold flex items-center gap-1">
                          <AlertCircle className="w-3 h-3 shrink-0" />
                          Monthly amount is required
                        </p>
                      )}
                    </td>

                    {/* Column 3: Notes */}
                    <td className="py-3 px-3 space-y-1">
                      <input
                        type="text"
                        value={item.notes || ''}
                        onChange={(e) => handleUpdateExpenditure(index, { notes: e.target.value })}
                        placeholder="Notes / breakdown details..."
                        className="w-full py-1.5 px-2.5 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-900 transition"
                      />
                    </td>

                    {/* Action: Delete */}
                    <td className="py-3 px-3 text-center">
                      <button
                        type="button"
                        onClick={() => handleRemoveExpenditureRow(index)}
                        title={currentExpenditures.length <= 1 ? 'Clear row' : 'Remove expenditure'}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Table Footer Helper */}
        <div className="p-3 bg-slate-50/80 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between text-[11px] text-slate-500 gap-2">
          <span>The default view provides 1 row with &ldquo;General Expenditure&rdquo;. Click &ldquo;+ Add Expenditure&rdquo; for itemised budgeting.</span>
          <span className="font-semibold text-slate-700">
            Total Monthly: <span className="font-mono text-slate-900">£{Math.round(totalMonthlyExpenditure).toLocaleString('en-GB')}</span>
          </span>
        </div>
      </div>

    </form>
  );
};
