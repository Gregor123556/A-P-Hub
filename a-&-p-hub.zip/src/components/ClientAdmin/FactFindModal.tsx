import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  User, 
  Users, 
  Calendar, 
  Mail, 
  Phone, 
  MapPin,
  CheckCircle2, 
  ArrowRight, 
  ArrowLeft, 
  Save, 
  FileSpreadsheet, 
  AlertCircle,
  Briefcase,
  HeartHandshake,
  ShieldAlert,
  Baby,
  Scroll,
  FileCheck2,
  Hourglass,
  Copy,
  Building2,
  Building,
  PoundSterling,
  Receipt,
  Wallet,
  Coins,
  SlidersHorizontal,
  Sparkles
} from 'lucide-react';
import { 
  ClientAdminEntry, 
  ClientFactFind, 
  FactFindStage1, 
  FactFindStage2, 
  FactFindStage2Personal,
  FactFindStage3 as FactFindStage3Type,
  FactFindStage4 as FactFindStage4Type,
  FactFindStage5 as FactFindStage5Type,
  FactFindStage5Personal,
  FactFindStage6 as FactFindStage6Type,
  FactFindStage7 as FactFindStage7Type,
  FactFindPrimaryGoal,
  FactFindAssetItem,
  FactFindLiabilityItem,
  FactFindMaritalStatus, 
  FactFindEmploymentStatus,
  FactFindYesNoQuestion,
  FactFindIncomeStream,
  FactFindExpenditureItem,
  FactFindGiftItem 
} from '../../types';
import { FactFindStage2 as FactFindStage2Component, DEFAULT_VULNERABILITY_NO_TEXT } from './FactFindStage2';
import { FactFindStage3, DEFAULT_1_INCOME_STREAM_ROW, DEFAULT_1_EXPENDITURE_ROW } from './FactFindStage3';
import { FactFindStage4, DEFAULT_1_ASSET_ROW, DEFAULT_1_LIABILITY_ROW } from './FactFindStage4';
import { FactFindStage5, Stage5CapacityState, DEFAULT_1_GIFT_ROW } from './FactFindStage5';
import { FactFindStage6, Stage6ObjectivesRiskState } from './FactFindStage6';
import { FactFindStage7, Stage7AdditionalNotesState } from './FactFindStage7';
import { FactFindStage8 } from './FactFindStage8';
import { DateOfBirthInput } from './DateOfBirthInput';
import { updateClientFactFind, removeUndefinedDeep, moveClientCategory } from '../../services/clientAdminService';
import { 
  getTodayDDMMYYYY, 
  convertDDMMYYYYToYYYYMMDD, 
  convertYYYYMMDDToDDMMYYYY 
} from '../../utils/dateUtils';

const DEFAULT_STAGE2_PERSONAL: FactFindStage2Personal = {
  vulnerability: { answered: '', details: '' },
  pepSanctions: { answered: '', details: '' },
  dependants: { answered: '', details: '' },
  willInPlace: { answered: '', details: '' },
  powerOfAttorney: { answered: '', details: '' },
  expectedLifeChanges: { answered: '', details: '' }
};

const DEFAULT_STAGE5_CAPACITY: Stage5CapacityState = {
  availableLumpSum: { answered: '', details: '' },
  availableMonthlyInvestment: { answered: '', details: '' },
  isaAllowanceUsed: { answered: '', details: '' },
  cgtAllowanceUsed: { answered: '', details: '' },
  giftAllowanceUsed: { answered: '', details: '' },
  gifts: [DEFAULT_1_GIFT_ROW]
};

const DEFAULT_STAGE6_OBJECTIVES_RISK: Stage6ObjectivesRiskState = {
  primaryGoals: [],
  primaryGoal: '',
  timeHorizon: '',
  objective1: '',
  objective2: '',
  objective3: '',
  hasObjective3: false,
  attitudeToRisk: '',
  ethicalEsgPreferences: { answered: '', details: '' }
};

const DEFAULT_STAGE7_ADDITIONAL_NOTES: Stage7AdditionalNotesState = {
  additionalNotes: ''
};

interface FactFindModalProps {
  client: ClientAdminEntry | null;
  isOpen: boolean;
  onClose: () => void;
  onClientUpdated?: () => void;
}

const MARITAL_STATUS_OPTIONS: { value: FactFindMaritalStatus; label: string; description: string }[] = [
  { value: 'Single', label: 'Single', description: 'Never married or in a registered civil partnership' },
  { value: 'Married', label: 'Married', description: 'Married or in a legally registered civil partnership' },
  { value: 'Divorced', label: 'Divorced', description: 'Marriage or civil partnership legally dissolved' },
  { value: 'Widowed', label: 'Widowed', description: 'Surviving spouse / civil partner' },
];

const EMPLOYMENT_STATUS_OPTIONS: { value: FactFindEmploymentStatus; label: string; description: string }[] = [
  { value: 'Employed', label: 'Employed', description: 'Full-time, part-time or fixed-term PAYE contract' },
  { value: 'Self-Employed', label: 'Self-Employed', description: 'Sole trader or partnership partner' },
  { value: 'Director / Business Owner', label: 'Director / Business Owner', description: 'Limited company director / shareholder' },
  { value: 'Retired', label: 'Retired', description: 'Drawing state, DB, or defined contribution pensions' },
  { value: 'Not Employed', label: 'Not Employed', description: 'Homemaker, student, or currently seeking employment' },
  { value: 'Other', label: 'Other', description: 'Other employment or contractor status' }
];

interface YesNoFieldConfig {
  key: keyof FactFindStage2Personal;
  label: string;
  question: string;
  icon: React.ComponentType<{ className?: string }>;
  helper: string;
  placeholder: string;
}

const YES_NO_QUESTIONS: YesNoFieldConfig[] = [
  {
    key: 'vulnerability',
    label: 'Vulnerability Identified?',
    question: 'Any FCA Consumer Duty vulnerability indicators identified?',
    icon: HeartHandshake,
    helper: '',
    placeholder: 'Please provide assessment details...'
  },
  {
    key: 'pepSanctions',
    label: 'PEP/Sanctions Concerns?',
    question: 'Is the client a PEP or subject to sanctions?',
    icon: ShieldAlert,
    helper: '',
    placeholder: 'Please specify details...'
  },
  {
    key: 'dependants',
    label: 'Dependants?',
    question: 'Does the client have financially dependent family members?',
    icon: Baby,
    helper: '',
    placeholder: 'Please list dependants...'
  },
  {
    key: 'willInPlace',
    label: 'Will in Place?',
    question: 'Does the client have a valid Will in place?',
    icon: Scroll,
    helper: '',
    placeholder: 'Please provide Will details...'
  },
  {
    key: 'powerOfAttorney',
    label: 'Power of Attorney?',
    question: 'Is a Lasting Power of Attorney (LPA) in place?',
    icon: FileCheck2,
    helper: '',
    placeholder: 'Please provide LPA details...'
  },
  {
    key: 'expectedLifeChanges',
    label: 'Expected Life Changes in 5 Years?',
    question: 'Any major life or financial changes expected in the next 5 years?',
    icon: Hourglass,
    helper: '',
    placeholder: 'Please detail expected life events...'
  }
];

export const FactFindModal: React.FC<FactFindModalProps> = ({
  client,
  isOpen,
  onClose,
  onClientUpdated
}) => {
  const [currentStage, setCurrentStage] = useState<number>(1);
  
  // Stage 1 State: Client 1 (5 fields: Full Name, DOB, Email, Phone, Address)
  const [hasSecondClient, setHasSecondClient] = useState<boolean>(false);
  const [c1FullName, setC1FullName] = useState<string>('');
  const [c1Dob, setC1Dob] = useState<string>('');
  const [c1Email, setC1Email] = useState<string>('');
  const [c1Phone, setC1Phone] = useState<string>('');
  const [c1Address, setC1Address] = useState<string>('');

  // Stage 1 State: Client 2 (5 fields: Full Name, DOB, Email, Phone, Address)
  const [c2FullName, setC2FullName] = useState<string>('');
  const [c2Dob, setC2Dob] = useState<string>('');
  const [c2Email, setC2Email] = useState<string>('');
  const [c2Phone, setC2Phone] = useState<string>('');
  const [c2Address, setC2Address] = useState<string>('');

  // Meeting Meta
  const [meetingDate, setMeetingDate] = useState<string>('');
  const [adviser, setAdviser] = useState<string>('Sam Adams');

  // Stage 2: Personal Situation State (Client 1 and Client 2 dual state)
  const [maritalStatus, setMaritalStatus] = useState<FactFindMaritalStatus | ''>('');
  const [c1Stage2, setC1Stage2] = useState<FactFindStage2Personal>(DEFAULT_STAGE2_PERSONAL);
  const [c2Stage2, setC2Stage2] = useState<FactFindStage2Personal>(DEFAULT_STAGE2_PERSONAL);

  // Stage 3: Employment & Income Streams State (Table format + Monthly Expenditure Table)
  const [incomeStreams, setIncomeStreams] = useState<FactFindIncomeStream[]>([DEFAULT_1_INCOME_STREAM_ROW]);
  const [expenditureItems, setExpenditureItems] = useState<FactFindExpenditureItem[]>([DEFAULT_1_EXPENDITURE_ROW]);
  const [monthlyExpenses, setMonthlyExpenses] = useState<string>('');

  // Legacy Stage 3 state kept for backwards-compatibility bindings if needed
  const [c1EmploymentStatus, setC1EmploymentStatus] = useState<FactFindEmploymentStatus | ''>('Employed');
  const [c1Employer, setC1Employer] = useState<string>('');
  const [c1AnnualIncome, setC1AnnualIncome] = useState<string>('');
  const [c1MonthlyExpenses, setC1MonthlyExpenses] = useState<string>('');
  const [c1OtherIncome, setC1OtherIncome] = useState<FactFindYesNoQuestion>({ answered: '', details: '' });

  const [c2EmploymentStatus, setC2EmploymentStatus] = useState<FactFindEmploymentStatus | ''>('Employed');
  const [c2Employer, setC2Employer] = useState<string>('');
  const [c2AnnualIncome, setC2AnnualIncome] = useState<string>('');
  const [c2MonthlyExpenses, setC2MonthlyExpenses] = useState<string>('');
  const [c2OtherIncome, setC2OtherIncome] = useState<FactFindYesNoQuestion>({ answered: '', details: '' });

  // Stage 4: Assets and Liabilities State
  const [assets, setAssets] = useState<FactFindAssetItem[]>([DEFAULT_1_ASSET_ROW]);
  const [liabilityItems, setLiabilityItems] = useState<FactFindLiabilityItem[]>([DEFAULT_1_LIABILITY_ROW]);
  const [liabilities, setLiabilities] = useState<FactFindYesNoQuestion>({ answered: '', details: '' });

  // Stage 5: Capacity State
  const [stage5Data, setStage5Data] = useState<Stage5CapacityState>(DEFAULT_STAGE5_CAPACITY);
  const [c1Stage5, setC1Stage5] = useState<Stage5CapacityState>(DEFAULT_STAGE5_CAPACITY);
  const [c2Stage5, setC2Stage5] = useState<Stage5CapacityState>(DEFAULT_STAGE5_CAPACITY);

  // Stage 6: Objectives / Risk & Investment Preferences State
  const [stage6Data, setStage6Data] = useState<Stage6ObjectivesRiskState>(DEFAULT_STAGE6_OBJECTIVES_RISK);

  // Stage 7: Additional Notes State
  const [stage7Data, setStage7Data] = useState<Stage7AdditionalNotesState>(DEFAULT_STAGE7_ADDITIONAL_NOTES);

  const [isCompletedState, setIsCompletedState] = useState<boolean>(client?.factFind?.status === 'completed');
  const [validationError, setValidationError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, boolean>>({});
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);

  const activeClientIdRef = useRef<string | null>(null);
  const wasOpenRef = useRef<boolean>(false);

  // Initialize or synchronize state from incoming client strictly upon opening or client switch
  useEffect(() => {
    if (!isOpen) {
      wasOpenRef.current = false;
      activeClientIdRef.current = null;
      return;
    }

    if (client && (!wasOpenRef.current || activeClientIdRef.current !== client.id)) {
      wasOpenRef.current = true;
      activeClientIdRef.current = client.id;
      setIsCompletedState(client.factFind?.status === 'completed');
      const todayStr = getTodayDDMMYYYY();
      const existingFF = client.factFind;

      if (existingFF) {
        setCurrentStage(existingFF.currentStage || 1);
        
        // Stage 1 sync
        if (existingFF.stage1) {
          setHasSecondClient(Boolean(existingFF.stage1.hasSecondClient));
          setC1FullName(existingFF.stage1.client1?.fullName || client.clientName || '');
          setC1Dob(existingFF.stage1.client1?.dateOfBirth || '');
          setC1Email(existingFF.stage1.client1?.email || client.email || '');
          setC1Phone(existingFF.stage1.client1?.phone || client.phone || '');
          setC1Address(existingFF.stage1.client1?.address || '');

          if (existingFF.stage1.client2) {
            setC2FullName(existingFF.stage1.client2.fullName || '');
            setC2Dob(existingFF.stage1.client2.dateOfBirth || '');
            setC2Email(existingFF.stage1.client2.email || '');
            setC2Phone(existingFF.stage1.client2.phone || '');
            setC2Address(existingFF.stage1.client2.address || '');
          } else {
            if (client.clientName && client.clientName.includes('&')) {
              const parts = client.clientName.split('&').map(s => s.trim());
              setC1FullName(parts[0] || '');
              setC2FullName(parts[1] || '');
              setHasSecondClient(true);
            } else {
              setC2FullName('');
              setC2Dob('');
              setC2Email('');
              setC2Phone('');
              setC2Address('');
            }
          }

          setMeetingDate(existingFF.stage1.meetingDate || todayStr);
          setAdviser(existingFF.stage1.adviser || client.adviserName || 'Sam Adams');
        }

        // Stage 2 sync helper
        const parsePersonalStage2 = (src?: FactFindStage2Personal | FactFindStage2): FactFindStage2Personal => {
          if (!src) return { ...DEFAULT_STAGE2_PERSONAL };
          const vuln = src.vulnerability;
          return {
            vulnerability: {
              answered: vuln?.answered || '',
              details: (vuln?.answered === 'no' && !vuln?.details?.trim())
                ? DEFAULT_VULNERABILITY_NO_TEXT
                : (vuln?.details || '')
            },
            pepSanctions: src.pepSanctions ? { answered: src.pepSanctions.answered || '', details: src.pepSanctions.details || '' } : { answered: '', details: '' },
            dependants: src.dependants ? { answered: src.dependants.answered || '', details: src.dependants.details || '' } : { answered: '', details: '' },
            willInPlace: src.willInPlace ? { answered: src.willInPlace.answered || '', details: src.willInPlace.details || '' } : { answered: '', details: '' },
            powerOfAttorney: src.powerOfAttorney ? { answered: src.powerOfAttorney.answered || '', details: src.powerOfAttorney.details || '' } : { answered: '', details: '' },
            expectedLifeChanges: src.expectedLifeChanges ? { answered: src.expectedLifeChanges.answered || '', details: src.expectedLifeChanges.details || '' } : { answered: '', details: '' }
          };
        };

        if (existingFF.stage2) {
          setMaritalStatus(existingFF.stage2.maritalStatus || (existingFF.stage1?.hasSecondClient ? 'Married' : ''));
          const c1Parsed = parsePersonalStage2(existingFF.stage2.client1 || existingFF.stage2);
          const c2Parsed = parsePersonalStage2(existingFF.stage2.client2);
          setC1Stage2(c1Parsed);
          setC2Stage2(c2Parsed);
        } else {
          setMaritalStatus(existingFF.stage1?.hasSecondClient ? 'Married' : '');
          setC1Stage2({ ...DEFAULT_STAGE2_PERSONAL });
          setC2Stage2({ ...DEFAULT_STAGE2_PERSONAL });
        }

        // Stage 3 sync
        if (existingFF.stage3) {
          const s3 = existingFF.stage3;
          if (Array.isArray(s3.incomeStreams) && s3.incomeStreams.length > 0) {
            setIncomeStreams(s3.incomeStreams);
          } else {
            // Migration fallback from legacy fields
            const streams: FactFindIncomeStream[] = [];
            const c1Source = s3.client1 || s3;
            if (c1Source && (c1Source.employer || c1Source.annualIncomeApprox || c1Source.employmentStatus)) {
              streams.push({
                id: 'income-1',
                employmentStatus: (c1Source.employmentStatus as FactFindEmploymentStatus) || 'Employed',
                employerBusiness: c1Source.employer || '',
                annualIncome: c1Source.annualIncomeApprox || ''
              });
            }
            if (s3.client2 && (s3.client2.employer || s3.client2.annualIncomeApprox || s3.client2.employmentStatus)) {
              streams.push({
                id: 'income-2',
                employmentStatus: (s3.client2.employmentStatus as FactFindEmploymentStatus) || 'Employed',
                employerBusiness: s3.client2.employer || '',
                annualIncome: s3.client2.annualIncomeApprox || ''
              });
            }
            setIncomeStreams(streams.length > 0 ? streams : [DEFAULT_1_INCOME_STREAM_ROW]);
          }

          if (s3.expenditureItems && Array.isArray(s3.expenditureItems) && s3.expenditureItems.length > 0) {
            setExpenditureItems(s3.expenditureItems);
          } else if (s3.monthlyExpenses || s3.client1?.monthlyExpenses) {
            setExpenditureItems([{
              id: 'expenditure-1',
              expenditureType: 'General Expenditure',
              monthlyAmount: s3.monthlyExpenses || s3.client1?.monthlyExpenses || '',
              notes: ''
            }]);
          } else {
            setExpenditureItems([DEFAULT_1_EXPENDITURE_ROW]);
          }

          setMonthlyExpenses(s3.monthlyExpenses || s3.client1?.monthlyExpenses || '');

          // Also keep legacy fields populated for backward compatibility
          const c1Source = s3.client1 || s3;
          setC1EmploymentStatus((c1Source.employmentStatus as FactFindEmploymentStatus) || 'Employed');
          setC1Employer(c1Source.employer || '');
          setC1AnnualIncome(c1Source.annualIncomeApprox || '');
          setC1MonthlyExpenses(c1Source.monthlyExpenses || s3.monthlyExpenses || '');
          setC1OtherIncome(c1Source.otherIncome || { answered: '', details: '' });

          if (s3.client2) {
            setC2EmploymentStatus((s3.client2.employmentStatus as FactFindEmploymentStatus) || 'Employed');
            setC2Employer(s3.client2.employer || '');
            setC2AnnualIncome(s3.client2.annualIncomeApprox || '');
            setC2MonthlyExpenses(s3.client2.monthlyExpenses || '');
            setC2OtherIncome(s3.client2.otherIncome || { answered: '', details: '' });
          }
        } else {
          setIncomeStreams([DEFAULT_1_INCOME_STREAM_ROW]);
          setMonthlyExpenses('');
          setC1EmploymentStatus('Employed');
          setC1Employer('');
          setC1AnnualIncome('');
          setC1MonthlyExpenses('');
          setC1OtherIncome({ answered: '', details: '' });

          setC2EmploymentStatus('Employed');
          setC2Employer('');
          setC2AnnualIncome('');
          setC2MonthlyExpenses('');
          setC2OtherIncome({ answered: '', details: '' });
        }

        // Stage 4 sync
        if (existingFF.stage4?.assets && existingFF.stage4.assets.length > 0) {
          setAssets(existingFF.stage4.assets);
        } else {
          setAssets([DEFAULT_1_ASSET_ROW]);
        }

        if (existingFF.stage4?.liabilityItems && existingFF.stage4.liabilityItems.length > 0) {
          setLiabilityItems(existingFF.stage4.liabilityItems);
        } else if (existingFF.stage4?.liabilities?.answered === 'yes' && existingFF.stage4.liabilities.details) {
          setLiabilityItems([{
            id: 'liability-row-1',
            liabilityType: 'Mortgage',
            amountOutstanding: '',
            monthlyRepayment: '',
            notes: existingFF.stage4.liabilities.details || ''
          }]);
        } else {
          setLiabilityItems([DEFAULT_1_LIABILITY_ROW]);
        }

        if (existingFF.stage4?.liabilities) {
          setLiabilities(existingFF.stage4.liabilities);
        } else {
          setLiabilities({ answered: '', details: '' });
        }

        // Stage 5 sync
        const parsePersonalStage5 = (src?: FactFindStage5Personal | FactFindStage5Type): Stage5CapacityState => {
          if (!src) return { ...DEFAULT_STAGE5_CAPACITY };
          return {
            availableLumpSum: src.availableLumpSum ? { answered: src.availableLumpSum.answered || '', details: src.availableLumpSum.details || '' } : { answered: '', details: '' },
            availableMonthlyInvestment: src.availableMonthlyInvestment ? { answered: src.availableMonthlyInvestment.answered || '', details: src.availableMonthlyInvestment.details || '' } : { answered: '', details: '' },
            isaAllowanceUsed: src.isaAllowanceUsed ? { answered: src.isaAllowanceUsed.answered || '', details: src.isaAllowanceUsed.details || '' } : { answered: '', details: '' },
            cgtAllowanceUsed: src.cgtAllowanceUsed ? { answered: src.cgtAllowanceUsed.answered || '', details: src.cgtAllowanceUsed.details || '' } : { answered: '', details: '' },
            giftAllowanceUsed: src.giftAllowanceUsed ? { answered: src.giftAllowanceUsed.answered || '', details: src.giftAllowanceUsed.details || '' } : { answered: '', details: '' },
            gifts: src.gifts && src.gifts.length > 0 ? src.gifts : [DEFAULT_1_GIFT_ROW]
          };
        };

        if (existingFF.stage5) {
          const c1Parsed = parsePersonalStage5(existingFF.stage5.client1 || existingFF.stage5);
          const c2Parsed = parsePersonalStage5(existingFF.stage5.client2);
          setC1Stage5(c1Parsed);
          setC2Stage5(c2Parsed);
          setStage5Data(c1Parsed);
        } else {
          setC1Stage5(DEFAULT_STAGE5_CAPACITY);
          setC2Stage5(DEFAULT_STAGE5_CAPACITY);
          setStage5Data(DEFAULT_STAGE5_CAPACITY);
        }

        // Stage 6 sync
        if (existingFF.stage6) {
          const goalsArray: FactFindPrimaryGoal[] = Array.isArray(existingFF.stage6.primaryGoals)
            ? existingFF.stage6.primaryGoals
            : existingFF.stage6.primaryGoal
            ? (existingFF.stage6.primaryGoal.split(',').map(s => s.trim()) as FactFindPrimaryGoal[]).filter(Boolean)
            : [];

          setStage6Data({
            primaryGoals: goalsArray,
            primaryGoal: existingFF.stage6.primaryGoal || goalsArray.join(', '),
            timeHorizon: existingFF.stage6.timeHorizon || '',
            objective1: existingFF.stage6.objective1 || '',
            objective2: existingFF.stage6.objective2 || '',
            objective3: existingFF.stage6.objective3 || '',
            hasObjective3: Boolean(existingFF.stage6.hasObjective3 || existingFF.stage6.objective3),
            attitudeToRisk: existingFF.stage6.attitudeToRisk || '',
            ethicalEsgPreferences: existingFF.stage6.ethicalEsgPreferences || { answered: '', details: '' }
          });
        } else {
          setStage6Data(DEFAULT_STAGE6_OBJECTIVES_RISK);
        }

        // Stage 7 sync
        if (existingFF.stage7) {
          setStage7Data({
            additionalNotes: existingFF.stage7.additionalNotes || ''
          });
        } else {
          setStage7Data(DEFAULT_STAGE7_ADDITIONAL_NOTES);
        }
      } else {
        // First time opening Fact Find
        setCurrentStage(1);
        if (client.clientName && client.clientName.includes('&')) {
          const parts = client.clientName.split('&').map(s => s.trim());
          setC1FullName(parts[0] || '');
          setC2FullName(parts[1] || '');
          setHasSecondClient(true);
          setMaritalStatus('Married');
        } else {
          setC1FullName(client.clientName || '');
          setC2FullName('');
          setHasSecondClient(false);
          setMaritalStatus('');
        }

        setC1Dob('');
        setC1Email(client.email || '');
        setC1Phone(client.phone || '');
        setC1Address('');
        setC2Dob('');
        setC2Email('');
        setC2Phone('');
        setC2Address('');

        setMeetingDate(todayStr);
        setAdviser(client.adviserName || 'Sam Adams');

        setC1Stage2(DEFAULT_STAGE2_PERSONAL);
        setC2Stage2(DEFAULT_STAGE2_PERSONAL);

        setC1EmploymentStatus('Employed');
        setC1Employer('');
        setC1AnnualIncome('');
        setC1MonthlyExpenses('');
        setC1OtherIncome({ answered: '', details: '' });

        setC2EmploymentStatus('Employed');
        setC2Employer('');
        setC2AnnualIncome('');
        setC2MonthlyExpenses('');
        setC2OtherIncome({ answered: '', details: '' });

        setIncomeStreams([DEFAULT_1_INCOME_STREAM_ROW]);
        setExpenditureItems([DEFAULT_1_EXPENDITURE_ROW]);
        setMonthlyExpenses('');

        setAssets([DEFAULT_1_ASSET_ROW]);
        setLiabilityItems([DEFAULT_1_LIABILITY_ROW]);
        setLiabilities({ answered: '', details: '' });
        setStage5Data(DEFAULT_STAGE5_CAPACITY);
        setC1Stage5(DEFAULT_STAGE5_CAPACITY);
        setC2Stage5(DEFAULT_STAGE5_CAPACITY);
        setStage6Data(DEFAULT_STAGE6_OBJECTIVES_RISK);
        setStage7Data(DEFAULT_STAGE7_ADDITIONAL_NOTES);
      }

      setValidationError(null);
      setFieldErrors({});
      setSaveSuccessMsg(null);
    }
  }, [client, isOpen]);

  if (!isOpen || !client) return null;

  const buildStage1Payload = (): FactFindStage1 => {
    const payload: FactFindStage1 = {
      hasSecondClient,
      client1: {
        fullName: c1FullName.trim(),
        dateOfBirth: c1Dob.trim(),
        email: c1Email.trim(),
        phone: c1Phone.trim(),
        address: c1Address.trim()
      },
      meetingDate: meetingDate.trim() || getTodayDDMMYYYY(),
      adviser: adviser.trim() || 'Sam Adams'
    };

    if (hasSecondClient) {
      payload.client2 = {
        fullName: c2FullName.trim(),
        dateOfBirth: c2Dob.trim(),
        email: c2Email.trim(),
        phone: c2Phone.trim(),
        address: c2Address.trim()
      };
    }

    return payload;
  };

  const buildStage2Payload = (): FactFindStage2 => {
    const sanitize = (q?: FactFindYesNoQuestion): FactFindYesNoQuestion => ({
      answered: q?.answered || '',
      details: (q?.details || '').trim()
    });

    const sanitizeOptional = (q?: FactFindYesNoQuestion): FactFindYesNoQuestion => ({
      answered: q?.answered || '',
      details: q?.answered === 'yes' ? (q?.details || '').trim() : ''
    });

    const buildPersonal = (p: FactFindStage2Personal): FactFindStage2Personal => ({
      vulnerability: sanitize(p.vulnerability),
      pepSanctions: sanitizeOptional(p.pepSanctions),
      dependants: sanitizeOptional(p.dependants),
      willInPlace: sanitizeOptional(p.willInPlace),
      powerOfAttorney: sanitizeOptional(p.powerOfAttorney),
      expectedLifeChanges: sanitizeOptional(p.expectedLifeChanges)
    });

    const c1Built = buildPersonal(c1Stage2);

    const payload: FactFindStage2 = {
      ...c1Built,
      client1: c1Built
    };

    if (maritalStatus) {
      payload.maritalStatus = maritalStatus;
    }

    if (hasSecondClient) {
      payload.client2 = buildPersonal(c2Stage2);
    }

    return payload;
  };

  const buildStage3Payload = (): FactFindStage3Type => {
    const streams = incomeStreams && incomeStreams.length > 0 ? incomeStreams : [DEFAULT_1_INCOME_STREAM_ROW];
    const expenditures = expenditureItems && expenditureItems.length > 0 ? expenditureItems : [DEFAULT_1_EXPENDITURE_ROW];
    const primaryStream = streams[0];

    const payload: FactFindStage3Type = {
      incomeStreams: streams.map((s, idx) => ({
        id: s.id || `income-${Date.now()}-${idx}`,
        employmentStatus: (s.employmentStatus || 'Employed').trim(),
        employerBusiness: (s.employerBusiness || '').trim(),
        annualIncome: (s.annualIncome || '').trim(),
        owner: s.owner || (hasSecondClient ? 'Client 1' : undefined)
      })),
      expenditureItems: expenditures.map((e, idx) => ({
        id: e.id || `expenditure-${Date.now()}-${idx}`,
        expenditureType: e.expenditureType || 'General Expenditure',
        monthlyAmount: (e.monthlyAmount || '').trim(),
        notes: (e.notes || '').trim()
      })),
      monthlyExpenses: monthlyExpenses.trim(),
      // Legacy backwards-compatibility bindings
      employmentStatus: primaryStream?.employmentStatus || 'Employed',
      employer: (primaryStream?.employerBusiness || '').trim(),
      annualIncomeApprox: (primaryStream?.annualIncome || '').trim(),
      client1: {
        employmentStatus: primaryStream?.employmentStatus || 'Employed',
        employer: (primaryStream?.employerBusiness || '').trim(),
        annualIncomeApprox: (primaryStream?.annualIncome || '').trim(),
        monthlyExpenses: monthlyExpenses.trim()
      }
    };

    return payload;
  };

  const buildStage4Payload = (): FactFindStage4Type => {
    const totalAssetsValue = assets.reduce((sum, item) => {
      if (!item.approxValue) return sum;
      const cleanNum = item.approxValue.replace(/[^0-9.]/g, '');
      const val = parseFloat(cleanNum);
      return isNaN(val) ? sum : sum + val;
    }, 0);

    const validLiabilityItems = liabilities.answered === 'yes'
      ? (liabilityItems && liabilityItems.length > 0 ? liabilityItems : [DEFAULT_1_LIABILITY_ROW])
      : [];

    const totalLiabilitiesValue = validLiabilityItems.reduce((sum, item) => {
      if (!item.amountOutstanding) return sum;
      const cleanNum = item.amountOutstanding.replace(/[^0-9.]/g, '');
      const val = parseFloat(cleanNum);
      return isNaN(val) ? sum : sum + val;
    }, 0);

    return {
      assets: assets.map(a => ({
        id: a.id || `asset-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        assetType: a.assetType || 'Residential Property',
        otherAssetType: (a.otherAssetType || '').trim(),
        providerPlatform: (a.providerPlatform || '').trim(),
        approxValue: (a.approxValue || '').trim(),
        notes: (a.notes || '').trim(),
        owner: (a.owner || 'Client 1').trim()
      })),
      totalApproxValue: totalAssetsValue > 0 ? `£${Math.round(totalAssetsValue).toLocaleString('en-GB')}` : '',
      liabilities: {
        answered: liabilities.answered,
        details: liabilities.answered === 'yes'
          ? (liabilities.details || validLiabilityItems.map(l => `${l.liabilityType}: ${l.amountOutstanding || '£0'} (${l.monthlyRepayment ? l.monthlyRepayment + '/mo' : ''}) ${l.notes ? '- ' + l.notes : ''}`).join('; ')).trim()
          : ''
      },
      liabilityItems: validLiabilityItems.map(l => ({
        id: l.id || `liability-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        liabilityType: l.liabilityType || 'Mortgage',
        amountOutstanding: (l.amountOutstanding || '').trim(),
        monthlyRepayment: (l.monthlyRepayment || '').trim(),
        notes: (l.notes || '').trim(),
        owner: (l.owner || 'Client 1').trim()
      })),
      totalLiabilitiesValue: totalLiabilitiesValue > 0 ? `£${Math.round(totalLiabilitiesValue).toLocaleString('en-GB')}` : ''
    };
  };

  const buildStage5Payload = (): FactFindStage5Type => {
    const buildPersonal = (st: Stage5CapacityState): FactFindStage5Personal => {
      const giftsList = st.gifts && st.gifts.length > 0
        ? st.gifts
        : [DEFAULT_1_GIFT_ROW];

      const totalGiftAmount = giftsList.reduce((sum, g) => {
        if (!g.amountGifted) return sum;
        const num = parseFloat(g.amountGifted.replace(/[^0-9.]/g, ''));
        return isNaN(num) ? sum : sum + num;
      }, 0);

      const isGiftYes = st.giftAllowanceUsed?.answered === 'yes';

      return {
        availableLumpSum: {
          answered: st.availableLumpSum?.answered || '',
          details: st.availableLumpSum?.answered === 'yes' ? (st.availableLumpSum.details || '').trim() : ''
        },
        availableMonthlyInvestment: {
          answered: st.availableMonthlyInvestment?.answered || '',
          details: st.availableMonthlyInvestment?.answered === 'yes' ? (st.availableMonthlyInvestment.details || '').trim() : ''
        },
        isaAllowanceUsed: {
          answered: st.isaAllowanceUsed?.answered || '',
          details: st.isaAllowanceUsed?.answered === 'yes' ? (st.isaAllowanceUsed.details || '').trim() : ''
        },
        cgtAllowanceUsed: {
          answered: st.cgtAllowanceUsed?.answered || '',
          details: st.cgtAllowanceUsed?.answered === 'yes' ? (st.cgtAllowanceUsed.details || '').trim() : ''
        },
        giftAllowanceUsed: {
          answered: st.giftAllowanceUsed?.answered || '',
          details: isGiftYes 
            ? (totalGiftAmount > 0 ? `£${Math.round(totalGiftAmount).toLocaleString('en-GB')}` : (st.giftAllowanceUsed?.details || '').trim()) 
            : ''
        },
        gifts: isGiftYes ? giftsList.map((g, idx) => ({
          id: g.id || `gift-${Date.now()}-${idx}`,
          recipient: (g.recipient || '').trim(),
          dateGifted: (g.dateGifted || '').trim(),
          amountGifted: (g.amountGifted || '').trim()
        })) : []
      };
    };

    const c1Personal = buildPersonal(c1Stage5);
    const c2Personal = hasSecondClient ? buildPersonal(c2Stage5) : undefined;

    return {
      ...c1Personal,
      client1: c1Personal,
      client2: c2Personal
    };
  };

  const buildStage6Payload = (): FactFindStage6Type => {
    const goalsArray: FactFindPrimaryGoal[] = stage6Data.primaryGoals && stage6Data.primaryGoals.length > 0
      ? stage6Data.primaryGoals
      : stage6Data.primaryGoal
      ? (stage6Data.primaryGoal.split(',').map(s => s.trim()) as FactFindPrimaryGoal[]).filter(Boolean)
      : [];

    return {
      primaryGoals: goalsArray,
      primaryGoal: stage6Data.primaryGoal || goalsArray.join(', '),
      timeHorizon: stage6Data.timeHorizon || '',
      objective1: (stage6Data.objective1 || '').trim(),
      objective2: (stage6Data.objective2 || '').trim(),
      objective3: stage6Data.hasObjective3 ? (stage6Data.objective3 || '').trim() : '',
      hasObjective3: stage6Data.hasObjective3,
      attitudeToRisk: stage6Data.attitudeToRisk || '',
      ethicalEsgPreferences: {
        answered: stage6Data.ethicalEsgPreferences?.answered || '',
        details: stage6Data.ethicalEsgPreferences?.answered === 'yes' 
          ? (stage6Data.ethicalEsgPreferences.details || '').trim() 
          : ''
      }
    };
  };

  const buildStage7Payload = (): FactFindStage7Type => {
    return {
      additionalNotes: (stage7Data.additionalNotes || '').trim()
    };
  };

  // Validate Stage 2 fields
  const validateStage2 = (): boolean => {
    const errors: Record<string, boolean> = {};
    const missingDetails: string[] = [];

    const validatePersonal = (
      prefix: 'c1' | 'c2',
      labelPrefix: string,
      pState: FactFindStage2Personal
    ) => {
      YES_NO_QUESTIONS.forEach(item => {
        const state = pState[item.key] || { answered: '', details: '' };
        const errKey = `${prefix}-${item.key}`;

        if (item.key === 'vulnerability') {
          if (!state.answered) {
            errors[errKey] = true;
            missingDetails.push(`${labelPrefix} Vulnerability: Please select Yes or No`);
          } else if (!state.details || !state.details.trim()) {
            errors[errKey] = true;
            missingDetails.push(`${labelPrefix} Vulnerability Assessment Notes (Mandatory for ${state.answered === 'yes' ? 'Yes' : 'No'})`);
          }
        } else {
          if (state.answered === 'yes' && (!state.details || !state.details.trim())) {
            errors[errKey] = true;
            missingDetails.push(`${labelPrefix} ${item.label.replace(/^\d+\.\s*/, '')}`);
          }
        }
      });
    };

    const c1DisplayName = c1FullName.trim() || 'Client 1';
    validatePersonal('c1', hasSecondClient ? `${c1DisplayName}:` : 'Client:', c1Stage2);

    if (hasSecondClient) {
      const c2DisplayName = c2FullName.trim() || 'Client 2';
      validatePersonal('c2', `${c2DisplayName}:`, c2Stage2);
    }

    setFieldErrors(errors);

    if (missingDetails.length > 0) {
      setValidationError(`Mandatory details required for: ${missingDetails.join(', ')}.`);
      return false;
    }

    setValidationError(null);
    return true;
  };

  // Validate Stage 3 fields (Each income stream: annual income required; Monthly Expenditure items: monthly amount required)
  const validateStage3 = (): boolean => {
    const errors: Record<string, boolean> = {};
    const missingFields: string[] = [];

    const streams = incomeStreams && incomeStreams.length > 0 ? incomeStreams : [DEFAULT_1_INCOME_STREAM_ROW];
    const expenditures = expenditureItems && expenditureItems.length > 0 ? expenditureItems : [DEFAULT_1_EXPENDITURE_ROW];

    streams.forEach((stream, idx) => {
      if (!stream.annualIncome || !stream.annualIncome.trim()) {
        errors[`income-val-${idx}`] = true;
        missingFields.push(`Income Stream #${idx + 1} Annual Income`);
      }
    });

    expenditures.forEach((item, idx) => {
      if (!item.monthlyAmount || !item.monthlyAmount.trim()) {
        errors[`expenditure-val-${idx}`] = true;
        missingFields.push(`Expenditure #${idx + 1} Monthly Amount`);
      }
    });

    if (!monthlyExpenses || !monthlyExpenses.trim()) {
      errors['monthlyExpenses'] = true;
    }

    setFieldErrors(errors);

    if (missingFields.length > 0) {
      setValidationError(`Please complete all mandatory fields: ${missingFields.join(', ')}.`);
      return false;
    }

    setValidationError(null);
    return true;
  };

  // Validate Stage 4 fields (Asset Type 'Other' requires custom type specification; Liabilities Yes requires amount outstanding)
  const validateStage4 = (): boolean => {
    const errors: Record<string, boolean> = {};
    let hasMissingOther = false;
    let hasMissingLiabilityAmount = false;

    assets.forEach((item, idx) => {
      if (item.assetType === 'Other' && (!item.otherAssetType || !item.otherAssetType.trim())) {
        errors[`asset-other-${idx}`] = true;
        hasMissingOther = true;
      }
    });

    if (liabilities.answered === 'yes') {
      const itemsToCheck = liabilityItems && liabilityItems.length > 0 ? liabilityItems : [DEFAULT_1_LIABILITY_ROW];
      itemsToCheck.forEach((item, idx) => {
        if (!item.amountOutstanding || !item.amountOutstanding.trim()) {
          errors[`liability-amount-${idx}`] = true;
          hasMissingLiabilityAmount = true;
        }
      });
      if (hasMissingLiabilityAmount) {
        errors['liabilities'] = true;
      }
    }

    setFieldErrors(errors);

    if (hasMissingOther) {
      setValidationError('Please specify the asset type for any row where "Other" was selected.');
      return false;
    }

    if (hasMissingLiabilityAmount || errors['liabilities']) {
      setValidationError('Mandatory Amount Outstanding required for each listed liability row because "Yes" was selected.');
      return false;
    }

    setValidationError(null);
    return true;
  };

  // Validate Stage 5 fields (Mandatory Pound Sterling value required if "Yes" is chosen)
  const validateStage5 = (): boolean => {
    const errors: Record<string, boolean> = {};
    const missingLabels: string[] = [];

    const validatePersonalCapacity = (
      st: Stage5CapacityState,
      prefix: 'c1' | 'c2',
      displayName: string
    ) => {
      const checkField = (key: keyof Omit<Stage5CapacityState, 'gifts'>, label: string) => {
        const item = st[key];
        if (item?.answered === 'yes' && (!item.details || !item.details.trim())) {
          errors[`${prefix}-${key}`] = true;
          errors[key] = true;
          missingLabels.push(hasSecondClient ? `${displayName} - ${label}` : label);
        }
      };

      checkField('availableLumpSum', 'Available Lump Sum to Invest');
      checkField('availableMonthlyInvestment', 'Available Monthly Investment Capacity');
      checkField('isaAllowanceUsed', 'ISA Allowance Used');
      checkField('cgtAllowanceUsed', 'CGT Allowance Used');

      // Validate Gifts Schedule Table if Gift Allowance Used is Yes
      if (st.giftAllowanceUsed?.answered === 'yes') {
        const gifts = st.gifts && st.gifts.length > 0 ? st.gifts : [DEFAULT_1_GIFT_ROW];
        let hasGiftError = false;

        gifts.forEach((gift, idx) => {
          if (!gift.recipient || !gift.recipient.trim()) {
            errors[`${prefix}-gift-recipient-${idx}`] = true;
            errors[`gift-recipient-${idx}`] = true;
            hasGiftError = true;
          }
          if (!gift.amountGifted || !gift.amountGifted.trim()) {
            errors[`${prefix}-gift-amount-${idx}`] = true;
            errors[`gift-amount-${idx}`] = true;
            hasGiftError = true;
          }
        });

        if (hasGiftError) {
          errors[`${prefix}-giftAllowanceUsed`] = true;
          errors['giftAllowanceUsed'] = true;
          missingLabels.push(hasSecondClient ? `${displayName} - Gift Allowance Schedule` : 'Gift Allowance Schedule (Recipient & Amount required)');
        }
      }
    };

    validatePersonalCapacity(c1Stage5, 'c1', c1FullName || 'Client 1');
    if (hasSecondClient) {
      validatePersonalCapacity(c2Stage5, 'c2', c2FullName || 'Client 2');
    }

    setFieldErrors(errors);

    if (missingLabels.length > 0) {
      setValidationError(`Please complete all required fields: ${missingLabels.join(', ')}.`);
      return false;
    }

    setValidationError(null);
    return true;
  };

  // Validate Stage 6 fields (Objectives / Risk & Investment Preferences)
  const validateStage6 = (): boolean => {
    const errors: Record<string, boolean> = {};
    const missingLabels: string[] = [];

    const hasPrimaryGoal = (stage6Data.primaryGoals && stage6Data.primaryGoals.length > 0) || Boolean(stage6Data.primaryGoal && stage6Data.primaryGoal.trim());
    if (!hasPrimaryGoal) {
      errors['primaryGoal'] = true;
      missingLabels.push('Primary Goal (select at least 1)');
    }

    if (!stage6Data.timeHorizon) {
      errors['timeHorizon'] = true;
      missingLabels.push('Time Horizon');
    }

    if (!stage6Data.objective1 || !stage6Data.objective1.trim()) {
      errors['objective1'] = true;
      missingLabels.push('Objective 1');
    }

    if (!stage6Data.objective2 || !stage6Data.objective2.trim()) {
      errors['objective2'] = true;
      missingLabels.push('Objective 2');
    }

    if (!stage6Data.attitudeToRisk) {
      errors['attitudeToRisk'] = true;
      missingLabels.push('Attitude to Risk Level');
    }

    if (stage6Data.ethicalEsgPreferences?.answered === 'yes' && (!stage6Data.ethicalEsgPreferences.details || !stage6Data.ethicalEsgPreferences.details.trim())) {
      errors['ethicalEsgPreferences'] = true;
      missingLabels.push('Ethical / ESG Preferences Details');
    }

    setFieldErrors(errors);

    if (missingLabels.length > 0) {
      setValidationError(`Please complete required fields: ${missingLabels.join(', ')}.`);
      return false;
    }

    setValidationError(null);
    return true;
  };

  const handleSaveDraft = async () => {
    if (!c1FullName.trim()) {
      setValidationError('Please provide at least the primary client’s Full Name before saving.');
      return;
    }
    setValidationError(null);
    setIsSaving(true);

    const stage1Data = buildStage1Payload();
    const stage2Data = buildStage2Payload();
    const stage3Data = buildStage3Payload();
    const stage4Data = buildStage4Payload();
    const stage5DataPayload = buildStage5Payload();
    const stage6DataPayload = buildStage6Payload();
    const stage7DataPayload = buildStage7Payload();

    const updatedFactFind: ClientFactFind = {
      status: 'in_progress',
      currentStage,
      stage1: stage1Data,
      stage2: stage2Data,
      stage3: stage3Data,
      stage4: stage4Data,
      stage5: stage5DataPayload,
      stage6: stage6DataPayload,
      stage7: stage7DataPayload,
      updatedAt: new Date().toISOString()
    };

    try {
      await updateClientFactFind(client.id, removeUndefinedDeep(updatedFactFind), true);
      setSaveSuccessMsg('Fact Find draft saved successfully!');
      setTimeout(() => setSaveSuccessMsg(null), 3000);
      if (onClientUpdated) onClientUpdated();
    } catch (err) {
      console.error('Failed to save Fact Find draft:', err);
      setValidationError('An error occurred while saving. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const navigateToStageWithAutoSave = async (targetStage: number) => {
    if (client && c1FullName.trim()) {
      const stage1Data = buildStage1Payload();
      const stage2Data = buildStage2Payload();
      const stage3Data = buildStage3Payload();
      const stage4Data = buildStage4Payload();
      const stage5DataPayload = buildStage5Payload();
      const stage6DataPayload = buildStage6Payload();
      const stage7DataPayload = buildStage7Payload();

      const updatedFactFind: ClientFactFind = {
        status: client.factFind?.status || 'in_progress',
        currentStage: targetStage,
        stage1: stage1Data,
        stage2: stage2Data,
        stage3: stage3Data,
        stage4: stage4Data,
        stage5: stage5DataPayload,
        stage6: stage6DataPayload,
        stage7: stage7DataPayload,
        updatedAt: new Date().toISOString()
      };

      try {
        await updateClientFactFind(client.id, removeUndefinedDeep(updatedFactFind), true);
        if (onClientUpdated) onClientUpdated();
      } catch (e) {
        console.warn('Silent auto-save on stage navigation:', e);
      }
    }
    setCurrentStage(targetStage);
    setValidationError(null);
    setFieldErrors({});
  };

  const handleCloseModal = async () => {
    if (client && c1FullName.trim()) {
      try {
        const stage1Data = buildStage1Payload();
        const stage2Data = buildStage2Payload();
        const stage3Data = buildStage3Payload();
        const stage4Data = buildStage4Payload();
        const stage5DataPayload = buildStage5Payload();
        const stage6DataPayload = buildStage6Payload();
        const stage7DataPayload = buildStage7Payload();

        const updatedFactFind: ClientFactFind = {
          status: client.factFind?.status || 'in_progress',
          currentStage,
          stage1: stage1Data,
          stage2: stage2Data,
          stage3: stage3Data,
          stage4: stage4Data,
          stage5: stage5DataPayload,
          stage6: stage6DataPayload,
          stage7: stage7DataPayload,
          updatedAt: new Date().toISOString()
        };

        await updateClientFactFind(client.id, removeUndefinedDeep(updatedFactFind), true);
        if (onClientUpdated) onClientUpdated();
      } catch (e) {
        console.warn('Auto-save on modal close:', e);
      }
    }
    onClose();
  };

  const handleNextToStage2 = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!c1FullName.trim()) {
      setValidationError('Primary Client Full Name is required to proceed.');
      return;
    }

    if (hasSecondClient && !c2FullName.trim()) {
      setValidationError('Second Client / Partner Full Name is required when joint application is enabled.');
      return;
    }

    setValidationError(null);
    setIsSaving(true);

    const stage1Data = buildStage1Payload();
    const stage2Data = buildStage2Payload();
    const stage3Data = buildStage3Payload();
    const stage4Data = buildStage4Payload();
    const stage5DataPayload = buildStage5Payload();
    const stage6DataPayload = buildStage6Payload();
    const stage7DataPayload = buildStage7Payload();

    const updatedFactFind: ClientFactFind = {
      status: 'in_progress',
      currentStage: 2,
      stage1: stage1Data,
      stage2: stage2Data,
      stage3: stage3Data,
      stage4: stage4Data,
      stage5: stage5DataPayload,
      stage6: stage6DataPayload,
      stage7: stage7DataPayload,
      updatedAt: new Date().toISOString()
    };

    try {
      await updateClientFactFind(client.id, removeUndefinedDeep(updatedFactFind), true);
      setCurrentStage(2);
      setSaveSuccessMsg('Stage 1 Client Details saved! Now completing Stage 2: Personal Situation.');
      setTimeout(() => setSaveSuccessMsg(null), 3000);
      if (onClientUpdated) onClientUpdated();
    } catch (err) {
      console.error('Failed to advance Fact Find to Stage 2:', err);
      setValidationError('Could not advance to Stage 2. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleNextToStage3 = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateStage2()) {
      return;
    }

    setIsSaving(true);
    const stage1Data = buildStage1Payload();
    const stage2Data = buildStage2Payload();
    const stage3Data = buildStage3Payload();
    const stage4Data = buildStage4Payload();
    const stage5DataPayload = buildStage5Payload();
    const stage6DataPayload = buildStage6Payload();
    const stage7DataPayload = buildStage7Payload();

    const updatedFactFind: ClientFactFind = {
      status: 'in_progress',
      currentStage: 3,
      stage1: stage1Data,
      stage2: stage2Data,
      stage3: stage3Data,
      stage4: stage4Data,
      stage5: stage5DataPayload,
      stage6: stage6DataPayload,
      stage7: stage7DataPayload,
      updatedAt: new Date().toISOString()
    };

    try {
      await updateClientFactFind(client.id, removeUndefinedDeep(updatedFactFind), true);
      setCurrentStage(3);
      setSaveSuccessMsg('Stage 2: Personal Situation saved! Now completing Stage 3: Employment & Income/Expenditure.');
      setTimeout(() => setSaveSuccessMsg(null), 3000);
      if (onClientUpdated) onClientUpdated();
    } catch (err) {
      console.error('Failed to advance to Stage 3:', err);
      setValidationError('Could not advance to Stage 3. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleNextToStage4 = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateStage3()) {
      return;
    }

    setIsSaving(true);
    const stage1Data = buildStage1Payload();
    const stage2Data = buildStage2Payload();
    const stage3Data = buildStage3Payload();
    const stage4Data = buildStage4Payload();
    const stage5DataPayload = buildStage5Payload();
    const stage6DataPayload = buildStage6Payload();
    const stage7DataPayload = buildStage7Payload();

    const updatedFactFind: ClientFactFind = {
      status: 'in_progress',
      currentStage: 4,
      stage1: stage1Data,
      stage2: stage2Data,
      stage3: stage3Data,
      stage4: stage4Data,
      stage5: stage5DataPayload,
      stage6: stage6DataPayload,
      stage7: stage7DataPayload,
      updatedAt: new Date().toISOString()
    };

    try {
      await updateClientFactFind(client.id, removeUndefinedDeep(updatedFactFind), true);
      setCurrentStage(4);
      setSaveSuccessMsg('Stage 3: Employment & Income saved! Now completing Stage 4: Assets & Liabilities.');
      setTimeout(() => setSaveSuccessMsg(null), 3000);
      if (onClientUpdated) onClientUpdated();
    } catch (err) {
      console.error('Failed to advance to Stage 4:', err);
      setValidationError('Could not advance to Stage 4. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleNextToStage5 = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateStage4()) {
      return;
    }

    setIsSaving(true);
    const stage1Data = buildStage1Payload();
    const stage2Data = buildStage2Payload();
    const stage3Data = buildStage3Payload();
    const stage4Data = buildStage4Payload();
    const stage5DataPayload = buildStage5Payload();
    const stage6DataPayload = buildStage6Payload();
    const stage7DataPayload = buildStage7Payload();

    const updatedFactFind: ClientFactFind = {
      status: 'in_progress',
      currentStage: 5,
      stage1: stage1Data,
      stage2: stage2Data,
      stage3: stage3Data,
      stage4: stage4Data,
      stage5: stage5DataPayload,
      stage6: stage6DataPayload,
      stage7: stage7DataPayload,
      updatedAt: new Date().toISOString()
    };

    try {
      await updateClientFactFind(client.id, removeUndefinedDeep(updatedFactFind), true);
      setCurrentStage(5);
      setSaveSuccessMsg('Stage 4: Assets & Liabilities saved! Now completing Stage 5: Capacity.');
      setTimeout(() => setSaveSuccessMsg(null), 3000);
      if (onClientUpdated) onClientUpdated();
    } catch (err) {
      console.error('Failed to advance to Stage 5:', err);
      setValidationError('Could not advance to Stage 5. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleNextToStage6 = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateStage5()) {
      return;
    }

    setIsSaving(true);
    const stage1Data = buildStage1Payload();
    const stage2Data = buildStage2Payload();
    const stage3Data = buildStage3Payload();
    const stage4Data = buildStage4Payload();
    const stage5DataPayload = buildStage5Payload();
    const stage6DataPayload = buildStage6Payload();
    const stage7DataPayload = buildStage7Payload();

    const updatedFactFind: ClientFactFind = {
      status: 'in_progress',
      currentStage: 6,
      stage1: stage1Data,
      stage2: stage2Data,
      stage3: stage3Data,
      stage4: stage4Data,
      stage5: stage5DataPayload,
      stage6: stage6DataPayload,
      stage7: stage7DataPayload,
      updatedAt: new Date().toISOString()
    };

    try {
      await updateClientFactFind(client.id, removeUndefinedDeep(updatedFactFind), true);
      setCurrentStage(6);
      setSaveSuccessMsg('Stage 5: Capacity saved! Now completing Stage 6: Objectives / Risk & Investment Preferences.');
      setTimeout(() => setSaveSuccessMsg(null), 3000);
      if (onClientUpdated) onClientUpdated();
    } catch (err) {
      console.error('Failed to advance to Stage 6:', err);
      setValidationError('Could not advance to Stage 6. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleNextToStage7 = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateStage6()) {
      return;
    }

    setIsSaving(true);
    const stage1Data = buildStage1Payload();
    const stage2Data = buildStage2Payload();
    const stage3Data = buildStage3Payload();
    const stage4Data = buildStage4Payload();
    const stage5DataPayload = buildStage5Payload();
    const stage6DataPayload = buildStage6Payload();
    const stage7DataPayload = buildStage7Payload();

    const updatedFactFind: ClientFactFind = {
      status: 'in_progress',
      currentStage: 7,
      stage1: stage1Data,
      stage2: stage2Data,
      stage3: stage3Data,
      stage4: stage4Data,
      stage5: stage5DataPayload,
      stage6: stage6DataPayload,
      stage7: stage7DataPayload,
      updatedAt: new Date().toISOString()
    };

    try {
      await updateClientFactFind(client.id, removeUndefinedDeep(updatedFactFind), true);
      setCurrentStage(7);
      setSaveSuccessMsg('Stage 6: Objectives & Risk saved! Now completing Stage 7: Additional Notes.');
      setTimeout(() => setSaveSuccessMsg(null), 3000);
      if (onClientUpdated) onClientUpdated();
    } catch (err) {
      console.error('Failed to advance to Stage 7:', err);
      setValidationError('Could not advance to Stage 7. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleNextToStage8 = async (e: React.FormEvent) => {
    e.preventDefault();

    setIsSaving(true);
    const stage1Data = buildStage1Payload();
    const stage2Data = buildStage2Payload();
    const stage3Data = buildStage3Payload();
    const stage4Data = buildStage4Payload();
    const stage5DataPayload = buildStage5Payload();
    const stage6DataPayload = buildStage6Payload();
    const stage7DataPayload = buildStage7Payload();

    const updatedFactFind: ClientFactFind = {
      status: 'in_progress',
      currentStage: 8,
      stage1: stage1Data,
      stage2: stage2Data,
      stage3: stage3Data,
      stage4: stage4Data,
      stage5: stage5DataPayload,
      stage6: stage6DataPayload,
      stage7: stage7DataPayload,
      updatedAt: new Date().toISOString()
    };

    try {
      await updateClientFactFind(client.id, removeUndefinedDeep(updatedFactFind), true);
      setCurrentStage(8);
      setSaveSuccessMsg('Stage 7: Notes saved! Now review all information in Stage 8 before submitting.');
      setTimeout(() => setSaveSuccessMsg(null), 3000);
      if (onClientUpdated) onClientUpdated();
    } catch (err) {
      console.error('Failed to advance to Stage 8:', err);
      setValidationError('Could not advance to Stage 8. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleCompleteFactFind = async (e: React.FormEvent) => {
    e.preventDefault();

    setIsSaving(true);
    const stage1Data = buildStage1Payload();
    const stage2Data = buildStage2Payload();
    const stage3Data = buildStage3Payload();
    const stage4Data = buildStage4Payload();
    const stage5DataPayload = buildStage5Payload();
    const stage6DataPayload = buildStage6Payload();
    const stage7DataPayload = buildStage7Payload();

    const updatedFactFind: ClientFactFind = {
      status: 'completed',
      currentStage: 8,
      stage1: stage1Data,
      stage2: stage2Data,
      stage3: stage3Data,
      stage4: stage4Data,
      stage5: stage5DataPayload,
      stage6: stage6DataPayload,
      stage7: stage7DataPayload,
      updatedAt: new Date().toISOString(),
      completedAt: client.factFind?.completedAt || new Date().toISOString()
    };

    try {
      await updateClientFactFind(client.id, removeUndefinedDeep(updatedFactFind), true);
      setIsCompletedState(true);
      setSaveSuccessMsg('Fact find completed & saved to client file!');
      setTimeout(() => {
        setSaveSuccessMsg(null);
      }, 3000);
      if (onClientUpdated) onClientUpdated();
    } catch (err) {
      console.error('Failed to complete Fact Find:', err);
      setValidationError('Could not complete Fact Find. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleMoveToOngoing = async () => {
    if (!client) return;

    setIsSaving(true);
    const stage1Data = buildStage1Payload();
    const stage2Data = buildStage2Payload();
    const stage3Data = buildStage3Payload();
    const stage4Data = buildStage4Payload();
    const stage5DataPayload = buildStage5Payload();
    const stage6DataPayload = buildStage6Payload();
    const stage7DataPayload = buildStage7Payload();

    const updatedFactFind: ClientFactFind = {
      status: 'completed',
      currentStage: 8,
      stage1: stage1Data,
      stage2: stage2Data,
      stage3: stage3Data,
      stage4: stage4Data,
      stage5: stage5DataPayload,
      stage6: stage6DataPayload,
      stage7: stage7DataPayload,
      updatedAt: new Date().toISOString(),
      completedAt: client.factFind?.completedAt || new Date().toISOString()
    };

    try {
      await updateClientFactFind(client.id, removeUndefinedDeep(updatedFactFind), true);
      await moveClientCategory(client.id, 'ongoing');
      setIsCompletedState(true);
      setSaveSuccessMsg(`${c1FullName || client.clientName} has been moved into Ongoing! Admin checklist triggered.`);
      setTimeout(() => {
        setSaveSuccessMsg(null);
        onClose();
      }, 1200);
      if (onClientUpdated) onClientUpdated();
    } catch (err) {
      console.error('Failed to move client to ongoing:', err);
      setValidationError('Could not move client to ongoing. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleBackToStage1 = () => {
    setCurrentStage(1);
    setValidationError(null);
    setFieldErrors({});
  };

  const handleBackToStage2 = () => {
    setCurrentStage(2);
    setValidationError(null);
    setFieldErrors({});
  };

  const handleBackToStage3 = () => {
    setCurrentStage(3);
    setValidationError(null);
    setFieldErrors({});
  };

  const handleBackToStage4 = () => {
    setCurrentStage(4);
    setValidationError(null);
    setFieldErrors({});
  };

  const handleBackToStage5 = () => {
    setCurrentStage(5);
    setValidationError(null);
    setFieldErrors({});
  };

  const handleBackToStage6 = () => {
    setCurrentStage(6);
    setValidationError(null);
    setFieldErrors({});
  };

  const handleBackToStage7 = () => {
    setCurrentStage(7);
    setValidationError(null);
    setFieldErrors({});
  };

  const handleNavigateToStage = (stageNum: number) => {
    setCurrentStage(stageNum);
    setValidationError(null);
    setFieldErrors({});
  };

  const copyAddressToClient2 = () => {
    if (c1Address) {
      setC2Address(c1Address);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl relative overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Modal Header */}
        <div className="border-b border-slate-200 p-5 sm:p-6 bg-slate-50 shrink-0">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-blue-100 text-blue-700 rounded-xl border border-blue-200 shadow-2xs">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className={`px-2 py-0.5 rounded-full text-[11px] font-semibold uppercase tracking-wider ${
                    client.category === 'ongoing'
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                      : client.category === 'onboarded'
                      ? 'bg-indigo-100 text-indigo-800 border border-indigo-200'
                      : client.category === 'completed'
                      ? 'bg-teal-100 text-teal-800 border border-teal-200'
                      : client.category === 'on_hold'
                      ? 'bg-slate-100 text-slate-700 border border-slate-200'
                      : 'bg-amber-50 text-amber-700 border border-amber-200'
                  }`}>
                    {client.category === 'ongoing'
                      ? 'Ongoing Client'
                      : client.category === 'onboarded'
                      ? 'Onboarded Client'
                      : client.category === 'completed'
                      ? 'Completed File'
                      : client.category === 'on_hold'
                      ? 'On Hold'
                      : 'Potential Client'}
                  </span>

                  {(isCompletedState || client.factFind?.status === 'completed') && (
                    <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      <span>Fact Find Completed</span>
                    </span>
                  )}

                  <span className="text-xs text-slate-500 font-medium hidden sm:inline">
                    Adams &amp; Poole Financial Services
                  </span>
                </div>
                <h2 className="text-xl font-bold text-slate-900 mt-0.5">
                  Client Fact Find — {c1FullName || client.clientName}
                </h2>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {(isCompletedState || client.factFind?.status === 'completed') && (client.category === 'potential' || !client.category) && (
                <button
                  type="button"
                  onClick={handleMoveToOngoing}
                  disabled={isSaving}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition cursor-pointer disabled:opacity-50"
                  title="Move client into Ongoing category and trigger admin checklist"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Move into Ongoing</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              )}

              <button
                onClick={handleCloseModal}
                className="p-1.5 text-slate-400 hover:text-slate-600 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg transition cursor-pointer"
                title="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Stepper Bar - 8 Stages */}
          <div className="mt-5 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-1.5 sm:gap-2 pt-3 border-t border-slate-200">
            {/* Stage 1 Step Pill */}
            <button
              type="button"
              onClick={() => {
                navigateToStageWithAutoSave(1);
              }}
              className={`flex items-center gap-2 p-2 sm:p-2.5 rounded-xl border text-left transition cursor-pointer ${
                currentStage === 1
                  ? 'bg-white border-blue-500 shadow-sm ring-2 ring-blue-500/20'
                  : currentStage > 1
                  ? 'bg-emerald-50/70 border-emerald-300 text-emerald-900 hover:bg-emerald-100/60'
                  : 'bg-slate-100/70 border-slate-200 text-slate-600'
              }`}
            >
              <div className={`w-6 h-6 sm:w-7 sm:h-7 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                currentStage === 1
                  ? 'bg-blue-600 text-white'
                  : 'bg-emerald-600 text-white'
              }`}>
                {currentStage > 1 ? <CheckCircle2 className="w-4 h-4" /> : '1'}
              </div>
              <div className="min-w-0 hidden xs:block sm:block">
                <p className="text-xs font-bold text-slate-900 truncate">
                  Stage 1: Details
                </p>
                <p className="text-[10px] text-slate-500 truncate">
                  Personal profile
                </p>
              </div>
            </button>

            {/* Stage 2 Step Pill */}
            <button
              type="button"
              onClick={() => {
                if (c1FullName.trim()) {
                  navigateToStageWithAutoSave(2);
                }
              }}
              className={`flex items-center gap-2 p-2 sm:p-2.5 rounded-xl border text-left transition cursor-pointer ${
                currentStage === 2
                  ? 'bg-white border-blue-500 shadow-sm ring-2 ring-blue-500/20'
                  : currentStage > 2
                  ? 'bg-emerald-50/70 border-emerald-300 text-emerald-900 hover:bg-emerald-100/60'
                  : 'bg-slate-100/70 border-slate-200 text-slate-600 hover:bg-white'
              }`}
            >
              <div className={`w-6 h-6 sm:w-7 sm:h-7 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                currentStage === 2
                  ? 'bg-blue-600 text-white'
                  : currentStage > 2
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-200 text-slate-600'
              }`}>
                {currentStage > 2 ? <CheckCircle2 className="w-4 h-4" /> : '2'}
              </div>
              <div className="min-w-0 hidden xs:block sm:block">
                <p className={`text-xs font-bold truncate ${currentStage === 2 ? 'text-slate-900' : 'text-slate-700'}`}>
                  Stage 2: Situation
                </p>
                <p className="text-[10px] text-slate-500 truncate">
                  Circumstances
                </p>
              </div>
            </button>

            {/* Stage 3 Step Pill */}
            <button
              type="button"
              onClick={() => {
                if (c1FullName.trim() && validateStage2()) {
                  navigateToStageWithAutoSave(3);
                }
              }}
              className={`flex items-center gap-2 p-2 sm:p-2.5 rounded-xl border text-left transition cursor-pointer ${
                currentStage === 3
                  ? 'bg-white border-blue-500 shadow-sm ring-2 ring-blue-500/20'
                  : currentStage > 3
                  ? 'bg-emerald-50/70 border-emerald-300 text-emerald-900 hover:bg-emerald-100/60'
                  : 'bg-slate-100/70 border-slate-200 text-slate-600 hover:bg-white'
              }`}
            >
              <div className={`w-6 h-6 sm:w-7 sm:h-7 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                currentStage === 3
                  ? 'bg-blue-600 text-white'
                  : currentStage > 3
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-200 text-slate-600'
              }`}>
                {currentStage > 3 ? <CheckCircle2 className="w-4 h-4" /> : '3'}
              </div>
              <div className="min-w-0 hidden xs:block sm:block">
                <p className={`text-xs font-bold truncate ${currentStage === 3 ? 'text-slate-900' : 'text-slate-700'}`}>
                  Stage 3: Income
                </p>
                <p className="text-[10px] text-slate-500 truncate">
                  Employment &amp; costs
                </p>
              </div>
            </button>

            {/* Stage 4 Step Pill */}
            <button
              type="button"
              onClick={() => {
                if (c1FullName.trim() && validateStage2() && validateStage3()) {
                  navigateToStageWithAutoSave(4);
                }
              }}
              className={`flex items-center gap-2 p-2 sm:p-2.5 rounded-xl border text-left transition cursor-pointer ${
                currentStage === 4
                  ? 'bg-white border-blue-500 shadow-sm ring-2 ring-blue-500/20'
                  : currentStage > 4
                  ? 'bg-emerald-50/70 border-emerald-300 text-emerald-900 hover:bg-emerald-100/60'
                  : 'bg-slate-100/70 border-slate-200 text-slate-600 hover:bg-white'
              }`}
            >
              <div className={`w-6 h-6 sm:w-7 sm:h-7 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                currentStage === 4
                  ? 'bg-blue-600 text-white'
                  : currentStage > 4
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-200 text-slate-600'
              }`}>
                {currentStage > 4 ? <CheckCircle2 className="w-4 h-4" /> : '4'}
              </div>
              <div className="min-w-0 hidden xs:block sm:block">
                <p className={`text-xs font-bold truncate ${currentStage === 4 ? 'text-slate-900' : 'text-slate-700'}`}>
                  Stage 4: Assets
                </p>
                <p className="text-[10px] text-slate-500 truncate">
                  Wealth &amp; debts
                </p>
              </div>
            </button>

            {/* Stage 5 Step Pill */}
            <button
              type="button"
              onClick={() => {
                if (c1FullName.trim() && validateStage2() && validateStage3() && validateStage4()) {
                  navigateToStageWithAutoSave(5);
                }
              }}
              className={`flex items-center gap-2 p-2 sm:p-2.5 rounded-xl border text-left transition cursor-pointer ${
                currentStage === 5
                  ? 'bg-white border-blue-500 shadow-sm ring-2 ring-blue-500/20'
                  : currentStage > 5
                  ? 'bg-emerald-50/70 border-emerald-300 text-emerald-900 hover:bg-emerald-100/60'
                  : 'bg-slate-100/70 border-slate-200 text-slate-600 hover:bg-white'
              }`}
            >
              <div className={`w-6 h-6 sm:w-7 sm:h-7 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                currentStage === 5
                  ? 'bg-blue-600 text-white'
                  : currentStage > 5
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-200 text-slate-600'
              }`}>
                {currentStage > 5 ? <CheckCircle2 className="w-4 h-4" /> : '5'}
              </div>
              <div className="min-w-0 hidden xs:block sm:block">
                <p className={`text-xs font-bold truncate ${currentStage === 5 ? 'text-slate-900' : 'text-slate-700'}`}>
                  Stage 5: Capacity
                </p>
                <p className="text-[10px] text-slate-500 truncate">
                  Investment capacity
                </p>
              </div>
            </button>

            {/* Stage 6 Step Pill */}
            <button
              type="button"
              onClick={() => {
                if (c1FullName.trim() && validateStage2() && validateStage3() && validateStage4() && validateStage5()) {
                  navigateToStageWithAutoSave(6);
                }
              }}
              className={`flex items-center gap-2 p-2 sm:p-2.5 rounded-xl border text-left transition cursor-pointer ${
                currentStage === 6
                  ? 'bg-white border-blue-500 shadow-sm ring-2 ring-blue-500/20'
                  : currentStage > 6
                  ? 'bg-emerald-50/70 border-emerald-300 text-emerald-900 hover:bg-emerald-100/60'
                  : 'bg-slate-100/70 border-slate-200 text-slate-600 hover:bg-white'
              }`}
            >
              <div className={`w-6 h-6 sm:w-7 sm:h-7 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                currentStage === 6
                  ? 'bg-blue-600 text-white'
                  : currentStage > 6
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-200 text-slate-600'
              }`}>
                {currentStage > 6 ? <CheckCircle2 className="w-4 h-4" /> : '6'}
              </div>
              <div className="min-w-0 hidden xs:block sm:block">
                <p className={`text-xs font-bold truncate ${currentStage === 6 ? 'text-slate-900' : 'text-slate-700'}`}>
                  Stage 6: Goals
                </p>
                <p className="text-[10px] text-slate-500 truncate">
                  Risk &amp; Preferences
                </p>
              </div>
            </button>

            {/* Stage 7 Step Pill */}
            <button
              type="button"
              onClick={() => {
                if (c1FullName.trim() && validateStage2() && validateStage3() && validateStage4() && validateStage5() && validateStage6()) {
                  navigateToStageWithAutoSave(7);
                }
              }}
              className={`flex items-center gap-2 p-2 sm:p-2.5 rounded-xl border text-left transition cursor-pointer ${
                currentStage === 7
                  ? 'bg-white border-blue-500 shadow-sm ring-2 ring-blue-500/20'
                  : currentStage > 7
                  ? 'bg-emerald-50/70 border-emerald-300 text-emerald-900 hover:bg-emerald-100/60'
                  : 'bg-slate-100/70 border-slate-200 text-slate-600 hover:bg-white'
              }`}
            >
              <div className={`w-6 h-6 sm:w-7 sm:h-7 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                currentStage === 7
                  ? 'bg-blue-600 text-white'
                  : currentStage > 7
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-200 text-slate-600'
              }`}>
                {currentStage > 7 ? <CheckCircle2 className="w-4 h-4" /> : '7'}
              </div>
              <div className="min-w-0 hidden xs:block sm:block">
                <p className={`text-xs font-bold truncate ${currentStage === 7 ? 'text-slate-900' : 'text-slate-700'}`}>
                  Stage 7: Notes
                </p>
                <p className="text-[10px] text-slate-500 truncate">
                  Additional notes
                </p>
              </div>
            </button>

            {/* Stage 8 Step Pill */}
            <button
              type="button"
              onClick={() => {
                if (c1FullName.trim() && validateStage2() && validateStage3() && validateStage4() && validateStage5() && validateStage6()) {
                  navigateToStageWithAutoSave(8);
                }
              }}
              className={`flex items-center gap-2 p-2 sm:p-2.5 rounded-xl border text-left transition cursor-pointer ${
                currentStage === 8
                  ? 'bg-white border-blue-500 shadow-sm ring-2 ring-blue-500/20'
                  : client.factFind?.status === 'completed'
                  ? 'bg-emerald-50/70 border-emerald-300 text-emerald-900 hover:bg-emerald-100/60'
                  : 'bg-slate-100/70 border-slate-200 text-slate-600 hover:bg-white'
              }`}
            >
              <div className={`w-6 h-6 sm:w-7 sm:h-7 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                currentStage === 8
                  ? 'bg-blue-600 text-white'
                  : client.factFind?.status === 'completed'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-200 text-slate-600'
              }`}>
                {client.factFind?.status === 'completed' ? <CheckCircle2 className="w-4 h-4" /> : '8'}
              </div>
              <div className="min-w-0 hidden xs:block sm:block">
                <p className={`text-xs font-bold truncate ${currentStage === 8 ? 'text-slate-900' : 'text-slate-700'}`}>
                  Stage 8: Review
                </p>
                <p className="text-[10px] text-slate-500 truncate">
                  Review &amp; submit
                </p>
              </div>
            </button>
          </div>
        </div>

        {/* Notifications & Validation Alerts */}
        {validationError && (
          <div className="mx-6 mt-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2 animate-in fade-in">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <span className="leading-snug font-medium">{validationError}</span>
          </div>
        )}

        {saveSuccessMsg && (
          <div className="mx-6 mt-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="font-medium">{saveSuccessMsg}</span>
          </div>
        )}

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 text-slate-700">
          {currentStage === 1 ? (
            /* ============================================================ */
            /* STAGE 1: CLIENT DETAILS (1 BY 1 VERTICAL VIEW)              */
            /* ============================================================ */
            <form id="fact-find-stage1-form" onSubmit={handleNextToStage2} className="space-y-6">
              
              {/* Meeting Meta & Lead Adviser Card */}
              <div className="bg-slate-50/90 border border-slate-200/90 rounded-xl p-4 sm:p-5">
                <div className="flex items-center gap-2 mb-3">
                  <Briefcase className="w-4 h-4 text-blue-600" />
                  <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Meeting &amp; Advisory Context
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Meeting Date (Defaulted to Today's date) */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Meeting Date <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <Calendar className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                      <input
                        type="date"
                        value={convertDDMMYYYYToYYYYMMDD(meetingDate)}
                        onChange={(e) => setMeetingDate(convertYYYYMMDDToDDMMYYYY(e.target.value))}
                        className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono"
                        required
                      />
                    </div>
                    <p className="text-[10px] text-slate-500 mt-1">
                      Defaulted to today ({meetingDate || getTodayDDMMYYYY()})
                    </p>
                  </div>

                  {/* Assigned Adviser */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Adviser <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                      <select
                        value={adviser}
                        onChange={(e) => setAdviser(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        required
                      >
                        <option value="Sam Adams">Sam Adams (Chartered Financial Planner)</option>
                        <option value="Anthony Poole">Anthony Poole (Chartered Financial Planner)</option>
                        <option value="Associate Adviser">Associate Paraplanner / Adviser</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {/* Couple / Partner Toggle Facility */}
              <div className="flex items-center justify-between p-3.5 bg-blue-50/70 border border-blue-200/80 rounded-xl">
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 bg-blue-100 text-blue-700 rounded-lg">
                    <Users className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">
                      Married Couple / Partner Details (2 Clients)
                    </span>
                    <span className="text-[11px] text-slate-600 block">
                      Enable facility to capture joint information for both clients
                    </span>
                  </div>
                </div>
                
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={hasSecondClient}
                    onChange={(e) => {
                      setHasSecondClient(e.target.checked);
                      if (e.target.checked && !maritalStatus) {
                        setMaritalStatus('Married');
                      }
                    }}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>

              {/* Client 1 Details Card: 1 by 1 Vertical Form View */}
              <div className="border border-slate-200 rounded-xl p-5 sm:p-6 bg-white shadow-2xs">
                <div className="flex items-center justify-between gap-2 mb-5 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2.5">
                    <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-800 text-xs font-bold flex items-center justify-center">
                      1
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-900">
                        {hasSecondClient ? 'Client 1 (Primary Client)' : 'Client Details'}
                      </h3>
                      <p className="text-[11px] text-slate-500">
                        5 core personal &amp; contact fields
                      </p>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-slate-100 text-slate-600 border border-slate-200">
                    1 by 1 View
                  </span>
                </div>

                {/* Vertical Stack: 1 by 1 Fields */}
                <div className="space-y-4 max-w-2xl">
                  {/* Field 1: Full Name */}
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1.5">
                      1. Full Name <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                      <input
                        type="text"
                        value={c1FullName}
                        onChange={(e) => setC1FullName(e.target.value)}
                        placeholder="e.g. Edward Thornton"
                        className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-900 bg-white"
                        required
                      />
                    </div>
                  </div>

                  {/* Field 2: Date of Birth */}
                  <DateOfBirthInput
                    id="client1-dob"
                    value={c1Dob}
                    onChange={setC1Dob}
                    label="2. Date of Birth"
                    themeColor="blue"
                    helperText="Format: DD/MM/YYYY (e.g. 15/05/1979)"
                  />

                  {/* Field 3: Email Address */}
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1.5">
                      3. Email Address
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                      <input
                        type="email"
                        value={c1Email}
                        onChange={(e) => setC1Email(e.target.value)}
                        placeholder="e.g. client@example.com"
                        className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-900 bg-white"
                      />
                    </div>
                  </div>

                  {/* Field 4: Phone Number */}
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1.5">
                      4. Phone Number
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                      <input
                        type="tel"
                        value={c1Phone}
                        onChange={(e) => setC1Phone(e.target.value)}
                        placeholder="e.g. 07700 900142"
                        className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono text-slate-900 bg-white"
                      />
                    </div>
                  </div>

                  {/* Field 5: Address */}
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1.5">
                      5. Address
                    </label>
                    <div className="relative">
                      <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                      <input
                        type="text"
                        value={c1Address}
                        onChange={(e) => setC1Address(e.target.value)}
                        placeholder="e.g. 14 Highwood Close, Guildford, Surrey, GU1 2AZ"
                        className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-900 bg-white"
                      />
                    </div>
                    <p className="text-[10px] text-slate-500 mt-1">
                      Residential or principal correspondence address
                    </p>
                  </div>
                </div>
              </div>

              {/* Client 2 Details Card (When toggle is ON): 1 by 1 Vertical Form View */}
              {hasSecondClient && (
                <div className="border border-indigo-200 rounded-xl p-5 sm:p-6 bg-indigo-50/30 shadow-2xs animate-in fade-in slide-in-from-top-2">
                  <div className="flex items-center justify-between gap-2 mb-5 pb-3 border-b border-indigo-100">
                    <div className="flex items-center gap-2.5">
                      <div className="w-6 h-6 rounded-full bg-indigo-100 text-indigo-800 text-xs font-bold flex items-center justify-center">
                        2
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-indigo-950">
                          Client 2 (Partner / Spouse / Co-applicant)
                        </h3>
                        <p className="text-[11px] text-indigo-700/70">
                          5 partner personal &amp; contact fields
                        </p>
                      </div>
                    </div>

                    {c1Address && (
                      <button
                        type="button"
                        onClick={copyAddressToClient2}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-indigo-700 bg-indigo-100 hover:bg-indigo-200 rounded-lg transition cursor-pointer"
                        title="Copy address from Client 1"
                      >
                        <Copy className="w-3 h-3" />
                        <span>Same address as Client 1</span>
                      </button>
                    )}
                  </div>

                  {/* Vertical Stack: 1 by 1 Fields */}
                  <div className="space-y-4 max-w-2xl">
                    {/* Field 1: Full Name */}
                    <div>
                      <label className="block text-xs font-bold text-indigo-950 mb-1.5">
                        1. Full Name <span className="text-rose-500">*</span>
                      </label>
                      <div className="relative">
                        <User className="w-4 h-4 text-indigo-400 absolute left-3 top-2.5" />
                        <input
                          type="text"
                          value={c2FullName}
                          onChange={(e) => setC2FullName(e.target.value)}
                          placeholder="e.g. Caroline Thornton"
                          className="w-full pl-9 pr-3 py-2 text-xs border border-indigo-200 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-slate-900"
                          required={hasSecondClient}
                        />
                      </div>
                    </div>

                    {/* Field 2: Date of Birth */}
                    <DateOfBirthInput
                      id="client2-dob"
                      value={c2Dob}
                      onChange={setC2Dob}
                      label="2. Date of Birth"
                      themeColor="indigo"
                      helperText="Format: DD/MM/YYYY (e.g. 15/05/1979)"
                    />

                    {/* Field 3: Email Address */}
                    <div>
                      <label className="block text-xs font-bold text-indigo-950 mb-1.5">
                        3. Email Address
                      </label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-indigo-400 absolute left-3 top-2.5" />
                        <input
                          type="email"
                          value={c2Email}
                          onChange={(e) => setC2Email(e.target.value)}
                          placeholder="e.g. partner@example.com"
                          className="w-full pl-9 pr-3 py-2 text-xs border border-indigo-200 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-slate-900"
                        />
                      </div>
                    </div>

                    {/* Field 4: Phone Number */}
                    <div>
                      <label className="block text-xs font-bold text-indigo-950 mb-1.5">
                        4. Phone Number
                      </label>
                      <div className="relative">
                        <Phone className="w-4 h-4 text-indigo-400 absolute left-3 top-2.5" />
                        <input
                          type="tel"
                          value={c2Phone}
                          onChange={(e) => setC2Phone(e.target.value)}
                          placeholder="e.g. 07700 900143"
                          className="w-full pl-9 pr-3 py-2 text-xs border border-indigo-200 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 font-mono text-slate-900"
                        />
                      </div>
                    </div>

                    {/* Field 5: Address */}
                    <div>
                      <label className="block text-xs font-bold text-indigo-950 mb-1.5">
                        5. Address
                      </label>
                      <div className="relative">
                        <MapPin className="w-4 h-4 text-indigo-400 absolute left-3 top-2.5" />
                        <input
                          type="text"
                          value={c2Address}
                          onChange={(e) => setC2Address(e.target.value)}
                          placeholder="e.g. 14 Highwood Close, Guildford, Surrey, GU1 2AZ"
                          className="w-full pl-9 pr-3 py-2 text-xs border border-indigo-200 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-slate-900"
                        />
                      </div>
                      <p className="text-[10px] text-slate-500 mt-1">
                        Residential or principal correspondence address
                      </p>
                    </div>
                  </div>
                </div>
              )}

            </form>
          ) : currentStage === 2 ? (
            /* ============================================================ */
            /* STAGE 2: PERSONAL CIRCUMSTANCES & DUAL-CLIENT ASSESSMENT     */
            /* ============================================================ */
            <FactFindStage2Component
              maritalStatus={maritalStatus}
              onChangeMaritalStatus={setMaritalStatus}
              hasSecondClient={hasSecondClient}
              c1FullName={c1FullName || client.clientName || 'Primary Client'}
              c2FullName={hasSecondClient ? (c2FullName || 'Client 2') : undefined}
              c1State={c1Stage2}
              onChangeC1State={setC1Stage2}
              c2State={c2Stage2}
              onChangeC2State={setC2Stage2}
              fieldErrors={fieldErrors}
              onClearFieldError={(key) => setFieldErrors(prev => ({ ...prev, [key]: false }))}
              onBackToStage1={handleBackToStage1}
              onSubmit={handleNextToStage3}
            />
          ) : currentStage === 3 ? (
            /* ============================================================ */
            /* STAGE 3: EMPLOYMENT & INCOME/EXPENDITURE                     */
            /* ============================================================ */
            <FactFindStage3
              incomeStreams={incomeStreams}
              onChangeIncomeStreams={setIncomeStreams}
              setIncomeStreams={setIncomeStreams}
              expenditureItems={expenditureItems}
              onChangeExpenditureItems={setExpenditureItems}
              setExpenditureItems={setExpenditureItems}
              monthlyExpenses={monthlyExpenses}
              onChangeMonthlyExpenses={setMonthlyExpenses}
              setMonthlyExpenses={setMonthlyExpenses}
              c1FullName={c1FullName || client.clientName || 'Primary Client'}
              c2FullName={hasSecondClient ? c2FullName : undefined}
              hasSecondClient={hasSecondClient}
              adviser={adviser}
              fieldErrors={fieldErrors}
              onClearFieldError={(key) => setFieldErrors(prev => ({ ...prev, [key]: false }))}
              onBackToStage2={handleBackToStage2}
              onSubmit={handleNextToStage4}
            />
          ) : currentStage === 4 ? (
            /* ============================================================ */
            /* STAGE 4: ASSETS & LIABILITIES                                */
            /* ============================================================ */
            <FactFindStage4
              assets={assets}
              onChangeAssets={setAssets}
              setAssets={setAssets}
              liabilityItems={liabilityItems}
              onChangeLiabilityItems={setLiabilityItems}
              setLiabilityItems={setLiabilityItems}
              liabilities={liabilities}
              onChangeLiabilities={setLiabilities}
              setLiabilities={setLiabilities}
              c1FullName={c1FullName || client.clientName || 'Primary Client'}
              c2FullName={hasSecondClient ? c2FullName : undefined}
              hasSecondClient={hasSecondClient}
              adviser={adviser}
              fieldErrors={fieldErrors}
              onClearFieldError={(key) => setFieldErrors(prev => ({ ...prev, [key]: false }))}
              onBackToStage3={handleBackToStage3}
              onSubmit={handleNextToStage5}
            />
          ) : currentStage === 5 ? (
            /* ============================================================ */
            /* STAGE 5: CAPACITY                                            */
            /* ============================================================ */
            <FactFindStage5
              c1State={c1Stage5}
              onChangeC1State={setC1Stage5}
              c2State={c2Stage5}
              onChangeC2State={setC2Stage5}
              data={c1Stage5}
              onChangeData={setC1Stage5}
              setData={setC1Stage5}
              c1FullName={c1FullName || client.clientName || 'Primary Client'}
              c2FullName={hasSecondClient ? c2FullName : undefined}
              hasSecondClient={hasSecondClient}
              adviser={adviser}
              fieldErrors={fieldErrors}
              onClearFieldError={(key) => setFieldErrors(prev => ({ ...prev, [key]: false }))}
              onBackToStage4={handleBackToStage4}
              onSubmit={handleNextToStage6}
            />
          ) : currentStage === 6 ? (
            /* ============================================================ */
            /* STAGE 6: OBJECTIVES / RISK & INVESTMENT PREFERENCES          */
            /* ============================================================ */
            <FactFindStage6
              data={stage6Data}
              onChangeData={setStage6Data}
              setData={setStage6Data}
              c1FullName={c1FullName || client.clientName || 'Primary Client'}
              c2FullName={hasSecondClient ? c2FullName : undefined}
              hasSecondClient={hasSecondClient}
              adviser={adviser}
              fieldErrors={fieldErrors}
              onClearFieldError={(key) => setFieldErrors(prev => ({ ...prev, [key]: false }))}
              onBackToStage5={handleBackToStage5}
              onSubmit={handleNextToStage7}
            />
          ) : currentStage === 7 ? (
            /* ============================================================ */
            /* STAGE 7: ADDITIONAL NOTES                                    */
            /* ============================================================ */
            <FactFindStage7
              data={stage7Data}
              onChangeData={setStage7Data}
              setData={setStage7Data}
              c1FullName={c1FullName || client.clientName || 'Primary Client'}
              c2FullName={hasSecondClient ? c2FullName : undefined}
              hasSecondClient={hasSecondClient}
              adviser={adviser}
              fieldErrors={fieldErrors}
              onClearFieldError={(key) => setFieldErrors(prev => ({ ...prev, [key]: false }))}
              onBackToStage6={handleBackToStage6}
              onSubmit={handleNextToStage8}
            />
          ) : (
            /* ============================================================ */
            /* STAGE 8: REVIEW & SUBMIT                                     */
            /* ============================================================ */
            <FactFindStage8
              c1FullName={c1FullName || client.clientName || 'Primary Client'}
              c1Dob={c1Dob}
              c1Email={c1Email}
              c1Phone={c1Phone}
              c1Address={c1Address}

              hasSecondClient={hasSecondClient}
              c2FullName={c2FullName}
              c2Dob={c2Dob}
              c2Email={c2Email}
              c2Phone={c2Phone}
              c2Address={c2Address}

              meetingDate={meetingDate}
              adviser={adviser}

              maritalStatus={maritalStatus}
              c1Stage2={c1Stage2}
              c2Stage2={c2Stage2}
              vulnerability={c1Stage2.vulnerability}
              pepSanctions={c1Stage2.pepSanctions}
              dependants={c1Stage2.dependants}
              willInPlace={c1Stage2.willInPlace}
              powerOfAttorney={c1Stage2.powerOfAttorney}
              expectedLifeChanges={c1Stage2.expectedLifeChanges}

              incomeStreams={incomeStreams}
              expenditureItems={expenditureItems}
              monthlyExpenses={monthlyExpenses}

              c1EmploymentStatus={c1EmploymentStatus}
              c1Employer={c1Employer}
              c1AnnualIncome={c1AnnualIncome}
              c1MonthlyExpenses={c1MonthlyExpenses}
              c1OtherIncome={c1OtherIncome}

              c2EmploymentStatus={c2EmploymentStatus}
              c2Employer={c2Employer}
              c2AnnualIncome={c2AnnualIncome}
              c2MonthlyExpenses={c2MonthlyExpenses}
              c2OtherIncome={c2OtherIncome}

              assets={assets}
              liabilities={liabilities}
              liabilityItems={liabilityItems}

              stage5Data={c1Stage5}
              c1Stage5={c1Stage5}
              c2Stage5={c2Stage5}
              stage6Data={stage6Data}
              stage7Data={stage7Data}

              isCompleted={isCompletedState || client.factFind?.status === 'completed'}
              clientCategory={client.category}
              onMoveToOngoing={handleMoveToOngoing}
              onNavigateToStage={handleNavigateToStage}
              onBackToStage7={handleBackToStage7}
              onSubmit={handleCompleteFactFind}
              isSaving={isSaving}
            />
          )}
        </div>

        {/* Modal Footer Controls */}
        <div className="border-t border-slate-200 p-4 sm:p-5 bg-slate-50 flex items-center justify-between gap-3 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl transition cursor-pointer"
          >
            Close
          </button>

          <div className="flex items-center gap-2 flex-wrap justify-end">
            {currentStage === 1 ? (
              <>
                <button
                  type="button"
                  onClick={handleSaveDraft}
                  disabled={isSaving}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl transition cursor-pointer disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5 text-slate-500" />
                  <span>Save Draft</span>
                </button>

                <button
                  type="submit"
                  form="fact-find-stage1-form"
                  disabled={isSaving}
                  className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition cursor-pointer disabled:opacity-50"
                >
                  <span>Next: Stage 2</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </>
            ) : currentStage === 2 ? (
              <>
                <button
                  type="button"
                  onClick={handleBackToStage1}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl transition cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Stage 1</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveDraft}
                  disabled={isSaving}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl transition cursor-pointer disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5 text-slate-500" />
                  <span>Save Draft</span>
                </button>

                <button
                  type="submit"
                  form="fact-find-stage2-form"
                  disabled={isSaving}
                  className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition cursor-pointer disabled:opacity-50"
                >
                  <span>Next: Stage 3</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </>
            ) : currentStage === 3 ? (
              <>
                <button
                  type="button"
                  onClick={handleBackToStage2}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl transition cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Stage 2</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveDraft}
                  disabled={isSaving}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl transition cursor-pointer disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5 text-slate-500" />
                  <span>Save Draft</span>
                </button>

                <button
                  type="submit"
                  form="fact-find-stage3-form"
                  disabled={isSaving}
                  className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition cursor-pointer disabled:opacity-50"
                >
                  <span>Next: Stage 4 (Assets &amp; Liabilities)</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </>
            ) : currentStage === 4 ? (
              <>
                <button
                  type="button"
                  onClick={handleBackToStage3}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl transition cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Stage 3</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveDraft}
                  disabled={isSaving}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl transition cursor-pointer disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5 text-slate-500" />
                  <span>Save Draft</span>
                </button>

                <button
                  type="submit"
                  form="fact-find-stage4-form"
                  disabled={isSaving}
                  className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition cursor-pointer disabled:opacity-50"
                >
                  <span>Next: Stage 5 (Capacity)</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </>
            ) : currentStage === 5 ? (
              <>
                <button
                  type="button"
                  onClick={handleBackToStage4}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl transition cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Stage 4</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveDraft}
                  disabled={isSaving}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl transition cursor-pointer disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5 text-slate-500" />
                  <span>Save Draft</span>
                </button>

                <button
                  type="submit"
                  form="fact-find-stage5-form"
                  disabled={isSaving}
                  className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition cursor-pointer disabled:opacity-50"
                >
                  <span>Next: Stage 6 (Objectives &amp; Risk)</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </>
            ) : currentStage === 6 ? (
              <>
                <button
                  type="button"
                  onClick={handleBackToStage5}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl transition cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Stage 5</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveDraft}
                  disabled={isSaving}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl transition cursor-pointer disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5 text-slate-500" />
                  <span>Save Draft</span>
                </button>

                <button
                  type="submit"
                  form="fact-find-stage6-form"
                  disabled={isSaving}
                  className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition cursor-pointer disabled:opacity-50"
                >
                  <span>Next: Stage 7 (Additional Notes)</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </>
            ) : currentStage === 7 ? (
              <>
                <button
                  type="button"
                  onClick={handleBackToStage6}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl transition cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Stage 6</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveDraft}
                  disabled={isSaving}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl transition cursor-pointer disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5 text-slate-500" />
                  <span>Save Draft</span>
                </button>

                <button
                  type="submit"
                  form="fact-find-stage7-form"
                  disabled={isSaving}
                  className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition cursor-pointer disabled:opacity-50"
                >
                  <span>Next: Stage 8 (Review &amp; Submit)</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </>
            ) : (
              <>
                <button
                  type="button"
                  onClick={handleBackToStage7}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl transition cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Stage 7</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveDraft}
                  disabled={isSaving}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl transition cursor-pointer disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5 text-slate-500" />
                  <span>{isCompletedState || client.factFind?.status === 'completed' ? 'Save Changes' : 'Save Draft'}</span>
                </button>

                {(isCompletedState || client.factFind?.status === 'completed') && (client.category === 'potential' || !client.category) ? (
                  <button
                    type="button"
                    onClick={handleMoveToOngoing}
                    disabled={isSaving}
                    className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs transition cursor-pointer disabled:opacity-50"
                    title="Move client into Ongoing and trigger admin checklist"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Move into Ongoing</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                ) : (
                  <button
                    type="submit"
                    form="fact-find-stage8-form"
                    disabled={isSaving}
                    className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs transition cursor-pointer disabled:opacity-50"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{isCompletedState || client.factFind?.status === 'completed' ? 'Save & Close' : 'Complete & Save Fact Find'}</span>
                  </button>
                )}
              </>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};
