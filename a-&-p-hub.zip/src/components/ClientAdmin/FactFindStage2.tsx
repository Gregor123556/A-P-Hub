import React from 'react';
import { 
  HeartHandshake, 
  ShieldAlert, 
  Users, 
  Scroll, 
  FileCheck2, 
  Hourglass, 
  AlertCircle, 
  User, 
  Info,
  CheckCircle2
} from 'lucide-react';
import { 
  FactFindMaritalStatus, 
  FactFindYesNoQuestion, 
  FactFindStage2Personal 
} from '../../types';

export const DEFAULT_VULNERABILITY_NO_TEXT = "Client is of full sound body and mind, they're financially independent and fully grasped our discussion";

export const MARITAL_STATUS_OPTIONS: { value: FactFindMaritalStatus; label: string; description: string }[] = [
  { value: 'Married', label: 'Married', description: 'Legally married under UK law' },
  { value: 'Civil Partner', label: 'Civil Partner', description: 'Registered UK Civil Partnership' },
  { value: 'Single', label: 'Single', description: 'Never married or in a civil partnership' },
  { value: 'Cohabiting', label: 'Cohabiting', description: 'Living together in an unregistered relationship' },
  { value: 'Divorced', label: 'Divorced', description: 'Decree absolute granted' },
  { value: 'Separated', label: 'Separated', description: 'Informally or legally separated' },
  { value: 'Widowed', label: 'Widowed', description: 'Surviving spouse or civil partner' },
  { value: 'Other', label: 'Other', description: 'Other personal or relationship status' }
];

export interface YesNoFieldConfig {
  key: keyof FactFindStage2Personal;
  label: string;
  question: string;
  icon: React.ComponentType<{ className?: string }>;
  helper: string;
  placeholder: string;
}

export const YES_NO_QUESTIONS: YesNoFieldConfig[] = [
  {
    key: 'vulnerability',
    label: '1. Vulnerability Identified?',
    question: 'Any FCA Consumer Duty vulnerability indicators identified?',
    icon: HeartHandshake,
    helper: '',
    placeholder: 'Please provide full assessment notes...'
  },
  {
    key: 'pepSanctions',
    label: '2. PEP / Sanctions Identified?',
    question: 'Is the client a PEP or subject to sanctions?',
    icon: ShieldAlert,
    helper: '',
    placeholder: 'Please provide PEP/Sanctions details...'
  },
  {
    key: 'dependants',
    label: '3. Dependants / Family Responsibilities?',
    question: 'Does the client have financially dependent family members?',
    icon: Users,
    helper: '',
    placeholder: 'Please detail dependants (names, ages, relationship)...'
  },
  {
    key: 'willInPlace',
    label: '4. Will in Place?',
    question: 'Does the client have a valid Will in place?',
    icon: Scroll,
    helper: '',
    placeholder: 'Please provide Will details (date, executors, location)...'
  },
  {
    key: 'powerOfAttorney',
    label: '5. Power of Attorney (LPA)?',
    question: 'Is a Lasting Power of Attorney (LPA) in place?',
    icon: FileCheck2,
    helper: '',
    placeholder: 'Please provide LPA details (types, appointed attorneys)...'
  },
  {
    key: 'expectedLifeChanges',
    label: '6. Expected Life Changes in 5 Years?',
    question: 'Any major life or financial changes expected in the next 5 years?',
    icon: Hourglass,
    helper: '',
    placeholder: 'Please detail expected life events and timeline...'
  }
];

interface FactFindStage2Props {
  maritalStatus: FactFindMaritalStatus | '';
  onChangeMaritalStatus: (status: FactFindMaritalStatus | '') => void;
  hasSecondClient: boolean;
  c1FullName?: string;
  c2FullName?: string;
  c1State: FactFindStage2Personal;
  onChangeC1State: (updater: (prev: FactFindStage2Personal) => FactFindStage2Personal) => void;
  c2State: FactFindStage2Personal;
  onChangeC2State: (updater: (prev: FactFindStage2Personal) => FactFindStage2Personal) => void;
  fieldErrors: Record<string, boolean>;
  onClearFieldError: (fieldKey: string) => void;
  onSubmit: (e: React.FormEvent) => void;
}

export const FactFindStage2: React.FC<FactFindStage2Props> = ({
  maritalStatus,
  onChangeMaritalStatus,
  hasSecondClient,
  c1FullName,
  c2FullName,
  c1State,
  onChangeC1State,
  c2State,
  onChangeC2State,
  fieldErrors,
  onClearFieldError,
  onSubmit
}) => {
  const client1DisplayName = c1FullName?.trim() || 'Client 1 (Primary Client)';
  const client2DisplayName = c2FullName?.trim() || 'Client 2 (Partner / Spouse)';

  const renderQuestionCard = (
    item: YesNoFieldConfig,
    clientPrefix: 'c1' | 'c2',
    clientState: FactFindStage2Personal,
    updateClientState: (updater: (prev: FactFindStage2Personal) => FactFindStage2Personal) => void,
    themeColor: 'blue' | 'indigo'
  ) => {
    const errorKey = `${clientPrefix}-${item.key}`;
    const hasError = fieldErrors[errorKey] || fieldErrors[item.key as string];
    const rawVal = clientState[item.key] as FactFindYesNoQuestion | undefined;
    const currentVal: FactFindYesNoQuestion = rawVal || { answered: '', details: '' };
    
    const isYes = currentVal.answered === 'yes';
    const isNo = currentVal.answered === 'no';
    const isVulnerability = item.key === 'vulnerability';
    const showTextBox = isVulnerability ? (isYes || isNo) : isYes;
    const IconComponent = item.icon;
    const isIndigo = themeColor === 'indigo';

    const activeYesBg = isIndigo 
      ? 'bg-indigo-600 border-indigo-600 text-white shadow-xs' 
      : 'bg-blue-600 border-blue-600 text-white shadow-xs';
    
    const iconAccentBg = isYes
      ? (isIndigo ? 'bg-indigo-100 text-indigo-700' : 'bg-blue-100 text-blue-700')
      : isNo && isVulnerability
      ? 'bg-slate-200 text-slate-700'
      : 'bg-slate-100 text-slate-600';

    return (
      <div
        key={`${clientPrefix}-${item.key}`}
        id={`stage2-${clientPrefix}-${item.key}`}
        className={`rounded-xl border transition-all p-4 bg-white ${
          hasError
            ? 'border-rose-400 bg-rose-50/20 ring-2 ring-rose-400/20'
            : isYes
            ? (isIndigo ? 'border-indigo-200 bg-indigo-50/15' : 'border-blue-200 bg-blue-50/20')
            : isNo && isVulnerability
            ? 'border-slate-300 bg-slate-50/40'
            : 'border-slate-200 hover:border-slate-300'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
          
          {/* Question info */}
          <div className="flex items-start gap-3 flex-1">
            <div className={`p-2 rounded-lg shrink-0 mt-0.5 ${iconAccentBg}`}>
              <IconComponent className="w-4 h-4" />
            </div>

            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-xs font-bold text-slate-900">
                  {item.label}
                </span>
                {isVulnerability ? (
                  <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-amber-100 text-amber-800 border border-amber-200 uppercase tracking-wide">
                    Mandatory Notes (Yes &amp; No)
                  </span>
                ) : isYes && (
                  <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-amber-100 text-amber-800 border border-amber-200 uppercase tracking-wide">
                    Details Required
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-600 leading-snug">
                {item.question}
              </p>
            </div>
          </div>

          {/* Yes / No Choice Buttons */}
          <div className="flex items-center gap-2 shrink-0 self-start sm:self-center">
            {/* Yes Button */}
            <button
              type="button"
              id={`${clientPrefix}-${item.key}-yes-btn`}
              onClick={() => {
                let nextDetails = currentVal.details || '';
                if (isVulnerability && currentVal.details === DEFAULT_VULNERABILITY_NO_TEXT) {
                  nextDetails = '';
                }
                updateClientState(prev => ({
                  ...prev,
                  [item.key]: {
                    answered: 'yes',
                    details: nextDetails
                  }
                }));
                onClearFieldError(errorKey);
                onClearFieldError(item.key as string);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
                isYes
                  ? activeYesBg
                  : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <div className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                isYes ? 'border-white bg-white' : 'border-slate-400'
              }`}>
                {isYes && (
                  <div className={`w-1.5 h-1.5 rounded-full ${isIndigo ? 'bg-indigo-600' : 'bg-blue-600'}`} />
                )}
              </div>
              <span>Yes</span>
            </button>

            {/* No Button */}
            <button
              type="button"
              id={`${clientPrefix}-${item.key}-no-btn`}
              onClick={() => {
                let nextDetails = '';
                if (isVulnerability) {
                  nextDetails = (currentVal.details && currentVal.details.trim() && currentVal.answered === 'no')
                    ? currentVal.details
                    : DEFAULT_VULNERABILITY_NO_TEXT;
                }
                updateClientState(prev => ({
                  ...prev,
                  [item.key]: {
                    answered: 'no',
                    details: nextDetails
                  }
                }));
                onClearFieldError(errorKey);
                onClearFieldError(item.key as string);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
                isNo
                  ? 'bg-slate-700 border-slate-700 text-white shadow-xs'
                  : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <div className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                isNo ? 'border-white bg-white' : 'border-slate-400'
              }`}>
                {isNo && <div className="w-1.5 h-1.5 rounded-full bg-slate-700" />}
              </div>
              <span>No</span>
            </button>
          </div>
        </div>

        {/* Text Area Details */}
        {showTextBox && (
          <div className="mt-3 pt-3 border-t border-slate-100 animate-in fade-in slide-in-from-top-1">
            <label className="block text-xs font-bold text-slate-800 mb-1">
              {isVulnerability
                ? isYes
                  ? 'Vulnerability Assessment & Support Details'
                  : 'Vulnerability Assessment Notes & Justification'
                : 'Context & Circumstances Details'}{' '}
              <span className="text-rose-500">* (Mandatory)</span>
            </label>
            <textarea
              id={`${clientPrefix}-${item.key}-textarea`}
              rows={2}
              value={currentVal.details || ''}
              onChange={(e) => {
                const val = e.target.value;
                updateClientState(prev => ({
                  ...prev,
                  [item.key]: {
                    ...(prev[item.key] || { answered: currentVal.answered }),
                    answered: currentVal.answered,
                    details: val
                  }
                }));
                if (val.trim()) {
                  onClearFieldError(errorKey);
                  onClearFieldError(item.key as string);
                }
              }}
              placeholder={
                isVulnerability
                  ? isYes
                    ? 'Please provide details of identified vulnerability and any required adjustments/support...'
                    : 'Please confirm assessment notes (e.g. No vulnerability indicators identified; client demonstrated full understanding, mental capacity, and financial resilience)...'
                  : item.placeholder
              }
              className={`w-full p-2.5 text-xs rounded-lg border bg-white focus:ring-2 focus:outline-none transition leading-relaxed ${
                hasError
                  ? 'border-rose-400 focus:border-rose-500 focus:ring-rose-200'
                  : isIndigo
                  ? 'border-slate-300 focus:border-indigo-500 focus:ring-indigo-100'
                  : 'border-slate-300 focus:border-blue-500 focus:ring-blue-100'
              }`}
              required={showTextBox}
            />
            {hasError && (
              <p className="text-[11px] text-rose-600 font-semibold mt-1 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                {isVulnerability
                  ? 'Assessment notes are mandatory for vulnerability.'
                  : 'Details are mandatory when “Yes” is chosen.'}
              </p>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <form id="fact-find-stage2-form" onSubmit={onSubmit} className="space-y-6">
      
      {/* Stage 2 Header banner */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-100 text-indigo-700 rounded-lg shrink-0">
            <HeartHandshake className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Stage 2: Personal Circumstances, Vulnerability &amp; Family
            </h3>
            <p className="text-xs text-slate-600 mt-0.5">
              {hasSecondClient
                ? 'Side-by-side compliance and background capture for both Client 1 and Client 2.'
                : 'Capture personal situation, vulnerability status, PEP sanctions, and family details.'}
            </p>
          </div>
        </div>
        {hasSecondClient && (
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-indigo-50 border border-indigo-200 text-indigo-800 rounded-lg text-xs font-semibold self-start sm:self-center">
            <Users className="w-3.5 h-3.5" />
            <span>Married Couple / 2 Clients Enabled</span>
          </div>
        )}
      </div>

      {/* Joint Marital Status Card */}
      <div className="border border-slate-200 rounded-xl p-5 bg-white shadow-2xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-slate-100 text-slate-700 text-xs font-bold flex items-center justify-center">
              ★
            </div>
            <div>
              <label htmlFor="marital-status-select" className="text-xs font-bold text-slate-900 block">
                Marital Status {hasSecondClient ? '(Joint / Household)' : ''}
              </label>
              <span className="text-[11px] text-slate-500">
                Select the legal marital / relationship status
              </span>
            </div>
          </div>
          {maritalStatus && (
            <span className="text-[11px] font-semibold px-2.5 py-0.5 bg-slate-100 text-slate-700 rounded-full border border-slate-200">
              Current: {maritalStatus}
            </span>
          )}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {MARITAL_STATUS_OPTIONS.map((opt) => {
            const isSelected = maritalStatus === opt.value;
            return (
              <button
                key={opt.value}
                type="button"
                id={`marital-status-${opt.value.toLowerCase().replace(/\s+/g, '-')}`}
                onClick={() => onChangeMaritalStatus(opt.value)}
                className={`p-3 text-left rounded-xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'border-indigo-600 bg-indigo-50/50 ring-2 ring-indigo-500/20'
                    : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50/60'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className={`text-xs font-bold ${isSelected ? 'text-indigo-950' : 'text-slate-800'}`}>
                    {opt.label}
                  </span>
                  {isSelected && (
                    <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />
                  )}
                </div>
                <p className="text-[10px] text-slate-500 mt-1 line-clamp-1">
                  {opt.description}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Compliance / Vulnerability Note */}
      <div className="p-3.5 bg-amber-50/60 border border-amber-200/80 rounded-xl flex items-start gap-2.5 text-xs text-amber-900">
        <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
        <div className="space-y-0.5">
          <span className="font-bold block">FCA Consumer Duty Vulnerability Assessment Guidance</span>
          <p className="text-[11px] text-amber-800 leading-relaxed">
            Every client must undergo an individual vulnerability assessment. Selecting <strong>"No"</strong> automatically inserts the standard sound capacity confirmation, which can be modified if specific positive traits apply.
          </p>
        </div>
      </div>

      {/* Stage 2 Questions: Single Client OR Side-by-Side View */}
      {hasSecondClient ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* ============================================================ */}
          {/* CLIENT 1 COLUMN (LEFT SIDE)                                  */}
          {/* ============================================================ */}
          <div className="border border-blue-200 rounded-2xl p-5 bg-white shadow-2xs space-y-4">
            
            {/* Column Header */}
            <div className="flex items-center justify-between pb-3 border-b border-blue-100 bg-blue-50/40 -mx-5 -mt-5 p-4 rounded-t-2xl">
              <div className="flex items-center gap-2.5">
                <div className="w-6 h-6 rounded-full bg-blue-600 text-white text-xs font-bold flex items-center justify-center shadow-xs">
                  1
                </div>
                <div>
                  <h4 className="text-xs font-bold text-blue-950 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-blue-600" />
                    <span>Client 1 (Left Side)</span>
                  </h4>
                  <span className="text-[11px] font-semibold text-blue-800 truncate block max-w-[220px]">
                    {client1DisplayName}
                  </span>
                </div>
              </div>
              <span className="text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 bg-blue-100 text-blue-800 rounded-full border border-blue-200">
                Primary Client
              </span>
            </div>

            {/* Questions for Client 1 */}
            <div className="space-y-3.5 pt-1">
              {YES_NO_QUESTIONS.map(item =>
                renderQuestionCard(item, 'c1', c1State, onChangeC1State, 'blue')
              )}
            </div>
          </div>

          {/* ============================================================ */}
          {/* CLIENT 2 COLUMN (RIGHT SIDE)                                 */}
          {/* ============================================================ */}
          <div className="border border-indigo-200 rounded-2xl p-5 bg-white shadow-2xs space-y-4">
            
            {/* Column Header */}
            <div className="flex items-center justify-between pb-3 border-b border-indigo-100 bg-indigo-50/40 -mx-5 -mt-5 p-4 rounded-t-2xl">
              <div className="flex items-center gap-2.5">
                <div className="w-6 h-6 rounded-full bg-indigo-600 text-white text-xs font-bold flex items-center justify-center shadow-xs">
                  2
                </div>
                <div>
                  <h4 className="text-xs font-bold text-indigo-950 flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Client 2 (Right Side)</span>
                  </h4>
                  <span className="text-[11px] font-semibold text-indigo-800 truncate block max-w-[220px]">
                    {client2DisplayName}
                  </span>
                </div>
              </div>
              <span className="text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 bg-indigo-100 text-indigo-800 rounded-full border border-indigo-200">
                Partner / Spouse
              </span>
            </div>

            {/* Questions for Client 2 */}
            <div className="space-y-3.5 pt-1">
              {YES_NO_QUESTIONS.map(item =>
                renderQuestionCard(item, 'c2', c2State, onChangeC2State, 'indigo')
              )}
            </div>
          </div>

        </div>
      ) : (
        /* ============================================================ */
        /* SINGLE CLIENT VIEW (When not a married couple/2 clients)     */
        /* ============================================================ */
        <div className="border border-slate-200 rounded-2xl p-5 bg-white shadow-2xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-800 text-xs font-bold flex items-center justify-center">
                1
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900">
                  Client Circumstances &amp; Regulatory Checks
                </h4>
                <span className="text-[11px] text-slate-500 font-medium">
                  {client1DisplayName}
                </span>
              </div>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 bg-slate-100 text-slate-700 rounded-full border border-slate-200">
              Single Client Application
            </span>
          </div>

          <div className="space-y-3.5 pt-1">
            {YES_NO_QUESTIONS.map(item =>
              renderQuestionCard(item, 'c1', c1State, onChangeC1State, 'blue')
            )}
          </div>
        </div>
      )}

    </form>
  );
};
