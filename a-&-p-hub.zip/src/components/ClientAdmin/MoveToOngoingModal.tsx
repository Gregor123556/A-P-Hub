import React, { useState, useEffect, useMemo } from 'react';
import { 
  X, 
  Sparkles, 
  ArrowRight, 
  TrendingUp, 
  PoundSterling, 
  Percent, 
  Calendar, 
  FileText, 
  CheckCircle2, 
  Calculator,
  User,
  ShieldCheck,
  Building2,
  Info
} from 'lucide-react';
import { ClientAdminEntry } from '../../types';
import { formatPoundSterling, parsePoundValue, normalizeServiceScope } from '../../utils/currencyUtils';

export interface MoveToOngoingModalProps {
  isOpen: boolean;
  client: ClientAdminEntry | null;
  onClose: () => void;
  onConfirm: (confirmedData: {
    estimatedValue: string;
    potentialSelectedFund: string;
    proposedFeeInitial: string;
    proposedFeeOngoing: string;
    signUpDate?: string;
    nextAction?: string;
    nextActionDueDate?: string;
  }) => Promise<void> | void;
  factFindTotalAssets?: string;
}

const POPULAR_FUNDS = [
  'Vanguard LifeStrategy 60% Equity',
  'Quilter Cirilium Moderate Portfolio',
  'L&G Multi-Index 4 Portfolio',
  'Tatton Core Active Portfolio',
  'HSBC Global Strategy Balanced',
  'Bespoke Discretionary (DFM)'
];

const INITIAL_FEE_PRESETS = ['1%', '2%', '2.5%', '3%'];
const ONGOING_FEE_PRESETS = ['0.5%', '0.75%', '1%', '1.25%'];

function getTodayFormatted(): string {
  const d = new Date();
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `${day}-${month}-${year}`;
}

function getDaysAheadFormatted(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `${day}-${month}-${year}`;
}

export const MoveToOngoingModal: React.FC<MoveToOngoingModalProps> = ({
  isOpen,
  client,
  onClose,
  onConfirm,
  factFindTotalAssets
}) => {
  const [estimatedValue, setEstimatedValue] = useState<string>('');
  const [selectedFund, setSelectedFund] = useState<string>('');
  const [initialFee, setInitialFee] = useState<string>('3%');
  const [ongoingFee, setOngoingFee] = useState<string>('1%');
  const [signUpDate, setSignUpDate] = useState<string>('');
  const [nextAction, setNextAction] = useState<string>('Issue Client Terms of Business & AFAF');
  const [nextActionDueDate, setNextActionDueDate] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Sync with client props whenever modal opens or client changes
  useEffect(() => {
    if (isOpen && client) {
      const initialVal = client.estimatedValue 
        ? formatPoundSterling(client.estimatedValue) 
        : (factFindTotalAssets ? formatPoundSterling(factFindTotalAssets) : '');
      
      setEstimatedValue(initialVal);
      setSelectedFund(client.potentialSelectedFund || 'Vanguard LifeStrategy 60% Equity');
      setInitialFee(client.proposedFeeInitial || '3%');
      setOngoingFee(client.proposedFeeOngoing || '1%');
      setSignUpDate(client.signUpDate || getTodayFormatted());
      setNextAction(client.nextAction || 'Issue Client Terms of Business & AFAF');
      setNextActionDueDate(client.nextActionDueDate || getDaysAheadFormatted(7));
      setErrorMsg(null);
      setIsSubmitting(false);
    }
  }, [isOpen, client, factFindTotalAssets]);

  // Fee calculation helper
  const feeCalculations = useMemo(() => {
    const portfolioNum = parsePoundValue(estimatedValue);
    
    // Parse initial fee percentage
    const initPct = parseFloat(initialFee.replace(/[^0-9.]/g, '')) || 0;
    const ongoingPct = parseFloat(ongoingFee.replace(/[^0-9.]/g, '')) || 0;

    const initialFeeAmount = portfolioNum > 0 && initPct > 0 ? (portfolioNum * (initPct / 100)) : 0;
    const ongoingFeeAnnual = portfolioNum > 0 && ongoingPct > 0 ? (portfolioNum * (ongoingPct / 100)) : 0;
    const ongoingFeeMonthly = ongoingFeeAnnual / 12;

    return {
      portfolioNum,
      initialFeeAmount,
      ongoingFeeAnnual,
      ongoingFeeMonthly
    };
  }, [estimatedValue, initialFee, ongoingFee]);

  if (!isOpen || !client) return null;

  const handleEstValueBlur = () => {
    if (estimatedValue.trim()) {
      setEstimatedValue(formatPoundSterling(estimatedValue));
    }
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const formattedEstVal = formatPoundSterling(estimatedValue.trim());
    const finalFund = selectedFund.trim();
    const finalInitialFee = initialFee.trim().endsWith('%') ? initialFee.trim() : `${initialFee.trim()}%`;
    const finalOngoingFee = ongoingFee.trim().endsWith('%') ? ongoingFee.trim() : `${ongoingFee.trim()}%`;

    setIsSubmitting(true);
    try {
      await onConfirm({
        estimatedValue: formattedEstVal,
        potentialSelectedFund: finalFund,
        proposedFeeInitial: finalInitialFee,
        proposedFeeOngoing: finalOngoingFee,
        signUpDate: signUpDate.trim() || getTodayFormatted(),
        nextAction: nextAction.trim() || 'Issue Client Terms of Business & AFAF',
        nextActionDueDate: nextActionDueDate.trim() || getDaysAheadFormatted(7)
      });
      onClose();
    } catch (err) {
      console.error('Failed to move client to ongoing:', err);
      setErrorMsg('An error occurred while transitioning client. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-2xl w-full my-6 flex flex-col shadow-2xl relative overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="border-b border-slate-200 p-5 sm:p-6 bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white shrink-0">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-400/20 text-emerald-300 border border-emerald-400/30 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-emerald-300" />
                  <span>Move to Ongoing Workflow</span>
                </span>
                <span className="text-xs text-slate-300 font-medium">
                  {normalizeServiceScope(client.serviceType)} • Adviser: {client.adviserName || 'Sam Adams'}
                </span>
              </div>
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <span>Confirm Setup: {client.clientName}</span>
              </h2>
              <p className="text-xs text-emerald-100/80 mt-1 max-w-lg">
                Review and confirm the Est. Portfolio valuation and agreed Proposed Funds &amp; Fees schedule before promoting into active ongoing administration.
              </p>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-300 hover:text-white bg-white/10 hover:bg-white/20 rounded-lg transition cursor-pointer"
              title="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Form Body */}
        <form id="move-to-ongoing-form" onSubmit={handleFormSubmit} className="p-5 sm:p-6 space-y-6 overflow-y-auto max-h-[calc(90vh-140px)]">
          
          {errorMsg && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl flex items-center gap-2">
              <Info className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* 1. Est. Portfolio Valuation */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 sm:p-5 space-y-3">
            <div className="flex items-center justify-between">
              <label htmlFor="modal-est-portfolio" className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <PoundSterling className="w-4 h-4 text-emerald-700" />
                <span>Estimated Portfolio Valuation</span>
              </label>
              {factFindTotalAssets && (
                <span className="text-[11px] text-slate-500 font-medium">
                  Fact Find Assets: <strong className="text-slate-700">{formatPoundSterling(factFindTotalAssets)}</strong>
                </span>
              )}
            </div>

            <div className="relative rounded-xl shadow-2xs">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 font-semibold">
                £
              </div>
              <input
                id="modal-est-portfolio"
                type="text"
                value={estimatedValue.startsWith('£') ? estimatedValue.slice(1) : estimatedValue}
                onChange={(e) => setEstimatedValue(e.target.value)}
                onBlur={handleEstValueBlur}
                placeholder="e.g. 520,000"
                className="w-full pl-8 pr-3.5 py-2.5 text-base font-semibold text-slate-900 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition"
              />
            </div>
            <p className="text-[11px] text-slate-500">
              Total estimated funds being transferred, managed, or advised across pension, ISA, GIA, or bond accounts.
            </p>
          </div>

          {/* 2. Proposed Fund Selection */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 sm:p-5 space-y-3">
            <label htmlFor="modal-proposed-fund" className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-emerald-700" />
              <span>Proposed Fund / Strategy</span>
            </label>

            <input
              id="modal-proposed-fund"
              type="text"
              value={selectedFund}
              onChange={(e) => setSelectedFund(e.target.value)}
              placeholder="e.g. Vanguard LifeStrategy 60% Equity"
              className="w-full px-3.5 py-2.5 text-sm font-medium text-slate-900 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition"
            />

            {/* Quick Pick Fund Chips */}
            <div className="space-y-1.5 pt-1">
              <span className="text-[11px] text-slate-500 font-medium">Quick Select Portfolios:</span>
              <div className="flex flex-wrap gap-1.5">
                {POPULAR_FUNDS.map((fund) => {
                  const isSelected = selectedFund === fund;
                  return (
                    <button
                      key={fund}
                      type="button"
                      onClick={() => setSelectedFund(fund)}
                      className={`text-[11px] px-2.5 py-1 rounded-lg border font-medium transition cursor-pointer ${
                        isSelected 
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs font-semibold' 
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {fund}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* 3. Proposed Fees Schedule */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 sm:p-5 space-y-4">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
              <Percent className="w-4 h-4 text-emerald-700" />
              <span>Agreed Fee Schedule</span>
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Initial Fee */}
              <div className="space-y-1.5">
                <span className="text-xs font-semibold text-slate-700">Initial Advice Fee</span>
                <input
                  type="text"
                  value={initialFee}
                  onChange={(e) => setInitialFee(e.target.value)}
                  placeholder="3%"
                  className="w-full px-3.5 py-2 text-sm font-mono font-semibold text-slate-900 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition"
                />
                <div className="flex items-center gap-1 pt-1">
                  {INITIAL_FEE_PRESETS.map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setInitialFee(preset)}
                      className={`text-[10px] px-2 py-0.5 rounded border transition cursor-pointer ${
                        initialFee === preset
                          ? 'bg-emerald-100 text-emerald-900 border-emerald-300 font-bold'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>

              {/* Ongoing Servicing Fee */}
              <div className="space-y-1.5">
                <span className="text-xs font-semibold text-slate-700">Ongoing Servicing Fee</span>
                <input
                  type="text"
                  value={ongoingFee}
                  onChange={(e) => setOngoingFee(e.target.value)}
                  placeholder="1%"
                  className="w-full px-3.5 py-2 text-sm font-mono font-semibold text-slate-900 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition"
                />
                <div className="flex items-center gap-1 pt-1">
                  {ONGOING_FEE_PRESETS.map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setOngoingFee(preset)}
                      className={`text-[10px] px-2 py-0.5 rounded border transition cursor-pointer ${
                        ongoingFee === preset
                          ? 'bg-emerald-100 text-emerald-900 border-emerald-300 font-bold'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Real-Time Monetary Fee Projection Card */}
            {feeCalculations.portfolioNum > 0 && (
              <div className="bg-emerald-50/80 border border-emerald-200 rounded-xl p-3.5 flex items-center justify-between gap-4 flex-wrap">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-2xs">
                    <Calculator className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-900 block">
                      Estimated Practice Remuneration
                    </span>
                    <span className="text-xs text-emerald-800">
                      Based on portfolio valuation of <strong>{formatPoundSterling(feeCalculations.portfolioNum)}</strong>
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-xs font-mono">
                  <div>
                    <span className="text-[10px] text-emerald-700 block uppercase">Est. Initial Fee</span>
                    <strong className="text-emerald-950 text-sm">
                      {formatPoundSterling(Math.round(feeCalculations.initialFeeAmount))}
                    </strong>
                  </div>
                  <div className="h-6 w-px bg-emerald-200" />
                  <div>
                    <span className="text-[10px] text-emerald-700 block uppercase">Est. Ongoing / Year</span>
                    <strong className="text-emerald-950 text-sm">
                      {formatPoundSterling(Math.round(feeCalculations.ongoingFeeAnnual))}
                    </strong>
                    <span className="text-[10px] text-emerald-700 block">
                      ({formatPoundSterling(Math.round(feeCalculations.ongoingFeeMonthly))}/mo)
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* 4. Onboarding Workflow Action & Dates */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label htmlFor="modal-sign-up-date" className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>Client Sign-Up / Agreement Date</span>
              </label>
              <input
                id="modal-sign-up-date"
                type="text"
                value={signUpDate}
                onChange={(e) => setSignUpDate(e.target.value)}
                placeholder="DD-MM-YYYY"
                className="w-full px-3.5 py-2 text-xs font-mono text-slate-900 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition"
              />
            </div>

            <div className="space-y-1.5">
              <label htmlFor="modal-next-action-due" className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>Next Action Target Date</span>
              </label>
              <input
                id="modal-next-action-due"
                type="text"
                value={nextActionDueDate}
                onChange={(e) => setNextActionDueDate(e.target.value)}
                placeholder="DD-MM-YYYY"
                className="w-full px-3.5 py-2 text-xs font-mono text-slate-900 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition"
              />
            </div>

            <div className="sm:col-span-2 space-y-1.5">
              <label htmlFor="modal-next-action" className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-slate-400" />
                <span>First Ongoing Milestone / Next Action</span>
              </label>
              <input
                id="modal-next-action"
                type="text"
                value={nextAction}
                onChange={(e) => setNextAction(e.target.value)}
                placeholder="e.g. Issue Client Terms of Business & AFAF"
                className="w-full px-3.5 py-2 text-xs text-slate-900 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition"
              />
            </div>
          </div>

          {/* Workflow Notice Banner */}
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-3.5 text-xs text-blue-900 flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-blue-950">Next: Ongoing Checklist Initialization</p>
              <p className="text-[11px] text-blue-800 mt-0.5">
                Promoting <strong>{client.clientName}</strong> will initialize the 9-stage Ongoing Checklist (Terms of Business, AFAF, ID3/AML, ATR, Suitability Report, through to Xplan FF). Proposed Funds &amp; Fees will be locked in and viewable throughout the Ongoing section.
              </p>
            </div>
          </div>
        </form>

        {/* Footer */}
        <div className="border-t border-slate-200 p-4 sm:p-5 bg-slate-50 flex items-center justify-between gap-3 shrink-0">
          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl transition cursor-pointer"
          >
            Cancel
          </button>

          <button
            type="submit"
            form="move-to-ongoing-form"
            disabled={isSubmitting}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs transition cursor-pointer disabled:opacity-50"
          >
            {isSubmitting ? (
              <span>Updating Client File...</span>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Confirm &amp; Move to Ongoing</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </div>

      </div>
    </div>
  );
};
