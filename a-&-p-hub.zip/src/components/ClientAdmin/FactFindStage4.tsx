import React from 'react';
import { 
  Building, 
  Plus, 
  Trash2, 
  PoundSterling, 
  FileText, 
  Landmark, 
  HelpCircle,
  TrendingUp,
  Info,
  CreditCard,
  AlertCircle,
  Receipt
} from 'lucide-react';
import { 
  FactFindAssetItem, 
  FactFindAssetType, 
  FactFindLiabilityItem,
  FactFindLiabilityType,
  FactFindYesNoQuestion 
} from '../../types';

export const ASSET_TYPE_OPTIONS: { value: FactFindAssetType; label: string }[] = [
  { value: 'Residential Property', label: 'Residential Property' },
  { value: 'Additional Property', label: 'Additional Property' },
  { value: 'Pension Pot', label: 'Pension Pot' },
  { value: 'Cash ISA', label: 'Cash ISA' },
  { value: 'Stock & Shares ISA', label: 'Stock & Shares ISA' },
  { value: 'Standard Savings Account', label: 'Standard Savings Account' },
  { value: 'Premium Bonds', label: 'Premium Bonds' },
  { value: 'GIA', label: 'GIA (General Investment Account)' },
  { value: 'Other', label: 'Other (Specify below)' },
];

export const LIABILITY_TYPE_OPTIONS: { value: FactFindLiabilityType; label: string }[] = [
  { value: 'Mortgage', label: 'Mortgage' },
  { value: 'Car Loan', label: 'Car Loan' },
  { value: 'Other', label: 'Other' },
];

export const DEFAULT_1_ASSET_ROW: FactFindAssetItem = {
  id: 'asset-row-1',
  assetType: 'Residential Property',
  otherAssetType: '',
  providerPlatform: '',
  approxValue: '',
  notes: '',
  owner: 'Client 1'
};

export const DEFAULT_4_ASSET_ROWS: FactFindAssetItem[] = [DEFAULT_1_ASSET_ROW];

export const DEFAULT_1_LIABILITY_ROW: FactFindLiabilityItem = {
  id: 'liability-row-1',
  liabilityType: 'Mortgage',
  amountOutstanding: '',
  monthlyRepayment: '',
  notes: '',
  owner: 'Client 1'
};

interface FactFindStage4Props {
  assets: FactFindAssetItem[];
  onChangeAssets?: (assets: FactFindAssetItem[]) => void;
  setAssets?: React.Dispatch<React.SetStateAction<FactFindAssetItem[]>> | ((assets: FactFindAssetItem[]) => void);
  liabilityItems?: FactFindLiabilityItem[];
  onChangeLiabilityItems?: (items: FactFindLiabilityItem[]) => void;
  setLiabilityItems?: React.Dispatch<React.SetStateAction<FactFindLiabilityItem[]>> | ((items: FactFindLiabilityItem[]) => void);
  liabilities?: FactFindYesNoQuestion;
  onChangeLiabilities?: (liabilities: FactFindYesNoQuestion) => void;
  setLiabilities?: React.Dispatch<React.SetStateAction<FactFindYesNoQuestion>> | ((liabilities: FactFindYesNoQuestion) => void);
  fieldErrors?: Record<string, boolean>;
  onClearFieldError?: (key: string) => void;
  c1FullName?: string;
  c2FullName?: string;
  client1Name?: string;
  client2Name?: string;
  hasSecondClient?: boolean;
  adviser?: string;
  adviserName?: string;
  onBackToStage3: () => void;
  onSubmit: (e: React.FormEvent) => void;
}

export const FactFindStage4: React.FC<FactFindStage4Props> = ({
  assets,
  onChangeAssets,
  setAssets,
  liabilityItems,
  onChangeLiabilityItems,
  setLiabilityItems,
  liabilities = { answered: '', details: '' },
  onChangeLiabilities,
  setLiabilities,
  fieldErrors = {},
  onClearFieldError,
  c1FullName,
  c2FullName,
  client1Name,
  client2Name,
  hasSecondClient,
  adviser,
  adviserName,
  onBackToStage3,
  onSubmit
}) => {
  const currentAssets = assets && assets.length > 0 ? assets : [DEFAULT_1_ASSET_ROW];
  const currentLiabilities = liabilityItems && liabilityItems.length > 0 ? liabilityItems : [DEFAULT_1_LIABILITY_ROW];
  const primaryClient = c1FullName || client1Name || 'Primary Client';
  const secondClient = c2FullName || client2Name;
  const leadAdviser = adviser || adviserName || 'Lead Adviser';
  const isJoint = hasSecondClient !== undefined ? hasSecondClient : Boolean(secondClient);

  // Extract first names for Client 1 & Client 2 dropdown
  const getFirstName = (fullName?: string, fallback = 'Client'): string => {
    const trimmed = (fullName || '').trim();
    if (!trimmed) return fallback;
    const first = trimmed.split(/\s+/)[0];
    return first || fallback;
  };

  const c1FirstName = getFirstName(c1FullName || client1Name, 'Client 1');
  const c2FirstName = getFirstName(c2FullName || client2Name, 'Client 2');

  const notifyChangeAssets = (updated: FactFindAssetItem[]) => {
    if (typeof onChangeAssets === 'function') {
      onChangeAssets(updated);
    }
    if (typeof setAssets === 'function') {
      setAssets(updated);
    }
  };

  const notifyChangeLiabilities = (updated: FactFindLiabilityItem[]) => {
    if (typeof onChangeLiabilityItems === 'function') {
      onChangeLiabilityItems(updated);
    }
    if (typeof setLiabilityItems === 'function') {
      setLiabilityItems(updated);
    }
  };

  const handleUpdateLiabilities = (updated: FactFindYesNoQuestion) => {
    if (typeof onChangeLiabilities === 'function') {
      onChangeLiabilities(updated);
    }
    if (typeof setLiabilities === 'function') {
      setLiabilities(updated);
    }
    if (fieldErrors['liabilities'] && onClearFieldError && (updated.answered === 'no' || (updated.details && updated.details.trim()))) {
      onClearFieldError('liabilities');
    }
  };

  const handleUpdateRow = (index: number, updates: Partial<FactFindAssetItem>) => {
    const updated = [...currentAssets];
    updated[index] = { ...updated[index], ...updates };
    notifyChangeAssets(updated);
    if (updates.approxValue && fieldErrors[`asset-val-${index}`] && onClearFieldError) {
      onClearFieldError(`asset-val-${index}`);
    }
  };

  const handleAddRow = () => {
    const newRow: FactFindAssetItem = {
      id: `asset-row-${Date.now()}`,
      assetType: 'Standard Savings Account',
      otherAssetType: '',
      providerPlatform: '',
      approxValue: '',
      notes: '',
      owner: 'Client 1'
    };
    notifyChangeAssets([...currentAssets, newRow]);
  };

  const handleRemoveRow = (index: number) => {
    if (currentAssets.length <= 1) {
      // Reset single row instead of empty
      notifyChangeAssets([{
        id: `asset-row-${Date.now()}`,
        assetType: 'Residential Property',
        otherAssetType: '',
        providerPlatform: '',
        approxValue: '',
        notes: '',
        owner: 'Client 1'
      }]);
      return;
    }
    const updated = currentAssets.filter((_, i) => i !== index);
    notifyChangeAssets(updated);
  };

  // Helper to format asset currency string on blur
  const formatPoundsOnBlur = (index: number, rawVal: string) => {
    if (!rawVal || !rawVal.trim()) return;
    const cleanNum = rawVal.replace(/[^0-9.]/g, '');
    const num = parseFloat(cleanNum);
    if (!isNaN(num)) {
      const formatted = '£' + Math.round(num).toLocaleString('en-GB');
      handleUpdateRow(index, { approxValue: formatted });
    }
  };

  // Liabilities Handlers
  const handleUpdateLiabilityRow = (index: number, updates: Partial<FactFindLiabilityItem>) => {
    const updated = [...currentLiabilities];
    updated[index] = { ...updated[index], ...updates };
    notifyChangeLiabilities(updated);
    if (updates.amountOutstanding && fieldErrors[`liability-amount-${index}`] && onClearFieldError) {
      onClearFieldError(`liability-amount-${index}`);
    }
  };

  const handleAddLiabilityRow = () => {
    const newRow: FactFindLiabilityItem = {
      id: `liability-row-${Date.now()}`,
      liabilityType: 'Mortgage',
      amountOutstanding: '',
      monthlyRepayment: '',
      notes: '',
      owner: 'Client 1'
    };
    notifyChangeLiabilities([...currentLiabilities, newRow]);
  };

  const handleRemoveLiabilityRow = (index: number) => {
    if (currentLiabilities.length <= 1) {
      notifyChangeLiabilities([{
        id: `liability-row-${Date.now()}`,
        liabilityType: 'Mortgage',
        amountOutstanding: '',
        monthlyRepayment: '',
        notes: '',
        owner: 'Client 1'
      }]);
      return;
    }
    const updated = currentLiabilities.filter((_, i) => i !== index);
    notifyChangeLiabilities(updated);
  };

  // Helper to format liability currency strings on blur
  const formatLiabilityAmountOnBlur = (index: number, field: 'amountOutstanding' | 'monthlyRepayment', rawVal: string) => {
    if (!rawVal || !rawVal.trim()) return;
    const cleanNum = rawVal.replace(/[^0-9.]/g, '');
    const num = parseFloat(cleanNum);
    if (!isNaN(num)) {
      const formatted = '£' + Math.round(num).toLocaleString('en-GB');
      handleUpdateLiabilityRow(index, { [field]: formatted });
    }
  };

  // Calculate live total approx assets
  const totalAssetsValue = currentAssets.reduce((sum, item) => {
    if (!item.approxValue) return sum;
    const cleanNum = item.approxValue.replace(/[^0-9.]/g, '');
    const val = parseFloat(cleanNum);
    return isNaN(val) ? sum : sum + val;
  }, 0);

  // Calculate live total liabilities outstanding & monthly repayments
  const totalLiabilitiesOutstanding = currentLiabilities.reduce((sum, item) => {
    if (!item.amountOutstanding) return sum;
    const cleanNum = item.amountOutstanding.replace(/[^0-9.]/g, '');
    const val = parseFloat(cleanNum);
    return isNaN(val) ? sum : sum + val;
  }, 0);

  const totalMonthlyRepayments = currentLiabilities.reduce((sum, item) => {
    if (!item.monthlyRepayment) return sum;
    const cleanNum = item.monthlyRepayment.replace(/[^0-9.]/g, '');
    const val = parseFloat(cleanNum);
    return isNaN(val) ? sum : sum + val;
  }, 0);

  const isLiabilitiesYes = liabilities.answered === 'yes';
  const isLiabilitiesNo = liabilities.answered === 'no';
  const liabilitiesHasError = Boolean(fieldErrors['liabilities']);

  return (
    <form id="fact-find-stage4-form" onSubmit={onSubmit} className="space-y-6 animate-in fade-in duration-150">
      
      {/* Context Summary Banner */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-100 text-blue-700 rounded-lg shrink-0">
            <Building className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-900">
              Stage 4: Assets and Liabilities
            </h3>
            <p className="text-[11px] text-slate-500">
              Client: <span className="font-semibold text-slate-800">{primaryClient}</span> {isJoint && secondClient ? `& ${secondClient}` : ''} • Adviser: {leadAdviser}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 self-start sm:self-auto flex-wrap sm:flex-nowrap">
          <div className="bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-xl text-right">
            <span className="text-[10px] uppercase font-bold text-emerald-800 tracking-wider block">
              Total Assets Value
            </span>
            <span className="text-sm font-bold text-emerald-950 font-mono">
              £{Math.round(totalAssetsValue).toLocaleString('en-GB')}
            </span>
          </div>

          {isLiabilitiesYes && totalLiabilitiesOutstanding > 0 && (
            <div className="bg-rose-50 border border-rose-200 px-3 py-1.5 rounded-xl text-right">
              <span className="text-[10px] uppercase font-bold text-rose-800 tracking-wider block">
                Total Liabilities
              </span>
              <span className="text-sm font-bold text-rose-950 font-mono">
                £{Math.round(totalLiabilitiesOutstanding).toLocaleString('en-GB')}
              </span>
            </div>
          )}

          <button
            type="button"
            onClick={onBackToStage3}
            className="text-xs font-semibold text-blue-600 hover:text-blue-800 hover:underline flex items-center gap-1 shrink-0 cursor-pointer ml-1"
          >
            ← Back to Stage 3
          </button>
        </div>
      </div>

      {/* Assets Table Container */}
      <div className="border border-slate-200 rounded-xl bg-white shadow-2xs overflow-hidden">
        
        {/* Table Header Controls */}
        <div className="p-4 border-b border-slate-100 bg-slate-50/70 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h4 className="text-xs font-bold text-slate-900 flex items-center gap-2">
              <span>Client Assets Schedule</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-100 text-blue-800 border border-blue-200">
                {currentAssets.length} Assets Listed
              </span>
            </h4>
            <p className="text-[11px] text-slate-500">
              Captures properties, tax wrappers, investment accounts, cash deposits, and alternative assets.
            </p>
          </div>

          <button
            type="button"
            onClick={handleAddRow}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition cursor-pointer self-start sm:self-auto"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ Add Asset Row</span>
          </button>
        </div>

        {/* Table Container without horizontal scrolling */}
        <div className="w-full overflow-hidden">
          <table className="w-full text-left border-collapse table-fixed">
            <colgroup>
              <col style={{ width: '4%' }} />
              {isJoint ? (
                <>
                  <col style={{ width: '22%' }} />
                  <col style={{ width: '20%' }} />
                  <col style={{ width: '17%' }} />
                  <col style={{ width: '14%' }} />
                  <col style={{ width: '19%' }} />
                </>
              ) : (
                <>
                  <col style={{ width: '26%' }} />
                  <col style={{ width: '23%' }} />
                  <col style={{ width: '20%' }} />
                  <col style={{ width: '23%' }} />
                </>
              )}
              <col style={{ width: '4%' }} />
            </colgroup>
            <thead>
              <tr className="bg-slate-100/80 text-[11px] font-bold text-slate-700 uppercase tracking-wider border-b border-slate-200">
                <th className="py-2.5 px-1.5 text-center">#</th>
                <th className="py-2.5 px-1.5 truncate">
                  Asset Type <span className="text-rose-500">*</span>
                </th>
                <th className="py-2.5 px-1.5 truncate">
                  Provider / Platform
                </th>
                <th className="py-2.5 px-1.5 truncate">
                  Approx Value <span className="text-slate-400 font-normal font-sans">(£)</span>
                </th>
                {isJoint && (
                  <th className="py-2.5 px-1.5 truncate">
                    Client
                  </th>
                )}
                <th className="py-2.5 px-1.5 truncate">
                  Notes
                </th>
                <th className="py-2.5 px-1.5 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {currentAssets.map((asset, index) => {
                const isOther = asset.assetType === 'Other';
                const hasError = fieldErrors[`asset-other-${index}`];

                return (
                  <tr 
                    key={asset.id || `asset-${index}`} 
                    className="hover:bg-slate-50/70 transition-colors group align-top"
                  >
                    {/* Row Index */}
                    <td className="py-2.5 px-1 text-center text-slate-400 font-mono font-medium pt-3.5">
                      {index + 1}
                    </td>

                    {/* Column 1: Asset Type Dropdown (with conditional Other text box) */}
                    <td className="py-2 px-1.5 space-y-1.5">
                      <div className="relative">
                        <select
                          value={asset.assetType || 'Residential Property'}
                          onChange={(e) => {
                            const val = e.target.value as FactFindAssetType;
                            handleUpdateRow(index, { 
                              assetType: val,
                              otherAssetType: val !== 'Other' ? '' : asset.otherAssetType 
                            });
                          }}
                          className="w-full min-w-0 py-1.5 px-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-900 font-medium cursor-pointer"
                        >
                          {ASSET_TYPE_OPTIONS.map((opt) => (
                            <option key={opt.value} value={opt.value}>
                              {opt.label}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* If Other selected, dynamic text box appears */}
                      {isOther && (
                        <div className="animate-in fade-in slide-in-from-top-1 space-y-1">
                          <input
                            type="text"
                            value={asset.otherAssetType || ''}
                            onChange={(e) => {
                              handleUpdateRow(index, { otherAssetType: e.target.value });
                              if (fieldErrors[`asset-other-${index}`] && e.target.value.trim() && onClearFieldError) {
                                onClearFieldError(`asset-other-${index}`);
                              }
                            }}
                            placeholder="Specify alternative asset..."
                            className={`w-full min-w-0 py-1.5 px-2 text-xs rounded-lg border bg-white focus:outline-none transition ${
                              hasError 
                                ? 'border-rose-400 focus:ring-2 focus:ring-rose-200 bg-rose-50/20 text-slate-900' 
                                : 'border-slate-300 focus:ring-2 focus:ring-blue-500 text-slate-900'
                            }`}
                            required={isOther}
                          />
                          {hasError && (
                            <span className="text-[10px] text-rose-600 font-semibold block truncate">
                              Specify custom asset type
                            </span>
                          )}
                        </div>
                      )}
                    </td>

                    {/* Column 2: Provider / Platform */}
                    <td className="py-2 px-1.5">
                      <div className="relative">
                        <Landmark className="w-3.5 h-3.5 text-slate-400 absolute left-2 top-2 pointer-events-none" />
                        <input
                          type="text"
                          value={asset.providerPlatform || ''}
                          onChange={(e) => handleUpdateRow(index, { providerPlatform: e.target.value })}
                          placeholder="Platform / Bank"
                          className="w-full min-w-0 pl-6 pr-2 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-900"
                        />
                      </div>
                    </td>

                    {/* Column 3: Approx Value (Formatted in Pounds) */}
                    <td className="py-2 px-1.5">
                      <div className="relative">
                        <PoundSterling className="w-3.5 h-3.5 text-slate-400 absolute left-2 top-2 pointer-events-none" />
                        <input
                          type="text"
                          value={asset.approxValue || ''}
                          onChange={(e) => handleUpdateRow(index, { approxValue: e.target.value })}
                          onBlur={(e) => formatPoundsOnBlur(index, e.target.value)}
                          placeholder="£150,000"
                          className="w-full min-w-0 pl-6 pr-2 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono text-slate-900 font-semibold"
                        />
                      </div>
                    </td>

                    {/* Column 4: Client (Rendered if 2 clients in Stage 1) */}
                    {isJoint && (
                      <td className="py-2 px-1.5 space-y-1">
                        <select
                          value={asset.owner || 'Client 1'}
                          onChange={(e) => handleUpdateRow(index, { owner: e.target.value })}
                          className="w-full min-w-0 py-1.5 px-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-900 font-medium cursor-pointer"
                        >
                          <option value="Client 1">{c1FirstName}</option>
                          <option value="Client 2">{c2FirstName}</option>
                          <option value="Joint">Joint</option>
                        </select>
                      </td>
                    )}

                    {/* Column 5: Notes */}
                    <td className="py-2 px-1.5">
                      <div className="relative">
                        <FileText className="w-3.5 h-3.5 text-slate-400 absolute left-2 top-2 pointer-events-none" />
                        <input
                          type="text"
                          value={asset.notes || ''}
                          onChange={(e) => handleUpdateRow(index, { notes: e.target.value })}
                          placeholder="Notes / terms..."
                          className="w-full min-w-0 pl-6 pr-2 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-900"
                        />
                      </div>
                    </td>

                    {/* Row Action: Delete */}
                    <td className="py-2 px-1 text-center pt-2.5">
                      <button
                        type="button"
                        onClick={() => handleRemoveRow(index)}
                        className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                        title={currentAssets.length <= 1 ? 'Clear row' : 'Remove this asset row'}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr className="bg-slate-50 font-bold border-t border-slate-200">
                <td colSpan={3} className="py-2.5 px-3 text-right text-xs text-slate-700">
                  Total Estimated Portfolio Value:
                </td>
                <td className="py-2.5 px-2 font-mono text-xs font-bold text-emerald-800 bg-emerald-50/50 truncate">
                  £{Math.round(totalAssetsValue).toLocaleString('en-GB')}
                </td>
                <td colSpan={isJoint ? 3 : 2} className="py-2.5 px-2 text-[11px] text-slate-500 font-normal">
                  Live calculated aggregate sum
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* ============================================================ */}
      {/* SECTION: LIABILITIES (YES / NO QUESTION)                     */}
      {/* ============================================================ */}
      <div className={`p-4 rounded-xl border transition-all bg-white ${
        liabilitiesHasError
          ? 'border-rose-400 bg-rose-50/20 ring-2 ring-rose-400/20'
          : isLiabilitiesYes
          ? 'border-amber-300 bg-amber-50/10 shadow-xs'
          : 'border-slate-200'
      }`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3 flex-1">
            <div className={`p-2 rounded-lg shrink-0 mt-0.5 ${
              isLiabilitiesYes ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600'
            }`}>
              <CreditCard className="w-4 h-4" />
            </div>
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-900">
                  Liabilities?
                </span>
                {isLiabilitiesYes && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200 uppercase tracking-wide">
                    Schedule Active
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-600 leading-snug">
                Does the client have any outstanding mortgages, car loans, bank finance, or other financial liabilities?
              </p>
              <p className="text-[10px] text-slate-400">
                Selecting &ldquo;Yes&rdquo; opens the itemised liabilities schedule table to record balances and monthly repayments.
              </p>
            </div>
          </div>

          {/* Yes / No Choice Buttons */}
          <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
            {/* Yes Button */}
            <button
              type="button"
              onClick={() => {
                handleUpdateLiabilities({
                  ...liabilities,
                  answered: 'yes'
                });
              }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
                isLiabilitiesYes
                  ? 'bg-amber-600 border-amber-600 text-white shadow-xs'
                  : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <div className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                isLiabilitiesYes ? 'border-white bg-white' : 'border-slate-400'
              }`}>
                {isLiabilitiesYes && <div className="w-1.5 h-1.5 rounded-full bg-amber-600" />}
              </div>
              <span>Yes</span>
            </button>

            {/* No Button */}
            <button
              type="button"
              onClick={() => {
                handleUpdateLiabilities({
                  answered: 'no',
                  details: ''
                });
              }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
                isLiabilitiesNo
                  ? 'bg-slate-700 border-slate-700 text-white shadow-xs'
                  : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <div className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                isLiabilitiesNo ? 'border-white bg-white' : 'border-slate-400'
              }`}>
                {isLiabilitiesNo && <div className="w-1.5 h-1.5 rounded-full bg-slate-700" />}
              </div>
              <span>No</span>
            </button>
          </div>
        </div>

        {/* ============================================================ */}
        {/* LIABILITIES SCHEDULE TABLE (Appears ONLY when Yes is selected)*/}
        {/* ============================================================ */}
        {isLiabilitiesYes && (
          <div className="mt-4 pt-4 border-t border-amber-200/80 animate-in fade-in slide-in-from-top-2 space-y-3">
            
            {/* Table Container */}
            <div className="border border-slate-200 rounded-xl bg-white shadow-2xs overflow-hidden">
              
              {/* Table Header Controls */}
              <div className="p-4 border-b border-slate-100 bg-slate-50/70 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h4 className="text-xs font-bold text-slate-900 flex items-center gap-2">
                    <span>Client Liabilities Schedule</span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-100 text-amber-800 border border-amber-200">
                      {currentLiabilities.length} {currentLiabilities.length === 1 ? 'Liability' : 'Liabilities'} Listed
                    </span>
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Captures mortgages, car loans, bank financing, and other liabilities.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleAddLiabilityRow}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-lg transition cursor-pointer self-start sm:self-auto"
                >
                  <Plus className="w-3.5 h-3.5 text-amber-700" />
                  <span>+ Add Liability Row</span>
                </button>
              </div>

              {/* Table Body without horizontal scrolling */}
              <div className="w-full overflow-hidden">
                <table className="w-full text-left border-collapse table-fixed">
                  <colgroup>
                    <col style={{ width: '4%' }} />
                    {isJoint ? (
                      <>
                        <col style={{ width: '21%' }} />
                        <col style={{ width: '20%' }} />
                        <col style={{ width: '18%' }} />
                        <col style={{ width: '14%' }} />
                        <col style={{ width: '19%' }} />
                      </>
                    ) : (
                      <>
                        <col style={{ width: '24%' }} />
                        <col style={{ width: '23%' }} />
                        <col style={{ width: '21%' }} />
                        <col style={{ width: '24%' }} />
                      </>
                    )}
                    <col style={{ width: '4%' }} />
                  </colgroup>
                  <thead>
                    <tr className="bg-slate-100/80 text-[11px] font-bold text-slate-700 uppercase tracking-wider border-b border-slate-200">
                      <th className="py-2.5 px-1.5 text-center">#</th>
                      <th className="py-2.5 px-1.5 truncate">
                        Liability Type <span className="text-rose-500">*</span>
                      </th>
                      <th className="py-2.5 px-1.5 truncate">
                        Amount Outstanding <span className="text-rose-500">*</span> <span className="text-slate-400 font-normal font-sans">(£)</span>
                      </th>
                      <th className="py-2.5 px-1.5 truncate">
                        Monthly Repayment <span className="text-slate-400 font-normal font-sans">(£)</span>
                      </th>
                      {isJoint && (
                        <th className="py-2.5 px-1.5 truncate">
                          Client
                        </th>
                      )}
                      <th className="py-2.5 px-1.5 truncate">
                        Notes
                      </th>
                      <th className="py-2.5 px-1.5 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs">
                    {currentLiabilities.map((item, index) => {
                      const amountError = fieldErrors[`liability-amount-${index}`];

                      return (
                        <tr
                          key={item.id || `liability-${index}`}
                          className="hover:bg-slate-50/70 transition-colors group align-top"
                        >
                          {/* Row Index */}
                          <td className="py-2.5 px-1 text-center text-slate-400 font-mono font-medium pt-3.5">
                            {index + 1}
                          </td>

                          {/* Column 1: Liability Type Dropdown */}
                          <td className="py-2 px-1.5 space-y-1">
                            <select
                              value={item.liabilityType || 'Mortgage'}
                              onChange={(e) => {
                                const val = e.target.value as FactFindLiabilityType;
                                handleUpdateLiabilityRow(index, { liabilityType: val });
                              }}
                              className="w-full min-w-0 py-1.5 px-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-900 font-medium cursor-pointer"
                            >
                              {LIABILITY_TYPE_OPTIONS.map((opt) => (
                                <option key={opt.value} value={opt.value}>
                                  {opt.label}
                                </option>
                              ))}
                            </select>
                          </td>

                          {/* Column 2: Amount Outstanding (Formatted in Pounds) */}
                          <td className="py-2 px-1.5 space-y-1">
                            <div className="relative">
                              <PoundSterling className={`w-3.5 h-3.5 absolute left-2 top-2 pointer-events-none ${amountError ? 'text-rose-500' : 'text-slate-400'}`} />
                              <input
                                type="text"
                                value={item.amountOutstanding || ''}
                                onChange={(e) => handleUpdateLiabilityRow(index, { amountOutstanding: e.target.value })}
                                onBlur={(e) => formatLiabilityAmountOnBlur(index, 'amountOutstanding', e.target.value)}
                                placeholder="£210,000"
                                className={`w-full min-w-0 pl-6 pr-2 py-1.5 text-xs rounded-lg border bg-white focus:outline-none transition font-mono font-semibold ${
                                  amountError
                                    ? 'border-rose-400 focus:ring-2 focus:ring-rose-200 bg-rose-50/20 text-slate-900'
                                    : 'border-slate-300 focus:ring-2 focus:ring-blue-500 text-slate-900'
                                }`}
                              />
                            </div>
                            {amountError && (
                              <p className="text-[10px] text-rose-600 font-semibold flex items-center gap-1 truncate">
                                <AlertCircle className="w-3 h-3 shrink-0" />
                                Required
                              </p>
                            )}
                          </td>

                          {/* Column 3: Monthly Repayment Amount (Formatted in Pounds) */}
                          <td className="py-2 px-1.5 space-y-1">
                            <div className="relative">
                              <PoundSterling className="w-3.5 h-3.5 text-slate-400 absolute left-2 top-2 pointer-events-none" />
                              <input
                                type="text"
                                value={item.monthlyRepayment || ''}
                                onChange={(e) => handleUpdateLiabilityRow(index, { monthlyRepayment: e.target.value })}
                                onBlur={(e) => formatLiabilityAmountOnBlur(index, 'monthlyRepayment', e.target.value)}
                                placeholder="£850"
                                className="w-full min-w-0 pl-6 pr-2 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono text-slate-900"
                              />
                            </div>
                          </td>

                          {/* Column 4: Client (Rendered if 2 clients in Stage 1) */}
                          {isJoint && (
                            <td className="py-2 px-1.5 space-y-1">
                              <select
                                value={item.owner || 'Client 1'}
                                onChange={(e) => handleUpdateLiabilityRow(index, { owner: e.target.value })}
                                className="w-full min-w-0 py-1.5 px-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-900 font-medium cursor-pointer"
                              >
                                <option value="Client 1">{c1FirstName}</option>
                                <option value="Client 2">{c2FirstName}</option>
                                <option value="Joint">Joint</option>
                              </select>
                            </td>
                          )}

                          {/* Column 5: Notes (Standard Text Box) */}
                          <td className="py-2 px-1.5 space-y-1">
                            <div className="relative">
                              <FileText className="w-3.5 h-3.5 text-slate-400 absolute left-2 top-2 pointer-events-none" />
                              <input
                                type="text"
                                value={item.notes || ''}
                                onChange={(e) => handleUpdateLiabilityRow(index, { notes: e.target.value })}
                                placeholder="Notes / terms..."
                                className="w-full min-w-0 pl-6 pr-2 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-900"
                              />
                            </div>
                          </td>

                          {/* Row Action: Delete */}
                          <td className="py-2 px-1 text-center pt-2.5">
                            <button
                              type="button"
                              onClick={() => handleRemoveLiabilityRow(index)}
                              className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                              title={currentLiabilities.length <= 1 ? 'Clear row' : 'Remove liability'}
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                  <tfoot>
                    <tr className="bg-slate-50 font-bold border-t border-slate-200">
                      <td colSpan={2} className="py-2.5 px-3 text-right text-xs text-slate-700">
                        Total Liabilities Summary:
                      </td>
                      <td className="py-2.5 px-2 font-mono text-xs font-bold text-rose-800 bg-rose-50/50 truncate">
                        Outstanding: £{Math.round(totalLiabilitiesOutstanding).toLocaleString('en-GB')}
                      </td>
                      <td className="py-2.5 px-2 font-mono text-xs font-semibold text-slate-900 truncate">
                        Repayments: £{Math.round(totalMonthlyRepayments).toLocaleString('en-GB')}/mo
                      </td>
                      <td colSpan={isJoint ? 3 : 2} className="py-2.5 px-2 text-[11px] text-slate-500 font-normal">
                        Live calculated totals
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>

            {liabilitiesHasError && (
              <p className="text-[11px] text-rose-600 font-semibold flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                Please complete the liabilities details with outstanding amounts.
              </p>
            )}
          </div>
        )}
      </div>

      {/* Guidance Note */}
      <div className="p-3.5 bg-blue-50/70 border border-blue-200 rounded-xl flex items-start gap-2.5 text-blue-900 text-xs">
        <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
        <div className="space-y-0.5 leading-relaxed">
          <span className="font-bold block">Adviser Asset &amp; Liability Guidance:</span>
          <span>
            Ensure all major liquid and illiquid wealth holdings and debt commitments are logged. If additional items are required, click <strong>+ Add Asset Row</strong> or <strong>+ Add Liability Row</strong>. All values automatically format with the British Pound currency marker.
          </span>
        </div>
      </div>

    </form>
  );
};


