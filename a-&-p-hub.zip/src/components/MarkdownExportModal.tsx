import React, { useState } from 'react';
import { X, Copy, Check, FileText, Download, Table, List } from 'lucide-react';
import { LoAEntry } from '../types';
import { getTodayDDMMYYYY } from '../utils/dateUtils';

interface MarkdownExportModalProps {
  loas: LoAEntry[];
  isOpen: boolean;
  onClose: () => void;
}

export const MarkdownExportModal: React.FC<MarkdownExportModalProps> = ({
  loas,
  isOpen,
  onClose
}) => {
  const [exportFormat, setExportFormat] = useState<'markdownTable' | 'bulletList' | 'csv'>('markdownTable');
  const [isCopied, setIsCopied] = useState(false);

  if (!isOpen) return null;

  const todayStr = getTodayDDMMYYYY();

  const generateMarkdownTable = () => {
    let md = `### Adams & Poole Financial Services - Letter of Authority (LoA) Tracker Summary (${todayStr})\n\n`;
    md += `| Client Name | Plan Number | Account Type | Current Provider | Date Sent | Date Due (+14d) | Chase-up Date (+7d) | Status |\n`;
    md += `| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |\n`;

    loas.forEach(l => {
      md += `| ${l.clientName} | ${l.policyNumber || '—'} | ${l.accountType} | ${l.currentProvider} | ${l.dateSent} | ${l.dateDue} | ${l.chaseUpDate} | **${l.status}** |\n`;
    });

    md += `\n*Total Records: ${loas.length} | Adams & Poole Financial Services Practice Management Hub.*`;
    return md;
  };

  const generateBulletedList = () => {
    let text = `### Adams & Poole Financial Services - Weekly LoA Overview (${todayStr})\n\n`;

    const pending = loas.filter(l => l.status === 'Pending');
    const overdue = loas.filter(l => l.status === 'Overdue');
    const overdueChased = loas.filter(l => l.status === 'Overdue + Chased');
    const received = loas.filter(l => l.status === 'Received');

    text += `#### 🚨 Overdue / Overdue + Chased Items (${overdue.length + overdueChased.length})\n`;
    if (overdue.length + overdueChased.length === 0) {
      text += `- No overdue or chased LoA items.\n`;
    } else {
      [...overdue, ...overdueChased].forEach(l => {
        text += `- **${l.clientName}** (Plan: ${l.policyNumber || 'N/A'}) — ${l.currentProvider} (${l.accountType}) | Date Sent: ${l.dateSent} | Due: ${l.dateDue} | Status: **${l.status}**\n  - *Notes:* ${l.notes || 'None'}\n`;
      });
    }

    text += `\n#### ⏳ Pending Items (${pending.length})\n`;
    pending.forEach(l => {
      text += `- **${l.clientName}** (Plan: ${l.policyNumber || 'N/A'}) — ${l.currentProvider} (${l.accountType}) | Chase Date: ${l.chaseUpDate} | Due: ${l.dateDue}\n`;
    });

    text += `\n#### ✅ Completed / Received Items (${received.length})\n`;
    received.forEach(l => {
      text += `- **${l.clientName}** (Plan: ${l.policyNumber || 'N/A'}) — ${l.currentProvider} (${l.accountType}) [Completed]\n`;
    });

    return text;
  };

  const generateCSV = () => {
    let csv = `Client Name,Plan Number,Account Type,Current Provider,Date Sent,Date Due,Chase-up Date,Status,Notes\n`;
    loas.forEach(l => {
      const cleanNotes = (l.notes || '').replace(/"/g, '""');
      csv += `"${l.clientName}","${l.policyNumber || ''}","${l.accountType}","${l.currentProvider}","${l.dateSent}","${l.dateDue}","${l.chaseUpDate}","${l.status}","${cleanNotes}"\n`;
    });
    return csv;
  };

  const getExportText = () => {
    if (exportFormat === 'markdownTable') return generateMarkdownTable();
    if (exportFormat === 'bulletList') return generateBulletedList();
    return generateCSV();
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(getExportText());
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2500);
  };

  const handleDownload = () => {
    const text = getExportText();
    const ext = exportFormat === 'csv' ? 'csv' : 'md';
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Adams_and_Poole_LoA_Report_${todayStr}.${ext}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl relative animate-scaleIn overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 p-5 sm:p-6 bg-white shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-blue-50 border border-blue-100 rounded-xl text-blue-600">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Export & Practice Report Summaries
              </h3>
              <p className="text-xs text-slate-500">
                Generate structured markdown tables or bulleted lists for adviser meetings
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-4">
          {/* Format Selector */}
          <div className="flex items-center justify-between bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-xs">
            <span className="text-slate-600 font-semibold pl-2">Report Format:</span>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setExportFormat('markdownTable')}
                className={`px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 transition ${
                  exportFormat === 'markdownTable'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Table className="w-3.5 h-3.5" />
                <span>Markdown Table</span>
              </button>

              <button
                type="button"
                onClick={() => setExportFormat('bulletList')}
                className={`px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 transition ${
                  exportFormat === 'bulletList'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <List className="w-3.5 h-3.5" />
                <span>Bulleted Summary</span>
              </button>

              <button
                type="button"
                onClick={() => setExportFormat('csv')}
                className={`px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 transition ${
                  exportFormat === 'csv'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Download className="w-3.5 h-3.5" />
                <span>CSV Data</span>
              </button>
            </div>
          </div>

          {/* Text Area Output */}
          <textarea
            readOnly
            value={getExportText()}
            rows={11}
            className="w-full bg-slate-50 text-slate-800 border border-slate-200 rounded-xl p-4 font-mono text-xs leading-relaxed focus:outline-none focus:ring-1 focus:ring-blue-500/50 resize-none shadow-inner"
          />
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-t border-slate-200 bg-slate-50/80 shrink-0">
          <span className="text-[11px] text-slate-500">
            {loas.length} records ready for copy/download.
          </span>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleDownload}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-lg transition flex items-center gap-1.5 border border-slate-200"
            >
              <Download className="w-3.5 h-3.5 text-blue-600" />
              <span>Download File</span>
            </button>

            <button
              type="button"
              onClick={handleCopy}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-lg transition shadow-sm flex items-center gap-1.5"
            >
              {isCopied ? (
                <>
                  <Check className="w-4 h-4 text-white" />
                  <span>Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copy Report</span>
                </>
              )}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
