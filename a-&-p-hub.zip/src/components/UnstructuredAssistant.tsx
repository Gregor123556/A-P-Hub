import React, { useState } from 'react';
import { Sparkles, Send, CheckCircle2, RefreshCw, Calendar, AlertTriangle, HelpCircle } from 'lucide-react';
import { AccountType, LoAEntry, LoAStatus } from '../types';
import { calculateDueDate, calculateChaseUpDate, getTodayDDMMYYYY } from '../utils/dateUtils';

interface UnstructuredAssistantProps {
  onAddLoA: (newLoa: Omit<LoAEntry, 'id' | 'createdAt'>) => void;
  onUpdateLoAStatus: (clientName: string, provider: string, newStatus: LoAStatus) => boolean;
  loas: LoAEntry[];
}

interface ParsedState {
  action: 'create' | 'update' | 'unknown';
  clientName?: string;
  accountType?: AccountType;
  currentProvider?: string;
  dateSent?: string;
  dateDue?: string;
  chaseUpDate?: string;
  policyNumber?: string;
  notes?: string;
  newStatus?: LoAStatus;
  targetClientName?: string;
  targetProvider?: string;
  explanation: string;
}

export const UnstructuredAssistant: React.FC<UnstructuredAssistantProps> = ({
  onAddLoA,
  onUpdateLoAStatus,
  loas
}) => {
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [parsedData, setParsedData] = useState<ParsedState | null>(null);
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  const presets = [
    'Sent an LoA for John Smith to Aviva for a pension today',
    'Issued LoA for Eleanor Vance - Prudential Bond sent yesterday',
    'Mark Aviva LoA for John Smith as received',
    'Mark Royal London pension LoA for Gareth & Fiona Edwards as overdue + chased',
    'Sent LoA for Michael Vance to Aegon Investment today with policy ref AEG-9912'
  ];

  const handleParse = async (textToParse: string) => {
    if (!textToParse.trim()) return;
    setIsLoading(true);
    setFeedbackMsg(null);
    setParsedData(null);

    const refDate = getTodayDDMMYYYY();

    try {
      const response = await fetch('/api/parse-loa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: textToParse, referenceDate: refDate }),
      });

      if (!response.ok) throw new Error('API request failed');

      const data = await response.json();
      
      const dateSent = data.dateSent || refDate;
      const dateDue = calculateDueDate(dateSent);
      const chaseUpDate = calculateChaseUpDate(dateSent);

      setParsedData({
        action: data.action || 'create',
        clientName: data.clientName || 'Unspecified Client',
        accountType: data.accountType || 'Pension',
        currentProvider: data.currentProvider || 'Unspecified Provider',
        dateSent,
        dateDue,
        chaseUpDate,
        policyNumber: data.policyNumber || '',
        notes: data.notes || '',
        newStatus: data.newStatus || 'Pending',
        targetClientName: data.targetClientName || data.clientName,
        targetProvider: data.targetProvider || data.currentProvider,
        explanation: data.explanation || 'Processed successfully.'
      });
    } catch (err) {
      console.error(err);
      fallbackLocalParse(textToParse, refDate);
    } finally {
      setIsLoading(false);
    }
  };

  const fallbackLocalParse = (text: string, refDate: string) => {
    const lower = text.toLowerCase();
    const isUpdate = lower.includes('mark') || lower.includes('update') || lower.includes('status') || lower.includes('received');

    if (isUpdate) {
      let status: LoAStatus = 'Pending';
      if (lower.includes('received')) status = 'Received';
      if (lower.includes('escalat') || lower.includes('chased')) status = 'Overdue + Chased';
      if (lower.includes('overdue')) status = 'Overdue';

      const matchedClient = loas.find(l => lower.includes(l.clientName.toLowerCase()))?.clientName || 'John Smith';
      const matchedProvider = loas.find(l => lower.includes(l.currentProvider.toLowerCase()))?.currentProvider || 'Aviva';

      setParsedData({
        action: 'update',
        newStatus: status,
        targetClientName: matchedClient,
        targetProvider: matchedProvider,
        explanation: `Parsed request to update status to '${status}' for ${matchedClient} (${matchedProvider}).`
      });
      return;
    }

    let accType: AccountType = 'Pension';
    if (lower.includes('investment') || lower.includes('isa')) accType = 'Investment';
    if (lower.includes('bond')) accType = 'Bond';

    let provider = 'Aviva';
    if (lower.includes('prudential') || lower.includes('pru')) provider = 'Prudential';
    if (lower.includes('royal london')) provider = 'Royal London';
    if (lower.includes('aegon')) provider = 'Aegon';
    if (lower.includes('fidelity')) provider = 'Fidelity International';

    let clientName = 'John Smith';
    const forMatch = text.match(/for\s+([A-Z][a-z]+\s+[A-Z][a-z]+)/i);
    if (forMatch) clientName = forMatch[1];

    const dateSent = refDate;
    const dateDue = calculateDueDate(dateSent);
    const chaseUpDate = calculateChaseUpDate(dateSent);

    setParsedData({
      action: 'create',
      clientName,
      accountType: accType,
      currentProvider: provider,
      dateSent,
      dateDue,
      chaseUpDate,
      policyNumber: '',
      notes: text,
      newStatus: 'Pending',
      explanation: `Parsed new LoA creation details for ${clientName} (${provider} ${accType}). Auto-calculated Due Date (+14 days) and Chase Date (+7 days).`
    });
  };

  const handleApplyAction = () => {
    if (!parsedData) return;

    if (parsedData.action === 'create') {
      onAddLoA({
        clientName: parsedData.clientName || 'Unnamed Client',
        accountType: parsedData.accountType || 'Pension',
        currentProvider: parsedData.currentProvider || 'Unknown Provider',
        dateSent: parsedData.dateSent || getTodayDDMMYYYY(),
        dateDue: parsedData.dateDue || calculateDueDate(getTodayDDMMYYYY()),
        chaseUpDate: parsedData.chaseUpDate || calculateChaseUpDate(getTodayDDMMYYYY()),
        status: parsedData.newStatus || 'Pending',
        policyNumber: parsedData.policyNumber || '',
        notes: parsedData.notes || 'Created via AI Natural Language Assistant.',
        adviserName: 'Sam Adams',
        lastChasedDate: ''
      });

      setFeedbackMsg({
        type: 'success',
        text: `Successfully added LoA for ${parsedData.clientName} (${parsedData.currentProvider} - ${parsedData.accountType}).`
      });
    } else if (parsedData.action === 'update') {
      const client = parsedData.targetClientName || '';
      const prov = parsedData.targetProvider || '';
      const status = parsedData.newStatus || 'Received';

      const success = onUpdateLoAStatus(client, prov, status);
      if (success) {
        setFeedbackMsg({
          type: 'success',
          text: `Updated LoA status to '${status}' for ${client} (${prov}).`
        });
      } else {
        setFeedbackMsg({
          type: 'error',
          text: `Could not locate matching pending LoA record for "${client}" (${prov}).`
        });
      }
    }

    setParsedData(null);
    setInputText('');
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-sm">
      {/* Title */}
      <div className="flex items-center gap-3 mb-4">
        <div className="p-2 bg-blue-50 border border-blue-100 rounded-lg text-blue-600">
          <Sparkles className="w-5 h-5" />
        </div>
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            AI Paraplanning Assistant
            <span className="text-[10px] uppercase font-bold tracking-wider text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded">
              Gemini NL Engine
            </span>
          </h2>
          <p className="text-xs text-slate-500">
            Type or click a prompt below to extract details, calculate Due (+14d) and Chase (+7d) dates, or update statuses automatically.
          </p>
        </div>
      </div>

      {/* Form Input */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleParse(inputText);
        }}
        className="space-y-3"
      >
        <div className="relative">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder='e.g., "Sent an LoA for John Smith to Aviva for a pension today" or "Mark Aviva LoA for John Smith as received"'
            className="w-full bg-slate-50 text-slate-900 border border-slate-200 rounded-lg py-3 pl-4 pr-28 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition placeholder-slate-400"
          />
          <button
            type="submit"
            disabled={isLoading || !inputText.trim()}
            className="absolute right-1.5 top-1.5 bottom-1.5 px-4 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 text-white font-medium text-xs rounded-md transition flex items-center gap-1.5 shadow-sm"
          >
            {isLoading ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-white" />
            ) : (
              <>
                <span>Parse & Run</span>
                <Send className="w-3 h-3" />
              </>
            )}
          </button>
        </div>

        {/* Quick Presets */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          <span className="text-[11px] font-medium text-slate-500 mr-1 flex items-center gap-1">
            <HelpCircle className="w-3 h-3 text-slate-400" /> Presets:
          </span>
          {presets.map((preset, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => {
                setInputText(preset);
                handleParse(preset);
              }}
              className="text-[11px] bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 px-2.5 py-1 rounded-full transition truncate max-w-[280px] sm:max-w-none text-left"
            >
              "{preset}"
            </button>
          ))}
        </div>
      </form>

      {/* Feedback Message */}
      {feedbackMsg && (
        <div
          className={`mt-4 p-3 rounded-lg border text-xs flex items-center gap-2 ${
            feedbackMsg.type === 'success'
              ? 'bg-green-50 border-green-200 text-green-800'
              : 'bg-red-50 border-red-200 text-red-800'
          }`}
        >
          {feedbackMsg.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-green-600 shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
          )}
          <span>{feedbackMsg.text}</span>
        </div>
      )}

      {/* Parsed Result Box */}
      {parsedData && (
        <div className="mt-4 p-4 bg-slate-50 border border-blue-200 rounded-xl shadow-sm text-xs space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-3">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-blue-700 bg-blue-100 px-2 py-0.5 rounded">
                AI Parsed Output
              </span>
              <h3 className="text-sm font-bold text-slate-900 mt-1">
                {parsedData.action === 'create' ? '✨ Create New LoA Entry' : '🔄 Update LoA Status'}
              </h3>
            </div>
            <p className="text-xs text-slate-600 italic bg-white px-3 py-1.5 rounded border border-slate-200">
              "{parsedData.explanation}"
            </p>
          </div>

          {parsedData.action === 'create' ? (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-2.5 bg-white rounded border border-slate-200">
                <span className="text-[10px] text-slate-400 block font-semibold uppercase">Client Name</span>
                <span className="font-bold text-slate-900">{parsedData.clientName}</span>
              </div>
              <div className="p-2.5 bg-white rounded border border-slate-200">
                <span className="text-[10px] text-slate-400 block font-semibold uppercase">Account Type</span>
                <span className="font-bold text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200 inline-block mt-0.5">
                  {parsedData.accountType}
                </span>
              </div>
              <div className="p-2.5 bg-white rounded border border-slate-200">
                <span className="text-[10px] text-slate-400 block font-semibold uppercase">Provider</span>
                <span className="font-bold text-slate-900">{parsedData.currentProvider}</span>
              </div>
              <div className="p-2.5 bg-white rounded border border-slate-200">
                <span className="text-[10px] text-slate-400 block font-semibold uppercase">Date Sent</span>
                <span className="font-semibold text-slate-700 flex items-center gap-1 font-mono">
                  <Calendar className="w-3 h-3 text-blue-600" />
                  {parsedData.dateSent}
                </span>
              </div>
              <div className="p-2.5 bg-white rounded border border-slate-200">
                <span className="text-[10px] text-amber-700 block font-semibold uppercase">Chase Date (+7d)</span>
                <span className="font-bold text-amber-800 font-mono">{parsedData.chaseUpDate}</span>
              </div>
              <div className="p-2.5 bg-white rounded border border-slate-200">
                <span className="text-[10px] text-red-700 block font-semibold uppercase">Date Due (+14d)</span>
                <span className="font-bold text-red-800 font-mono">{parsedData.dateDue}</span>
              </div>
              <div className="p-2.5 bg-white rounded border border-slate-200">
                <span className="text-[10px] text-slate-400 block font-semibold uppercase">Status</span>
                <span className="font-bold text-blue-700">Pending</span>
              </div>
              <div className="p-2.5 bg-white rounded border border-slate-200">
                <span className="text-[10px] text-slate-400 block font-semibold uppercase">Policy Ref</span>
                <span className="text-slate-700 truncate block font-mono">{parsedData.policyNumber || 'Auto-generated'}</span>
              </div>
            </div>
          ) : (
            <div className="bg-white p-3 rounded border border-slate-200 flex items-center justify-between">
              <div>
                <span className="text-slate-500 text-[11px]">Target Client & Provider:</span>
                <p className="font-bold text-slate-900 text-sm">{parsedData.targetClientName} ({parsedData.targetProvider})</p>
              </div>
              <span className="px-2.5 py-1 rounded-md font-bold uppercase text-xs bg-blue-600 text-white">
                {parsedData.newStatus}
              </span>
            </div>
          )}

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              onClick={() => setParsedData(null)}
              className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-800 transition"
            >
              Cancel
            </button>
            <button
              onClick={handleApplyAction}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium text-xs rounded-lg transition shadow-sm flex items-center gap-1.5"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Confirm & Add to Tracker</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
