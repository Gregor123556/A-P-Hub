import React, { useState } from 'react';
import { 
  Search, ChevronDown, ChevronUp, Send, Edit3, Trash2, 
  FileText, User
} from 'lucide-react';
import { AccountType, LoAEntry, LoAStatus } from '../types';
import { getLoATimingStatus } from '../utils/dateUtils';
import { normalizeServiceScope } from '../utils/currencyUtils';

interface LoATableProps {
  loas: LoAEntry[];
  onUpdateStatus: (id: string, newStatus: LoAStatus) => void;
  onEdit: (entry: LoAEntry) => void;
  onDelete: (id: string) => void;
  onGenerateChase: (entry: LoAEntry) => void;
}

export const LoATable: React.FC<LoATableProps> = ({
  loas,
  onUpdateStatus,
  onEdit,
  onDelete,
  onGenerateChase
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAccountType, setSelectedAccountType] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [selectedProvider, setSelectedProvider] = useState<string>('ALL');
  const [selectedAdvisor, setSelectedAdvisor] = useState<string>('ALL');
  const [sortField, setSortField] = useState<'dateDue' | 'chaseUpDate' | 'clientName' | 'currentProvider' | 'adviserName' | 'policyNumber'>('dateDue');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Unique list of providers for dropdown
  const providerList = Array.from(new Set(loas.map(l => l.currentProvider))).sort();

  // Filter logic
  const filteredLoas = loas.filter(item => {
    const matchesSearch =
      item.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.currentProvider.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.adviserName && item.adviserName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (item.policyNumber && item.policyNumber.toLowerCase().includes(searchTerm.toLowerCase()));

    const normalizedScope = normalizeServiceScope(item.accountType);
    const matchesAccountType = selectedAccountType === 'ALL' || normalizedScope === selectedAccountType || item.accountType === selectedAccountType;
    const matchesStatus = selectedStatus === 'ALL' || item.status === selectedStatus;
    const matchesProvider = selectedProvider === 'ALL' || item.currentProvider === selectedProvider;
    const matchesAdvisor = selectedAdvisor === 'ALL' || item.adviserName === selectedAdvisor;

    return matchesSearch && matchesAccountType && matchesStatus && matchesProvider && matchesAdvisor;
  });

  // Sort logic
  const sortedLoas = [...filteredLoas].sort((a, b) => {
    let aVal = a[sortField] || '';
    let bVal = b[sortField] || '';

    if (sortField === 'dateDue' || sortField === 'chaseUpDate') {
      const revA = aVal.split('-').reverse().join('');
      const revB = bVal.split('-').reverse().join('');
      return sortOrder === 'asc' ? revA.localeCompare(revB) : revB.localeCompare(revA);
    }

    return sortOrder === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
  });

  const toggleSort = (field: 'dateDue' | 'chaseUpDate' | 'clientName' | 'currentProvider' | 'adviserName' | 'policyNumber') => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  const toggleSelectAll = () => {
    if (selectedIds.length === sortedLoas.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(sortedLoas.map(l => l.id));
    }
  };

  const toggleSelectOne = (id: string) => {
    setSelectedIds(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleBatchStatusUpdate = (newStatus: LoAStatus) => {
    selectedIds.forEach(id => onUpdateStatus(id, newStatus));
    setSelectedIds([]);
  };

  const handleBatchDelete = () => {
    if (window.confirm(`Are you sure you want to delete ${selectedIds.length} selected record${selectedIds.length > 1 ? 's' : ''}? This action cannot be undone.`)) {
      selectedIds.forEach(id => onDelete(id));
      setSelectedIds([]);
    }
  };

  const getAccountBadge = (type: string) => {
    const scope = normalizeServiceScope(type);
    switch (scope) {
      case 'ISA & GIA':
        return 'bg-blue-50 text-blue-800 border-blue-200';
      case 'CIB':
        return 'bg-purple-50 text-purple-800 border-purple-200';
      case 'Pension':
      default:
        return 'bg-amber-50 text-amber-800 border-amber-200';
    }
  };

  const getStatusBadge = (status: LoAStatus) => {
    switch (status) {
      case 'Received':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Overdue':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Overdue + Chased':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'Pending':
      default:
        return 'bg-blue-100 text-blue-800 border-blue-200';
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden flex flex-col">
      
      {/* Control & Filter Header */}
      <div className="p-4 sm:p-5 border-b border-slate-200 bg-white space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          
          {/* Search Box */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search client, plan number, provider, or advisor..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg py-2 pl-9 pr-4 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition"
            />
          </div>

          {/* Filters */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            {/* Account Type / Scope Filter */}
            <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
              <span className="text-slate-500 font-medium">Scope:</span>
              <select
                value={selectedAccountType}
                onChange={(e) => setSelectedAccountType(e.target.value)}
                className="bg-transparent text-slate-800 focus:outline-none cursor-pointer font-medium"
              >
                <option value="ALL">All Scopes</option>
                <option value="ISA & GIA">ISA &amp; GIA</option>
                <option value="CIB">CIB</option>
                <option value="Pension">Pension</option>
              </select>
            </div>

            {/* Status Filter */}
            <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
              <span className="text-slate-500 font-medium">Status:</span>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="bg-transparent text-slate-800 focus:outline-none cursor-pointer font-medium"
              >
                <option value="ALL">All Statuses</option>
                <option value="Pending">Pending</option>
                <option value="Overdue">Overdue</option>
                <option value="Overdue + Chased">Overdue + Chased</option>
                <option value="Received">Received</option>
              </select>
            </div>

            {/* Provider Filter */}
            <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
              <span className="text-slate-500 font-medium">Provider:</span>
              <select
                value={selectedProvider}
                onChange={(e) => setSelectedProvider(e.target.value)}
                className="bg-transparent text-slate-800 focus:outline-none cursor-pointer font-medium max-w-[140px] truncate"
              >
                <option value="ALL">All Providers</option>
                {providerList.map(p => (
                  <option key={p} value={p}>{p}</option>
                ))}
              </select>
            </div>

            {/* Advisor Filter */}
            <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
              <span className="text-slate-500 font-medium">Advisor:</span>
              <select
                value={selectedAdvisor}
                onChange={(e) => setSelectedAdvisor(e.target.value)}
                className="bg-transparent text-slate-800 focus:outline-none cursor-pointer font-medium"
              >
                <option value="ALL">All Advisors</option>
                <option value="Sam Adams">Sam Adams</option>
                <option value="Anthony Poole">Anthony Poole</option>
              </select>
            </div>
          </div>
        </div>

        {/* Batch Selection Action Bar */}
        {selectedIds.length > 0 && (
          <div className="p-2.5 bg-blue-50 border border-blue-200 rounded-lg flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="text-blue-900 font-semibold px-2">
              {selectedIds.length} item{selectedIds.length > 1 ? 's' : ''} selected
            </span>
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-slate-600 font-medium">Mark Selected as:</span>
              <button
                onClick={() => handleBatchStatusUpdate('Received')}
                className="px-2.5 py-1 bg-green-600 hover:bg-green-700 text-white rounded font-medium transition"
              >
                Received
              </button>
              <button
                onClick={() => handleBatchStatusUpdate('Overdue + Chased')}
                className="px-2.5 py-1 bg-red-600 hover:bg-red-700 text-white rounded font-medium transition"
              >
                Overdue + Chased
              </button>
              <button
                onClick={() => handleBatchStatusUpdate('Pending')}
                className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded font-medium transition"
              >
                Pending
              </button>

              <div className="h-4 w-px bg-blue-200 mx-1 hidden sm:block" />

              <button
                onClick={handleBatchDelete}
                className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded font-medium transition flex items-center gap-1.5 shadow-2xs"
                title="Bulk delete selected clients"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete Selected</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Table Container */}
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-slate-200 text-left">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-4 py-3.5 w-10 text-center">
                <input
                  type="checkbox"
                  checked={selectedIds.length === sortedLoas.length && sortedLoas.length > 0}
                  onChange={toggleSelectAll}
                  className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
              </th>
              <th 
                className="px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider cursor-pointer hover:text-slate-800"
                onClick={() => toggleSort('clientName')}
              >
                <div className="flex items-center gap-1">
                  <span>Client Name</span>
                  {sortField === 'clientName' && (sortOrder === 'asc' ? <ChevronUp className="w-3.5 h-3.5 text-blue-600" /> : <ChevronDown className="w-3.5 h-3.5 text-blue-600" />)}
                </div>
              </th>
              <th 
                className="px-5 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider cursor-pointer hover:text-slate-800"
                onClick={() => toggleSort('policyNumber')}
              >
                <div className="flex items-center gap-1">
                  <span>Plan Number</span>
                  {sortField === 'policyNumber' && (sortOrder === 'asc' ? <ChevronUp className="w-3.5 h-3.5 text-blue-600" /> : <ChevronDown className="w-3.5 h-3.5 text-blue-600" />)}
                </div>
              </th>
              <th className="px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider">Type</th>
              <th 
                className="px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider cursor-pointer hover:text-slate-800"
                onClick={() => toggleSort('currentProvider')}
              >
                <div className="flex items-center gap-1">
                  <span>Provider</span>
                  {sortField === 'currentProvider' && (sortOrder === 'asc' ? <ChevronUp className="w-3.5 h-3.5 text-blue-600" /> : <ChevronDown className="w-3.5 h-3.5 text-blue-600" />)}
                </div>
              </th>
              <th 
                className="px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider cursor-pointer hover:text-slate-800"
                onClick={() => toggleSort('adviserName')}
              >
                <div className="flex items-center gap-1">
                  <span>Assigned Advisor</span>
                  {sortField === 'adviserName' && (sortOrder === 'asc' ? <ChevronUp className="w-3.5 h-3.5 text-blue-600" /> : <ChevronDown className="w-3.5 h-3.5 text-blue-600" />)}
                </div>
              </th>
              <th className="px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider">Date Sent</th>
              <th 
                className="px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider cursor-pointer hover:text-slate-800"
                onClick={() => toggleSort('chaseUpDate')}
              >
                <div className="flex items-center gap-1">
                  <span>Chase Up</span>
                  {sortField === 'chaseUpDate' && (sortOrder === 'asc' ? <ChevronUp className="w-3.5 h-3.5 text-blue-600" /> : <ChevronDown className="w-3.5 h-3.5 text-blue-600" />)}
                </div>
              </th>
              <th 
                className="px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider cursor-pointer hover:text-slate-800"
                onClick={() => toggleSort('dateDue')}
              >
                <div className="flex items-center gap-1">
                  <span>Date Due</span>
                  {sortField === 'dateDue' && (sortOrder === 'asc' ? <ChevronUp className="w-3.5 h-3.5 text-blue-600" /> : <ChevronDown className="w-3.5 h-3.5 text-blue-600" />)}
                </div>
              </th>
              <th className="px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider text-center">Status</th>
              <th className="px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-slate-200">
            {sortedLoas.length === 0 ? (
              <tr>
                <td colSpan={11} className="py-12 text-center text-slate-400">
                  <FileText className="w-8 h-8 mx-auto mb-2 opacity-40 text-slate-400" />
                  No Letter of Authority records match your search parameters.
                </td>
              </tr>
            ) : (
              sortedLoas.map((loa) => {
                const timing = getLoATimingStatus(loa.dateSent, loa.dateDue, loa.chaseUpDate, loa.status);
                const isSelected = selectedIds.includes(loa.id);

                return (
                  <tr key={loa.id} className={`hover:bg-slate-50/80 transition-colors ${isSelected ? 'bg-blue-50/40' : ''}`}>
                    {/* Select Checkbox */}
                    <td className="px-4 py-4 whitespace-nowrap text-center">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleSelectOne(loa.id)}
                        className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                      />
                    </td>

                    {/* Client Name */}
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">
                      <span className="block font-semibold text-slate-900">
                        {loa.clientName}
                      </span>
                    </td>

                    {/* Plan Number (View Only) */}
                    <td className="px-5 py-4 whitespace-nowrap text-sm">
                      {loa.policyNumber ? (
                        <span className="inline-flex items-center px-2 py-0.5 rounded bg-slate-100 border border-slate-200 text-slate-800 text-xs font-mono font-medium">
                          {loa.policyNumber}
                        </span>
                      ) : (
                        <span className="text-slate-400 text-xs font-mono italic">—</span>
                      )}
                    </td>

                    {/* Account Type */}
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">
                      <span className={`px-2 py-0.5 rounded text-xs font-semibold border ${getAccountBadge(loa.accountType)}`}>
                        {loa.accountType}
                      </span>
                    </td>

                    {/* Provider */}
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600 font-medium">
                      {loa.currentProvider}
                    </td>

                    {/* Assigned Advisor */}
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-700 font-medium">
                      <div className="flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-slate-400" />
                        <span>{loa.adviserName || 'Sam Adams'}</span>
                      </div>
                    </td>

                    {/* Date Sent */}
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600 font-mono">
                      {loa.dateSent}
                    </td>

                    {/* Chase-up Date */}
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-mono">
                      <span className={timing.isChaseDue && loa.status === 'Pending' ? 'text-amber-600 font-semibold' : 'text-slate-600'}>
                        {loa.chaseUpDate}
                      </span>
                    </td>

                    {/* Date Due */}
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-mono">
                      <div>
                        <span className={timing.isOverdue && loa.status !== 'Received' ? 'text-amber-600 font-semibold' : 'text-slate-600'}>
                          {loa.dateDue}
                        </span>
                        {loa.status !== 'Received' && (
                          <span className={`block text-[11px] font-sans ${timing.isOverdue ? 'text-red-600 font-medium' : 'text-slate-400'}`}>
                            {timing.label}
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Status Dropdown Pill */}
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <select
                        value={loa.status}
                        onChange={(e) => onUpdateStatus(loa.id, e.target.value as LoAStatus)}
                        className={`px-2.5 py-1 text-xs font-semibold rounded-full border cursor-pointer focus:outline-none transition ${getStatusBadge(loa.status)}`}
                      >
                        <option value="Pending" className="bg-white text-blue-800">Pending</option>
                        <option value="Received" className="bg-white text-green-800">Received</option>
                        <option value="Overdue" className="bg-white text-amber-800">Overdue</option>
                        <option value="Overdue + Chased" className="bg-white text-red-800">Overdue + Chased</option>
                      </select>
                    </td>

                    {/* Actions */}
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm">
                      <div className="flex items-center justify-end gap-1.5">
                        {loa.status !== 'Received' && (
                          <button
                            onClick={() => onGenerateChase(loa)}
                            className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition"
                            title="Draft Provider Chase Letter"
                          >
                            <Send className="w-4 h-4" />
                          </button>
                        )}
                        <button
                          onClick={() => onEdit(loa)}
                          className="p-1.5 text-slate-500 hover:bg-slate-100 rounded-lg transition"
                          title="Edit Record"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onDelete(loa.id)}
                          className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition"
                          title="Delete Record"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Footer Info */}
      <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-between items-center text-xs text-slate-500 font-medium">
        <span>Showing {sortedLoas.length} of {loas.length} records</span>
        <span>Adams &amp; Poole Financial Services</span>
      </div>
    </div>
  );
};
