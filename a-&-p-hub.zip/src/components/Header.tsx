import React from 'react';
import { ShieldCheck, Calendar, FileSpreadsheet, PlusCircle, AlertCircle, Sparkles } from 'lucide-react';
import { LoAEntry } from '../types';
import { AdamsPooleLogo } from './AdamsPooleLogo';

interface HeaderProps {
  loas: LoAEntry[];
  onOpenNewModal: () => void;
  onOpenExportModal: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  loas,
  onOpenNewModal,
  onOpenExportModal,
  activeTab,
  setActiveTab
}) => {
  const totalCount = loas.length;
  const overdueCount = loas.filter(l => l.status === 'Overdue').length;
  const pendingCount = loas.filter(l => l.status === 'Pending').length;
  const overdueChasedCount = loas.filter(l => l.status === 'Overdue + Chased').length;
  const receivedCount = loas.filter(l => l.status === 'Received').length;
  const receivedPct = totalCount > 0 ? Math.round((receivedCount / totalCount) * 100) : 0;

  return (
    <header className="bg-slate-900 text-slate-100 border-b border-slate-800 sticky top-0 z-30 shadow-md">
      {/* Top Adams and Poole Financial Services Practice Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-col md:flex-row md:items-center justify-between gap-4">
        
        {/* Brand & Firm Context */}
        <div className="flex items-center gap-3.5">
          <AdamsPooleLogo size={46} />
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-bold uppercase tracking-wider text-[#c5a468] bg-[#0b291d] px-2.5 py-0.5 rounded border border-[#c5a468]/40">
                Adams and Poole Financial Services
              </span>
              <span className="text-xs text-slate-400 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                Ref Date: 14 Aug 2026
              </span>
            </div>
            <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2 mt-0.5">
              Paraplanning LoA Hub
              <span className="text-xs font-normal text-slate-400 bg-slate-800 px-2 py-0.5 rounded-full border border-slate-700">
                Live Cloud Sync
              </span>
            </h1>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={onOpenExportModal}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 transition shadow-sm"
            title="Generate Markdown or CSV Reports"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span className="hidden sm:inline">Export Summary / MD</span>
            <span className="sm:hidden">Export</span>
          </button>

          <button
            onClick={onOpenNewModal}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition shadow-sm border border-emerald-500"
          >
            <PlusCircle className="w-4 h-4" />
            <span>New LoA Record</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <div className="bg-slate-950/70 border-t border-slate-800/80 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex items-center justify-between overflow-x-auto no-scrollbar">
          <nav className="flex space-x-1 sm:space-x-2 py-2">
            <button
              onClick={() => setActiveTab('tracker')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'tracker'
                  ? 'bg-blue-600 text-white font-semibold shadow'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <span>📋 LoA Dashboard</span>
              <span className="ml-1 bg-slate-900/60 px-1.5 py-0.5 rounded-full text-[10px]">
                {totalCount}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('analytics')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'analytics'
                  ? 'bg-blue-600 text-white font-semibold shadow'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <span>🏢 Provider Directory</span>
            </button>
          </nav>

          {/* Metric Summary Ticker */}
          <div className="hidden lg:flex items-center gap-4 text-xs py-2 text-slate-400 border-l border-slate-800 pl-4">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-amber-400"></span>
              Pending: <strong className="text-slate-200">{pendingCount}</strong>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-rose-500"></span>
              Overdue: <strong className="text-rose-400">{overdueCount}</strong>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-purple-400"></span>
              Overdue + Chased: <strong className="text-purple-300">{overdueChasedCount}</strong>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              Completed: <strong className="text-emerald-300">{receivedPct}%</strong>
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};
