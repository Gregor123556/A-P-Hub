import React, { useState } from 'react';
import {
  Search,
  CheckSquare,
  Square,
  Calendar,
  User,
  Trash2,
  Edit3,
  Mail,
  PhoneCall,
  Clock,
  Sparkles,
  Layers,
  FileCheck,
  AlertCircle,
  Plus,
  X,
  TrendingUp,
  CheckCircle2,
  CalendarCheck,
  CalendarClock
} from 'lucide-react';
import { ServicingClient } from '../types';
import { updateServicingClient, deleteServicingClient } from '../services/servicingService';
import { formatPrettyDate, parseDDMMYYYY, formatDDMMYYYY, calculateServicingDates, getTodayDDMMYYYY } from '../utils/dateUtils';
import { formatPoundSterling, normalizeServiceScope } from '../utils/currencyUtils';

interface ServicingDashboardProps {
  servicingClients: ServicingClient[];
  onRefresh?: () => void;
  onNavigateToClientAdmin?: () => void;
}

export const ServicingDashboard: React.FC<ServicingDashboardProps> = ({
  servicingClients,
  onNavigateToClientAdmin
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAdviser, setSelectedAdviser] = useState<string>('ALL');
  const [selectedScope, setSelectedScope] = useState<string>('ALL');
  const [filterEmailStatus, setFilterEmailStatus] = useState<string>('ALL');

  // Edit / Date Customization Modal
  const [editingClient, setEditingClient] = useState<ServicingClient | null>(null);
  const [editStartDate, setEditStartDate] = useState('');
  const [editWelcomeCallDue, setEditWelcomeCallDue] = useState('');
  const [editSixMonthDue, setEditSixMonthDue] = useState('');
  const [editOneYearDue, setEditOneYearDue] = useState('');
  const [editNotes, setEditNotes] = useState('');

  // Delete confirmation
  const [deleteModal, setDeleteModal] = useState<{
    isOpen: boolean;
    id: string;
    name: string;
  }>({
    isOpen: false,
    id: '',
    name: ''
  });

  const handleOpenEdit = (client: ServicingClient) => {
    setEditingClient(client);
    setEditStartDate(client.servicingStartDate);
    setEditWelcomeCallDue(client.welcomeCallDueDate);
    setEditSixMonthDue(client.sixMonthReviewDueDate);
    setEditOneYearDue(client.oneYearReviewDueDate);
    setEditNotes(client.notes || '');
  };

  const handleStartDateChange = (newDateStr: string) => {
    setEditStartDate(newDateStr);
    const calculated = calculateServicingDates(newDateStr);
    setEditWelcomeCallDue(calculated.welcomeCallDueDate);
    setEditSixMonthDue(calculated.sixMonthReviewDueDate);
    setEditOneYearDue(calculated.oneYearReviewDueDate);
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingClient) return;

    await updateServicingClient(editingClient.id, {
      servicingStartDate: editStartDate,
      welcomeCallDueDate: editWelcomeCallDue,
      sixMonthReviewDueDate: editSixMonthDue,
      oneYearReviewDueDate: editOneYearDue,
      notes: editNotes
    });

    setEditingClient(null);
  };

  const handleToggleWelcomeEmail = async (client: ServicingClient) => {
    const nextVal = !client.welcomeEmailSent;
    const todayStr = getTodayDDMMYYYY();
    await updateServicingClient(client.id, {
      welcomeEmailSent: nextVal,
      welcomeEmailSentDate: nextVal ? todayStr : ''
    });
  };

  const handleToggleWelcomeCall = async (client: ServicingClient) => {
    const nextVal = !client.welcomeCallCompleted;
    const todayStr = getTodayDDMMYYYY();
    await updateServicingClient(client.id, {
      welcomeCallCompleted: nextVal,
      welcomeCallCompletedDate: nextVal ? todayStr : ''
    });
  };

  const handleToggleSixMonthReview = async (client: ServicingClient) => {
    const nextVal = !client.sixMonthReviewCompleted;
    const todayStr = getTodayDDMMYYYY();
    await updateServicingClient(client.id, {
      sixMonthReviewCompleted: nextVal,
      sixMonthReviewCompletedDate: nextVal ? todayStr : ''
    });
  };

  const handleToggleOneYearReview = async (client: ServicingClient) => {
    const nextVal = !client.oneYearReviewCompleted;
    const todayStr = getTodayDDMMYYYY();
    await updateServicingClient(client.id, {
      oneYearReviewCompleted: nextVal,
      oneYearReviewCompletedDate: nextVal ? todayStr : ''
    });
  };

  const handleConfirmDelete = async () => {
    if (deleteModal.id) {
      await deleteServicingClient(deleteModal.id);
    }
    setDeleteModal({ isOpen: false, id: '', name: '' });
  };

  // Helper for Overdue / Timing calculation
  const getDateStatus = (dueDateStr: string, isCompleted?: boolean) => {
    if (isCompleted) {
      return { isOverdue: false, isDueSoon: false, text: 'Completed', badgeClass: 'bg-emerald-50 text-emerald-700 border-emerald-200' };
    }
    const d = parseDDMMYYYY(dueDateStr);
    if (!d) return { isOverdue: false, isDueSoon: false, text: dueDateStr || 'Not Set', badgeClass: 'text-slate-600 bg-slate-50 border-slate-200' };

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dueTime = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
    const diffDays = Math.round((dueTime - today.getTime()) / (1000 * 60 * 60 * 24));

    if (diffDays < 0) {
      return { 
        isOverdue: true, 
        isDueSoon: false, 
        text: `${Math.abs(diffDays)}d overdue (${dueDateStr})`, 
        badgeClass: 'bg-rose-50 text-rose-700 border-rose-200 font-semibold' 
      };
    }
    if (diffDays <= 7) {
      return { 
        isOverdue: false, 
        isDueSoon: true, 
        text: diffDays === 0 ? `Due Today (${dueDateStr})` : `Due in ${diffDays}d (${dueDateStr})`, 
        badgeClass: 'bg-amber-50 text-amber-800 border-amber-200 font-semibold' 
      };
    }
    return { 
      isOverdue: false, 
      isDueSoon: false, 
      text: dueDateStr, 
      badgeClass: 'bg-slate-50 text-slate-700 border-slate-200' 
    };
  };

  // Filtering
  const filtered = servicingClients.filter(c => {
    const term = searchTerm.toLowerCase();
    const matchesSearch =
      c.clientName.toLowerCase().includes(term) ||
      (c.adviserName && c.adviserName.toLowerCase().includes(term)) ||
      (c.serviceType && c.serviceType.toLowerCase().includes(term)) ||
      (c.notes && c.notes.toLowerCase().includes(term));

    const matchesAdviser = selectedAdviser === 'ALL' || c.adviserName === selectedAdviser;
    const matchesScope = selectedScope === 'ALL' || normalizeServiceScope(c.serviceType) === selectedScope;
    const matchesEmail =
      filterEmailStatus === 'ALL' ||
      (filterEmailStatus === 'SENT' && c.welcomeEmailSent) ||
      (filterEmailStatus === 'PENDING' && !c.welcomeEmailSent);

    return matchesSearch && matchesAdviser && matchesScope && matchesEmail;
  });

  const totalClients = servicingClients.length;
  const emailsSentCount = servicingClients.filter(c => c.welcomeEmailSent).length;
  const emailsPendingCount = totalClients - emailsSentCount;

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      
      {/* Top Banner & Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        
        {/* Total Active Servicing */}
        <div className="p-4 rounded-xl border border-blue-200 bg-blue-50/70 shadow-2xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-600 ring-4 ring-blue-100" />
              <p className="text-xs font-bold text-blue-950 uppercase tracking-wider">Active Servicing Clients</p>
            </div>
            <span className="p-1.5 rounded-lg bg-blue-200 text-blue-900 font-bold">
              <Layers className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900">{totalClients}</span>
            <span className="text-xs text-slate-500 font-medium">Completed Onboarding Pipeline</span>
          </div>
          <p className="text-xs text-slate-600 mt-1">
            Clients transitioned automatically upon finishing all Ongoing administrative stages.
          </p>
        </div>

        {/* Welcome Email Status */}
        <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/70 shadow-2xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 ring-4 ring-emerald-100" />
              <p className="text-xs font-bold text-emerald-950 uppercase tracking-wider">Welcome Email Dispatched</p>
            </div>
            <span className="p-1.5 rounded-lg bg-emerald-200 text-emerald-900 font-bold">
              <Mail className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-emerald-900">{emailsSentCount}</span>
            <span className="text-xs text-emerald-700 font-medium">of {totalClients} Sent</span>
          </div>
          <p className="text-xs text-emerald-800 mt-1">
            {emailsPendingCount > 0 
              ? `${emailsPendingCount} client${emailsPendingCount > 1 ? 's' : ''} awaiting welcome email dispatch.` 
              : 'All servicing welcome emails have been dispatched.'}
          </p>
        </div>

        {/* Reviews Schedule */}
        <div className="p-4 rounded-xl border border-purple-200 bg-purple-50/70 shadow-2xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-purple-600 ring-4 ring-purple-100" />
              <p className="text-xs font-bold text-purple-950 uppercase tracking-wider">Annual Review Pipeline</p>
            </div>
            <span className="p-1.5 rounded-lg bg-purple-200 text-purple-900 font-bold">
              <CalendarClock className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-purple-950">6m &amp; 1yr</span>
            <span className="text-xs text-purple-800 font-medium">Automatic SLA Tracking</span>
          </div>
          <p className="text-xs text-purple-800 mt-1">
            Welcome Call (1 week), 6-Month Review, and 1-Year Review dates auto-computed.
          </p>
        </div>

      </div>

      {/* Main Servicing Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden flex flex-col">
        
        {/* Search & Filter Bar */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-white space-y-4">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search servicing clients by name, adviser, or notes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg py-2 pl-9 pr-4 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition"
              />
            </div>

            {/* Filters */}
            <div className="flex flex-wrap items-center gap-2 text-xs">
              
              {/* Welcome Email Filter */}
              <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
                <span className="text-slate-500 font-medium">Welcome Email:</span>
                <select
                  value={filterEmailStatus}
                  onChange={(e) => setFilterEmailStatus(e.target.value)}
                  className="bg-transparent text-slate-800 focus:outline-none cursor-pointer font-medium"
                >
                  <option value="ALL">All ({totalClients})</option>
                  <option value="SENT">Sent ({emailsSentCount})</option>
                  <option value="PENDING">Pending ({emailsPendingCount})</option>
                </select>
              </div>

              {/* Adviser Filter */}
              <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
                <span className="text-slate-500 font-medium">Adviser:</span>
                <select
                  value={selectedAdviser}
                  onChange={(e) => setSelectedAdviser(e.target.value)}
                  className="bg-transparent text-slate-800 focus:outline-none cursor-pointer font-medium"
                >
                  <option value="ALL">All Advisers</option>
                  <option value="Sam Adams">Sam Adams</option>
                  <option value="Anthony Poole">Anthony Poole</option>
                </select>
              </div>

              {/* Scope Filter */}
              <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
                <span className="text-slate-500 font-medium">Scope:</span>
                <select
                  value={selectedScope}
                  onChange={(e) => setSelectedScope(e.target.value)}
                  className="bg-transparent text-slate-800 focus:outline-none cursor-pointer font-medium"
                >
                  <option value="ALL">All Scopes</option>
                  <option value="Pension">Pension</option>
                  <option value="ISA & GIA">ISA &amp; GIA</option>
                  <option value="CIB">CIB</option>
                </select>
              </div>

            </div>
          </div>
        </div>

        {/* Table Content */}
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200 text-left">
            <thead className="bg-slate-50">
              <tr>
                {/* Client Name */}
                <th className="px-5 py-3.5 text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  Client Name
                </th>

                {/* Servicing Start Date */}
                <th className="px-4 py-3.5 text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  Servicing Start Date
                </th>

                {/* Welcome Email Sent? */}
                <th className="px-4 py-3.5 text-xs font-semibold text-slate-600 uppercase tracking-wider text-center">
                  Welcome Email Sent?
                </th>

                {/* Welcome Call Due Date (1 week after start) */}
                <th className="px-4 py-3.5 text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  Welcome Call Due Date
                </th>

                {/* 6 Month Review Due Date (6 months after start) */}
                <th className="px-4 py-3.5 text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  6 Month Review Due Date
                </th>

                {/* 1 Year Review Due Date (6 months after 6 month / 1 year after start) */}
                <th className="px-4 py-3.5 text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  1 Year Review Due Date
                </th>

                {/* Actions */}
                <th className="px-5 py-3.5 text-xs font-semibold text-slate-600 uppercase tracking-wider text-right">
                  Actions
                </th>
              </tr>
            </thead>

            <tbody className="bg-white divide-y divide-slate-200">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    <Layers className="w-8 h-8 mx-auto mb-2 opacity-40 text-slate-400" />
                    <p className="font-medium text-slate-600">No clients currently in the Servicing pipeline.</p>
                    <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                      Clients automatically feed into Servicing once all 9 administrative stages in the <strong>Ongoing Clients</strong> section are completed.
                    </p>
                    {onNavigateToClientAdmin && (
                      <button
                        onClick={onNavigateToClientAdmin}
                        className="mt-3 px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium text-xs transition inline-flex items-center gap-1.5 shadow-2xs"
                      >
                        <FileCheck className="w-3.5 h-3.5" />
                        <span>Go to Client Admin Checklist</span>
                      </button>
                    )}
                  </td>
                </tr>
              ) : (
                filtered.map((client) => {
                  const welcomeCallStatus = getDateStatus(client.welcomeCallDueDate, client.welcomeCallCompleted);
                  const sixMonthStatus = getDateStatus(client.sixMonthReviewDueDate, client.sixMonthReviewCompleted);
                  const oneYearStatus = getDateStatus(client.oneYearReviewDueDate, client.oneYearReviewCompleted);

                  return (
                    <tr key={client.id} className="hover:bg-slate-50/80 transition-colors">
                      
                      {/* 1. Client Name */}
                      <td className="px-5 py-4 whitespace-nowrap">
                        <div className="flex flex-col">
                          <span 
                            className="font-semibold text-slate-900 text-sm hover:text-blue-600 cursor-pointer"
                            onClick={() => handleOpenEdit(client)}
                          >
                            {client.clientName}
                          </span>
                          <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                            {client.serviceType && (
                              <span className="font-medium text-slate-600">{normalizeServiceScope(client.serviceType)}</span>
                            )}
                            {client.adviserName && (
                              <>
                                <span>•</span>
                                <span>Adviser: {client.adviserName}</span>
                              </>
                            )}
                            {client.estimatedValue && (
                              <>
                                <span>•</span>
                                <span className="font-mono text-slate-700 font-medium">{formatPoundSterling(client.estimatedValue)}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* 2. Servicing Start Date */}
                      <td className="px-4 py-4 whitespace-nowrap">
                        <div className="flex items-center gap-1.5 text-xs text-slate-800 font-mono font-medium bg-slate-50 px-2.5 py-1 rounded-md border border-slate-200 w-fit">
                          <Calendar className="w-3.5 h-3.5 text-slate-500" />
                          <span>{client.servicingStartDate || '—'}</span>
                        </div>
                      </td>

                      {/* 3. Welcome Email Sent? (Checkbox) */}
                      <td className="px-4 py-4 whitespace-nowrap text-center">
                        <button
                          type="button"
                          onClick={() => handleToggleWelcomeEmail(client)}
                          className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border transition cursor-pointer ${
                            client.welcomeEmailSent
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                              : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
                          }`}
                          title="Click to toggle Welcome Email Sent status"
                        >
                          {client.welcomeEmailSent ? (
                            <>
                              <CheckSquare className="w-4 h-4 text-emerald-600" />
                              <span>Sent</span>
                            </>
                          ) : (
                            <>
                              <Square className="w-4 h-4 text-slate-400" />
                              <span>Pending</span>
                            </>
                          )}
                        </button>
                        {client.welcomeEmailSentDate && (
                          <div className="text-[10px] text-emerald-700 font-mono mt-0.5">
                            {client.welcomeEmailSentDate}
                          </div>
                        )}
                      </td>

                      {/* 4. Welcome Call Due Date (1 week after start) */}
                      <td className="px-4 py-4 whitespace-nowrap">
                        <div className="flex flex-col gap-1">
                          <div className={`flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-md border font-mono w-fit ${welcomeCallStatus.badgeClass}`}>
                            <PhoneCall className="w-3.5 h-3.5 shrink-0" />
                            <span>{client.welcomeCallDueDate || '—'}</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleToggleWelcomeCall(client)}
                            className="text-[10px] text-slate-500 hover:text-blue-600 flex items-center gap-1 text-left"
                          >
                            {client.welcomeCallCompleted ? (
                              <span className="text-emerald-700 font-semibold flex items-center gap-0.5">
                                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                Call Completed ({client.welcomeCallCompletedDate || 'Done'})
                              </span>
                            ) : (
                              <span className="text-slate-500 hover:underline">Mark call complete</span>
                            )}
                          </button>
                        </div>
                      </td>

                      {/* 5. 6 Month Review Due Date (6 months after start) */}
                      <td className="px-4 py-4 whitespace-nowrap">
                        <div className="flex flex-col gap-1">
                          <div className={`flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-md border font-mono w-fit ${sixMonthStatus.badgeClass}`}>
                            <CalendarCheck className="w-3.5 h-3.5 shrink-0" />
                            <span>{client.sixMonthReviewDueDate || '—'}</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleToggleSixMonthReview(client)}
                            className="text-[10px] text-slate-500 hover:text-blue-600 flex items-center gap-1 text-left"
                          >
                            {client.sixMonthReviewCompleted ? (
                              <span className="text-emerald-700 font-semibold flex items-center gap-0.5">
                                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                Review Completed ({client.sixMonthReviewCompletedDate || 'Done'})
                              </span>
                            ) : (
                              <span className="text-slate-500 hover:underline">Mark review complete</span>
                            )}
                          </button>
                        </div>
                      </td>

                      {/* 6. 1 Year Review Due Date (6 months after 6 month / 1 year after start) */}
                      <td className="px-4 py-4 whitespace-nowrap">
                        <div className="flex flex-col gap-1">
                          <div className={`flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-md border font-mono w-fit ${oneYearStatus.badgeClass}`}>
                            <CalendarClock className="w-3.5 h-3.5 shrink-0" />
                            <span>{client.oneYearReviewDueDate || '—'}</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleToggleOneYearReview(client)}
                            className="text-[10px] text-slate-500 hover:text-blue-600 flex items-center gap-1 text-left"
                          >
                            {client.oneYearReviewCompleted ? (
                              <span className="text-emerald-700 font-semibold flex items-center gap-0.5">
                                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                Annual Review Completed ({client.oneYearReviewCompletedDate || 'Done'})
                              </span>
                            ) : (
                              <span className="text-slate-500 hover:underline">Mark review complete</span>
                            )}
                          </button>
                        </div>
                      </td>

                      {/* 7. Actions */}
                      <td className="px-5 py-4 whitespace-nowrap text-right text-sm">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleOpenEdit(client)}
                            className="p-1.5 text-slate-500 hover:bg-slate-100 rounded-lg transition"
                            title="Edit Dates / Notes"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setDeleteModal({
                              isOpen: true,
                              id: client.id,
                              name: client.clientName
                            })}
                            className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition"
                            title="Delete Servicing Entry"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>

                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Footer Info */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row justify-between items-center gap-2 text-xs text-slate-500 font-medium">
          <span>
            Showing {filtered.length} of {totalClients} servicing client records
          </span>
          <span>Adams &amp; Poole Financial Services • Ongoing Servicing &amp; Reviews</span>
        </div>

      </div>

      {/* Edit Dates & Notes Modal */}
      {editingClient && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Edit Servicing Record
                </h3>
                <p className="text-xs text-slate-500">{editingClient.clientName}</p>
              </div>
              <button
                onClick={() => setEditingClient(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="mt-4 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Servicing Start Date (DD-MM-YYYY)
                </label>
                <input
                  type="text"
                  required
                  value={editStartDate}
                  onChange={(e) => handleStartDateChange(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="DD-MM-YYYY"
                />
                <span className="text-[11px] text-slate-400 mt-0.5 block">
                  Changing the start date auto-recalculates due dates (+1 week, +6 months, +1 year).
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Welcome Call Due
                  </label>
                  <input
                    type="text"
                    value={editWelcomeCallDue}
                    onChange={(e) => setEditWelcomeCallDue(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="DD-MM-YYYY"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    6 Month Due
                  </label>
                  <input
                    type="text"
                    value={editSixMonthDue}
                    onChange={(e) => setEditSixMonthDue(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="DD-MM-YYYY"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    1 Year Due
                  </label>
                  <input
                    type="text"
                    value={editOneYearDue}
                    onChange={(e) => setEditOneYearDue(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="DD-MM-YYYY"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Notes &amp; Servicing Instructions
                </label>
                <textarea
                  rows={3}
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Add any specific servicing notes or review preferences..."
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingClient(null)}
                  className="px-4 py-2 bg-white border border-slate-200 rounded-lg text-slate-700 font-medium hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium shadow-xs"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150">
            <div className="flex items-start gap-3.5">
              <div className="p-3 bg-rose-100 text-rose-600 rounded-full shrink-0">
                <Trash2 className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-slate-900">
                  Delete Servicing Record?
                </h3>
                <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                  Are you sure you want to remove <strong className="text-slate-900">{deleteModal.name}</strong> from active Servicing tracking?
                </p>
              </div>
            </div>

            <div className="mt-6 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setDeleteModal({ isOpen: false, id: '', name: '' })}
                className="px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 border border-slate-300 rounded-lg transition"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg transition shadow-xs"
              >
                Delete Record
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
