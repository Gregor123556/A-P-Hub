import React from 'react';
import { ShieldCheck, Clock, AlertTriangle, CheckCircle2, Building2, PieChart } from 'lucide-react';
import { LoAEntry } from '../types';
import { PROVIDER_CONTACTS } from '../data/mockData';

interface AnalyticsDashboardProps {
  loas: LoAEntry[];
}

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({ loas }) => {
  const total = loas.length;
  const pending = loas.filter(l => l.status === 'Pending').length;
  const overdue = loas.filter(l => l.status === 'Overdue').length;
  const overdueChased = loas.filter(l => l.status === 'Overdue + Chased').length;
  const received = loas.filter(l => l.status === 'Received').length;

  const pensions = loas.filter(l => l.accountType === 'Pension').length;
  const investments = loas.filter(l => l.accountType === 'Investment').length;
  const bonds = loas.filter(l => l.accountType === 'Bond').length;

  // Provider breakdown
  const providerStats: Record<string, { total: number; overdue: number; received: number }> = {};
  loas.forEach(l => {
    if (!providerStats[l.currentProvider]) {
      providerStats[l.currentProvider] = { total: 0, overdue: 0, received: 0 };
    }
    providerStats[l.currentProvider].total += 1;
    if (l.status === 'Overdue' || l.status === 'Overdue + Chased') providerStats[l.currentProvider].overdue += 1;
    if (l.status === 'Received') providerStats[l.currentProvider].received += 1;
  });

  return (
    <div className="space-y-6">
      
      {/* Top Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        
        <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1 block">
              Total Active LoAs
            </span>
            <h3 className="text-3xl font-bold text-slate-900">{total}</h3>
            <span className="text-xs text-slate-500">Across Portfolio</span>
          </div>
          <div className="p-3 bg-blue-50 border border-blue-100 rounded-xl text-blue-600">
            <ShieldCheck className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-sm border-l-4 border-l-amber-500 flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1 block">
              Pending & Chasing
            </span>
            <h3 className="text-3xl font-bold text-amber-600">{pending}</h3>
            <span className="text-xs text-slate-500">Standard 14d SLA</span>
          </div>
          <div className="p-3 bg-amber-50 border border-amber-100 rounded-xl text-amber-600">
            <Clock className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-sm border-l-4 border-l-red-500 flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1 block">
              Overdue & Chased
            </span>
            <h3 className="text-3xl font-bold text-red-600">{overdue + overdueChased}</h3>
            <span className="text-xs text-red-500 font-medium">Exceeds 14d SLA limit</span>
          </div>
          <div className="p-3 bg-red-50 border border-red-100 rounded-xl text-red-600">
            <AlertTriangle className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-sm border-l-4 border-l-green-500 flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1 block">
              SLA Completion Rate
            </span>
            <h3 className="text-3xl font-bold text-green-600">
              {total > 0 ? Math.round((received / total) * 100) : 0}%
            </h3>
            <span className="text-xs text-slate-500">{received} completed</span>
          </div>
          <div className="p-3 bg-green-50 border border-green-100 rounded-xl text-green-600">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>

      </div>

      {/* Main Analytics Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Account Type Distribution */}
        <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-sm">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 mb-4">
            <PieChart className="w-4 h-4 text-blue-600" />
            LoA Volume by Account Type
          </h3>

          <div className="space-y-4 text-xs">
            {/* Pension */}
            <div>
              <div className="flex justify-between text-slate-700 mb-1 font-semibold">
                <span>Pension ({pensions})</span>
                <span>{total > 0 ? Math.round((pensions / total) * 100) : 0}%</span>
              </div>
              <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                <div
                  className="h-full bg-amber-500 rounded-full transition-all duration-500"
                  style={{ width: `${total > 0 ? (pensions / total) * 100 : 0}%` }}
                ></div>
              </div>
            </div>

            {/* Investment */}
            <div>
              <div className="flex justify-between text-slate-700 mb-1 font-semibold">
                <span>Investment ({investments})</span>
                <span>{total > 0 ? Math.round((investments / total) * 100) : 0}%</span>
              </div>
              <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                <div
                  className="h-full bg-blue-600 rounded-full transition-all duration-500"
                  style={{ width: `${total > 0 ? (investments / total) * 100 : 0}%` }}
                ></div>
              </div>
            </div>

            {/* Bond */}
            <div>
              <div className="flex justify-between text-slate-700 mb-1 font-semibold">
                <span>Bond ({bonds})</span>
                <span>{total > 0 ? Math.round((bonds / total) * 100) : 0}%</span>
              </div>
              <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                <div
                  className="h-full bg-purple-600 rounded-full transition-all duration-500"
                  style={{ width: `${total > 0 ? (bonds / total) * 100 : 0}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>

        {/* Provider Matrix */}
        <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-sm">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 mb-4">
            <Building2 className="w-4 h-4 text-blue-600" />
            Provider Turnaround & Bottleneck Matrix
          </h3>

          <div className="overflow-y-auto max-h-56 pr-1 space-y-2 text-xs">
            {Object.entries(providerStats).map(([provider, stats]) => {
              const contact = PROVIDER_CONTACTS[provider];
              return (
                <div key={provider} className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-slate-900">{provider}</span>
                    <span className="block text-[11px] text-slate-500">
                      SLA Target: {contact?.avgTurnaroundDays || 14} days average
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-xs text-slate-600">
                      Total: <strong className="text-slate-900">{stats.total}</strong>
                    </span>
                    {stats.overdue > 0 && (
                      <span className="px-2 py-0.5 rounded font-semibold text-xs bg-red-100 text-red-800 border border-red-200">
                        {stats.overdue} Overdue
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>

    </div>
  );
};
