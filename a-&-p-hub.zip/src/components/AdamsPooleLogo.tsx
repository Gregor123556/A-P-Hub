import React from 'react';

interface AdamsPooleLogoProps {
  className?: string;
  size?: number;
  showText?: boolean;
}

export const AdamsPooleLogo: React.FC<AdamsPooleLogoProps> = ({
  className = '',
  size = 40,
  showText = false
}) => {
  return (
    <div className={`inline-flex items-center gap-3 ${className}`}>
      {/* Precision Vector Emblem matching uploaded brand identity */}
      <svg
        width={size}
        height={size}
        viewBox="0 0 300 300"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0 drop-shadow-sm select-none"
      >
        {/* Background Deep Forest Green Circle */}
        <circle cx="150" cy="150" r="148" fill="#0b291d" />

        {/* Double Concentric Gold Rings */}
        <circle
          cx="150"
          cy="150"
          r="138"
          stroke="#c5a468"
          strokeWidth="3.5"
          fill="none"
        />
        <circle
          cx="150"
          cy="150"
          r="128"
          stroke="#c5a468"
          strokeWidth="2.5"
          fill="none"
        />

        {/* Skyline & Tree Architectural Line Artwork in Gold */}
        <g stroke="#c5a468" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" fill="none">
          {/* Baseline Ground Line */}
          <line x1="38" y1="156" x2="262" y2="156" />

          {/* Left Tree */}
          {/* Tree trunk */}
          <line x1="92" y1="156" x2="92" y2="132" />
          {/* Tree foliage clouds */}
          <path d="M92 132 C82 132 76 126 76 118 C76 110 82 106 88 106 C88 98 94 92 102 92 C110 92 116 97 117 104 C122 104 126 109 126 116 C126 123 120 128 114 129 C114 132 108 132 104 132 Z" />
          <line x1="92" y1="120" x2="92" y2="108" />

          {/* Building 1 (Left-Center Arch / Mid Tower) */}
          <path d="M120 156 L120 126 C120 114 134 114 134 126 L134 156" />

          {/* Building 2 (Center Skyscraper / Tower with Stepped Top) */}
          <path d="M140 156 L140 102 L150 102 L150 90 L168 90 L168 102 L178 102 L178 156" />
          {/* Center skyscraper window detail lines */}
          <line x1="159" y1="98" x2="159" y2="156" strokeWidth="1.5" strokeOpacity="0.6" />

          {/* Building 3 (Right Tower Section) */}
          <path d="M178 156 L178 112 L192 112 L192 156" />

          {/* Building 4 (Right Residential House with Pitched Gable Roof) */}
          <path d="M192 156 L192 136 L218 118 L244 136 L244 156" />
        </g>

        {/* Brand Text inside circular badge */}
        {/* Main Title: ADAMS & POOLE */}
        <text
          x="150"
          y="188"
          textAnchor="middle"
          fill="#FFFFFF"
          fontFamily="'Plus Jakarta Sans', system-ui, -apple-system, sans-serif"
          fontWeight="800"
          fontSize="17.5"
          letterSpacing="2.8"
        >
          ADAMS &amp; POOLE
        </text>

        {/* Subtitle: FINANCIAL SERVICES */}
        <text
          x="150"
          y="208"
          textAnchor="middle"
          fill="#c5a468"
          fontFamily="'Plus Jakarta Sans', system-ui, -apple-system, sans-serif"
          fontWeight="700"
          fontSize="10"
          letterSpacing="3.5"
        >
          FINANCIAL SERVICES
        </text>
      </svg>

      {/* Optional Side Text lockup */}
      {showText && (
        <div className="flex flex-col">
          <span className="font-bold text-slate-900 leading-tight tracking-tight text-base">
            Adams &amp; Poole
          </span>
          <span className="text-[11px] font-semibold tracking-widest text-[#9d7d40] uppercase">
            Financial Services
          </span>
        </div>
      )}
    </div>
  );
};
