import React, { useState } from 'react';
import { 
  Building2, 
  Mail, 
  Phone, 
  MapPin, 
  Search, 
  Copy, 
  Check, 
  ChevronUp, 
  ChevronDown, 
  Send, 
  ExternalLink,
  Clock,
  Filter,
  Edit3,
  Trash2,
  Plus,
  RotateCcw
} from 'lucide-react';
import { ProviderContact, SubmissionMethod, LoAEntry } from '../types';
import { ProviderFormModal } from './ProviderFormModal';
import { 
  createProvider, 
  updateProvider, 
  deleteProvider, 
  resetProvidersToInitial 
} from '../services/providerService';

interface ProviderDirectoryProps {
  loas: LoAEntry[];
  providers: ProviderContact[];
  onRefreshProviders?: () => void;
}

export const ProviderDirectory: React.FC<ProviderDirectoryProps> = ({ 
  loas, 
  providers,
  onRefreshProviders 
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMethod, setSelectedMethod] = useState<string>('ALL');
  const [sortField, setSortField] = useState<'name' | 'avgTurnaroundDays' | 'bestSubmissionMethod'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProvider, setEditingProvider] = useState<ProviderContact | null>(null);

  // Handler for changing best submission method interactively
  const handleUpdateMethod = async (providerId: string, newMethod: SubmissionMethod) => {
    try {
      await updateProvider(providerId, { bestSubmissionMethod: newMethod });
      if (onRefreshProviders) onRefreshProviders();
    } catch (e) {
      console.error('Failed to update submission method:', e);
    }
  };

  // Handler for saving/editing provider
  const handleSaveProvider = async (
    providerData: Omit<ProviderContact, 'id'>,
    existingId?: string
  ) => {
    try {
      if (existingId) {
        await updateProvider(existingId, providerData);
      } else {
        await createProvider(providerData);
      }
      if (onRefreshProviders) onRefreshProviders();
    } catch (e) {
      console.error('Failed to save provider:', e);
      alert('Error saving provider to directory.');
    }
  };

  // Handler for deleting provider
  const handleDeleteProvider = async (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to delete "${name}" from the provider directory?`)) {
      try {
        await deleteProvider(id);
        if (onRefreshProviders) onRefreshProviders();
      } catch (e) {
        console.error('Failed to delete provider:', e);
        alert('Error deleting provider.');
      }
    }
  };

  // Reset to initial default list
  const handleResetDefaults = async () => {
    if (window.confirm('Reset provider directory back to standard UK default provider list?')) {
      try {
        await resetProvidersToInitial();
        if (onRefreshProviders) onRefreshProviders();
      } catch (e) {
        console.error('Failed to reset provider defaults:', e);
      }
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => {
      setCopiedId(null);
    }, 2000);
  };

  // Provider active LoA mapping
  const providerActiveLoaMap: Record<string, { total: number; overdue: number }> = {};
  loas.forEach(l => {
    const provName = l.currentProvider.toLowerCase();
    const match = providers.find(p => 
      p.name.toLowerCase().includes(provName) || provName.includes(p.name.toLowerCase())
    );
    const key = match ? match.name : l.currentProvider;
    if (!providerActiveLoaMap[key]) {
      providerActiveLoaMap[key] = { total: 0, overdue: 0 };
    }
    providerActiveLoaMap[key].total += 1;
    if (l.status === 'Overdue' || l.status === 'Overdue + Chased') {
      providerActiveLoaMap[key].overdue += 1;
    }
  });

  // Filter logic
  const filteredProviders = providers.filter(prov => {
    const matchesSearch =
      prov.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      prov.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      prov.phone.toLowerCase().includes(searchTerm.toLowerCase()) ||
      prov.mailingAddress.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesMethod = selectedMethod === 'ALL' || prov.bestSubmissionMethod === selectedMethod;

    return matchesSearch && matchesMethod;
  });

  // Sort logic
  const sortedProviders = [...filteredProviders].sort((a, b) => {
    if (sortField === 'avgTurnaroundDays') {
      return sortOrder === 'asc' 
        ? a.avgTurnaroundDays - b.avgTurnaroundDays 
        : b.avgTurnaroundDays - a.avgTurnaroundDays;
    }

    const aVal = a[sortField] || '';
    const bVal = b[sortField] || '';
    return sortOrder === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
  });

  const toggleSort = (field: 'name' | 'avgTurnaroundDays' | 'bestSubmissionMethod') => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Main Table Card (matching LoATable structure) */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden flex flex-col">
        
        {/* Control & Filter Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-white space-y-4">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            
            {/* Search Box */}
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search provider, address, email, or telephone..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg py-2 pl-9 pr-4 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition"
              />
              {searchTerm && (
                <button
                  type="button"
                  onClick={() => setSearchTerm('')}
                  className="absolute right-2.5 top-2.5 text-xs text-slate-400 hover:text-slate-600"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Filters & Add Provider Button */}
            <div className="flex flex-wrap items-center gap-2 text-xs">
              
              {/* Submission Method Filter */}
              <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
                <span className="text-slate-500 font-medium">Method:</span>
                <select
                  value={selectedMethod}
                  onChange={(e) => setSelectedMethod(e.target.value)}
                  className="bg-transparent text-slate-800 focus:outline-none cursor-pointer font-medium"
                >
                  <option value="ALL">All Methods</option>
                  <option value="unipass">⚡ Unipass</option>
                  <option value="post">✉️ Post / Paper</option>
                  <option value="email">📧 Email Direct</option>
                </select>
              </div>

              {/* Reset filter button if active */}
              {(searchTerm !== '' || selectedMethod !== 'ALL') && (
                <button
                  type="button"
                  onClick={() => {
                    setSearchTerm('');
                    setSelectedMethod('ALL');
                  }}
                  className="px-2.5 py-1.5 text-xs text-blue-600 hover:text-blue-800 font-medium transition"
                >
                  Reset Filters
                </button>
              )}

              {/* Reset to Defaults button */}
              <button
                type="button"
                onClick={handleResetDefaults}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 font-medium rounded-lg transition flex items-center gap-1.5"
                title="Restore default UK provider list"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Defaults</span>
              </button>

              {/* Add New Provider Button */}
              <button
                type="button"
                onClick={() => {
                  setEditingProvider(null);
                  setIsModalOpen(true);
                }}
                className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg shadow-2xs transition flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Provider</span>
              </button>
            </div>
          </div>
        </div>

        {/* Table Container */}
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200 text-left">
            <thead className="bg-slate-50">
              <tr>
                <th 
                  className="px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider cursor-pointer hover:text-slate-800"
                  onClick={() => toggleSort('name')}
                >
                  <div className="flex items-center gap-1">
                    <span>Provider Name</span>
                    {sortField === 'name' && (sortOrder === 'asc' ? <ChevronUp className="w-3.5 h-3.5 text-blue-600" /> : <ChevronDown className="w-3.5 h-3.5 text-blue-600" />)}
                  </div>
                </th>
                
                <th className="px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Mailing Address
                </th>

                <th className="px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Email Address
                </th>

                <th className="px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Telephone Number
                </th>

                <th 
                  className="px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider text-center cursor-pointer hover:text-slate-800"
                  onClick={() => toggleSort('bestSubmissionMethod')}
                >
                  <div className="flex items-center justify-center gap-1">
                    <span>Best Submission Method</span>
                    {sortField === 'bestSubmissionMethod' && (sortOrder === 'asc' ? <ChevronUp className="w-3.5 h-3.5 text-blue-600" /> : <ChevronDown className="w-3.5 h-3.5 text-blue-600" />)}
                  </div>
                </th>

                <th 
                  className="px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider text-center cursor-pointer hover:text-slate-800"
                  onClick={() => toggleSort('avgTurnaroundDays')}
                >
                  <div className="flex items-center justify-center gap-1">
                    <span>Avg SLA</span>
                    {sortField === 'avgTurnaroundDays' && (sortOrder === 'asc' ? <ChevronUp className="w-3.5 h-3.5 text-blue-600" /> : <ChevronDown className="w-3.5 h-3.5 text-blue-600" />)}
                  </div>
                </th>

                {/* Actions Column (matching LoATable) */}
                <th className="px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider text-right">
                  Actions
                </th>
              </tr>
            </thead>

            <tbody className="bg-white divide-y divide-slate-200">
              {sortedProviders.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    <Building2 className="w-8 h-8 mx-auto mb-2 opacity-40 text-slate-400" />
                    No provider records match your search parameters.
                  </td>
                </tr>
              ) : (
                sortedProviders.map((provider) => {
                  const isCopiedEmail = copiedId === `email-${provider.id}`;
                  const isCopiedPhone = copiedId === `phone-${provider.id}`;
                  const isCopiedAddress = copiedId === `addr-${provider.id}`;
                  const activeStats = providerActiveLoaMap[provider.name];

                  return (
                    <tr 
                      key={provider.id} 
                      className="hover:bg-slate-50/80 transition-colors"
                    >
                      
                      {/* Provider Name */}
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-slate-900">
                            {provider.name}
                          </span>
                          {activeStats && activeStats.total > 0 && (
                            <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-blue-50 text-blue-700 border border-blue-200">
                              {activeStats.total} in LoA pipeline
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Mailing Address with 1-click copy */}
                      <td className="px-6 py-4 text-sm text-slate-600 max-w-xs">
                        <div className="flex items-start justify-between gap-2 group">
                          <span className="text-xs text-slate-700 leading-snug">
                            {provider.mailingAddress}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleCopy(provider.mailingAddress, `addr-${provider.id}`)}
                            className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded transition shrink-0"
                            title="Copy Address"
                          >
                            {isCopiedAddress ? (
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      </td>

                      {/* Email Address with 1-click copy */}
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <div className="flex items-center justify-between gap-2">
                          <a
                            href={`mailto:${provider.email}`}
                            className="font-mono text-xs text-blue-600 hover:text-blue-800 hover:underline font-medium"
                          >
                            {provider.email}
                          </a>
                          <button
                            type="button"
                            onClick={() => handleCopy(provider.email, `email-${provider.id}`)}
                            className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded transition shrink-0"
                            title="Copy Email"
                          >
                            {isCopiedEmail ? (
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      </td>

                      {/* Telephone Number with 1-click copy */}
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <div className="flex items-center justify-between gap-2">
                          <a
                            href={`tel:${provider.phone.replace(/\s+/g, '')}`}
                            className="font-mono text-xs text-slate-800 hover:text-blue-600 font-medium"
                          >
                            {provider.phone}
                          </a>
                          <button
                            type="button"
                            onClick={() => handleCopy(provider.phone, `phone-${provider.id}`)}
                            className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded transition shrink-0"
                            title="Copy Telephone"
                          >
                            {isCopiedPhone ? (
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      </td>

                      {/* Interactive Best Submission Method: Choice between 3 options (Unipass, Post, Email) */}
                      <td className="px-6 py-4 whitespace-nowrap text-center">
                        <div className="inline-flex items-center p-0.5 rounded-lg bg-slate-100 border border-slate-200">
                          
                          {/* Unipass button */}
                          <button
                            type="button"
                            onClick={() => handleUpdateMethod(provider.id, 'unipass')}
                            className={`px-2.5 py-1 rounded text-xs font-semibold transition ${
                              provider.bestSubmissionMethod === 'unipass'
                                ? 'bg-purple-600 text-white shadow-xs'
                                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
                            }`}
                            title="Set preferred route to Unipass Electronic Submission"
                          >
                            ⚡ Unipass
                          </button>

                          {/* Post button */}
                          <button
                            type="button"
                            onClick={() => handleUpdateMethod(provider.id, 'post')}
                            className={`px-2.5 py-1 rounded text-xs font-semibold transition ${
                              provider.bestSubmissionMethod === 'post'
                                ? 'bg-amber-600 text-white shadow-xs'
                                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
                            }`}
                            title="Set preferred route to Postal Wet Signature"
                          >
                            ✉️ Post
                          </button>

                          {/* Email button */}
                          <button
                            type="button"
                            onClick={() => handleUpdateMethod(provider.id, 'email')}
                            className={`px-2.5 py-1 rounded text-xs font-semibold transition ${
                              provider.bestSubmissionMethod === 'email'
                                ? 'bg-emerald-600 text-white shadow-xs'
                                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
                            }`}
                            title="Set preferred route to Direct Email PDF"
                          >
                            📧 Email
                          </button>

                        </div>
                      </td>

                      {/* Avg SLA */}
                      <td className="px-6 py-4 whitespace-nowrap text-center text-sm font-mono">
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-slate-100 border border-slate-200 text-slate-700">
                          {provider.avgTurnaroundDays} days
                        </span>
                      </td>

                      {/* Actions: Edit and Delete Buttons replicated from LoATable */}
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => {
                              setEditingProvider(provider);
                              setIsModalOpen(true);
                            }}
                            className="p-1.5 text-slate-500 hover:bg-slate-100 rounded-lg transition"
                            title="Edit Provider"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteProvider(provider.id, provider.name)}
                            className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition"
                            title="Delete Provider"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>

                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Footer Info (matching LoATable footer) */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-between items-center text-xs text-slate-500 font-medium">
          <span>Showing {sortedProviders.length} of {providers.length} providers</span>
          <span>Adams &amp; Poole Financial Services</span>
        </div>

      </div>

      {/* Provider Form Modal (Add / Edit) */}
      <ProviderFormModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingProvider(null);
        }}
        onSubmit={handleSaveProvider}
        editingProvider={editingProvider}
      />

    </div>
  );
};
