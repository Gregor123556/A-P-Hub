import React, { useState, useEffect, useMemo } from 'react';
import { 
  X, 
  Calculator, 
  ShieldCheck, 
  Building2, 
  FileText, 
  Calendar, 
  Mail,
  Phone,
  MapPin,
  Send,
  Clock,
  ExternalLink
} from 'lucide-react';
import { AccountType, LoAEntry, LoAStatus, ProviderContact } from '../types';
import {
  calculateDueDate,
  calculateChaseUpDate,
  getTodayDDMMYYYY,
  ddmmToYyyyMmDd,
  yyyymmddToDdMmYyyy,
  formatDDMMYYYY
} from '../utils/dateUtils';
import { normalizeServiceScope } from '../utils/currencyUtils';
import { getStoredProviders } from '../services/providerService';

interface LoAFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Omit<LoAEntry, 'id' | 'createdAt'>, existingId?: string) => void;
  editingEntry?: LoAEntry | null;
  providers?: ProviderContact[];
}

export const LoAFormModal: React.FC<LoAFormModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  editingEntry,
  providers: propProviders
}) => {
  const todayStr = getTodayDDMMYYYY();

  // Retrieve current active directory providers
  const activeProviders = useMemo(() => {
    const list = propProviders && propProviders.length > 0 ? propProviders : getStoredProviders();
    return [...list].sort((a, b) => a.name.localeCompare(b.name));
  }, [propProviders, isOpen]);

  const [clientName, setClientName] = useState('');
  const [accountType, setAccountType] = useState<AccountType>('Pension');
  const [currentProvider, setCurrentProvider] = useState('');
  const [dateSent, setDateSent] = useState(todayStr);
  const [dateDue, setDateDue] = useState(calculateDueDate(todayStr));
  const [chaseUpDate, setChaseUpDate] = useState(calculateChaseUpDate(todayStr));
  const [status, setStatus] = useState<LoAStatus>('Pending');
  const [policyNumber, setPolicyNumber] = useState('');
  const [adviserName, setAdviserName] = useState('Sam Adams');
  const [notes, setNotes] = useState('');
  const [isCustomDates, setIsCustomDates] = useState(false);

  useEffect(() => {
    if (editingEntry) {
      setClientName(editingEntry.clientName);
      setAccountType(normalizeServiceScope(editingEntry.accountType));
      setCurrentProvider(editingEntry.currentProvider);
      setDateSent(editingEntry.dateSent);
      setDateDue(editingEntry.dateDue);
      setChaseUpDate(editingEntry.chaseUpDate);
      setStatus(editingEntry.status);
      setPolicyNumber(editingEntry.policyNumber || '');
      setAdviserName(editingEntry.adviserName && (editingEntry.adviserName === 'Anthony Poole' || editingEntry.adviserName === 'Sam Adams') ? editingEntry.adviserName : 'Sam Adams');
      setNotes(editingEntry.notes || '');
    } else {
      setClientName('');
      setAccountType('Pension');
      // Set default to first provider present in directory
      const defaultProviderName = activeProviders.length > 0 ? activeProviders[0].name : 'Aviva';
      setCurrentProvider(defaultProviderName);
      setDateSent(todayStr);
      setDateDue(calculateDueDate(todayStr));
      setChaseUpDate(calculateChaseUpDate(todayStr));
      setStatus('Pending');
      setPolicyNumber('');
      setAdviserName('Sam Adams');
      setNotes('');
      setIsCustomDates(false);
    }
  }, [editingEntry, isOpen, activeProviders]);

  const handleDateSentChange = (newSentDate: string) => {
    setDateSent(newSentDate);
    if (!isCustomDates) {
      setDateDue(calculateDueDate(newSentDate));
      setChaseUpDate(calculateChaseUpDate(newSentDate));
    }
  };

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientName.trim() || !currentProvider.trim() || !policyNumber.trim()) return;

    onSubmit(
      {
        clientName: clientName.trim(),
        accountType: normalizeServiceScope(accountType),
        currentProvider: currentProvider.trim(),
        dateSent,
        dateDue,
        chaseUpDate,
        status,
        policyNumber: policyNumber.trim(),
        adviserName: adviserName.trim(),
        notes: notes.trim(),
        lastChasedDate: editingEntry?.lastChasedDate || ''
      },
      editingEntry?.id
    );

    onClose();
  };

  // Find currently selected provider contact info from directory
  const selectedProviderInfo = activeProviders.find(
    p => p.name.toLowerCase() === currentProvider.toLowerCase()
  );

  // Check if editing a legacy provider not currently in directory
  const isLegacyProviderNotInDirectory = 
    currentProvider && !activeProviders.some(p => p.name.toLowerCase() === currentProvider.toLowerCase());

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl relative overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header - Fixed at top */}
        <div className="flex items-center justify-between border-b border-slate-200 p-5 sm:p-6 bg-white shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-50 border border-blue-100 rounded-lg text-blue-600">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                {editingEntry ? 'Edit Letter of Authority' : 'Create Letter of Authority Record'}
              </h3>
              <p className="text-xs text-slate-500">
                Adams and Poole Financial Services • LoA Pipeline
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition"
            title="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body - Scrollable */}
        <form onSubmit={handleSubmit} className="flex flex-col flex-1 overflow-hidden">
          <div className="p-5 sm:p-6 space-y-4 text-xs overflow-y-auto flex-1">
            
            {/* Client Name & Plan Number */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Client Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. John & Sarah Smith"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg py-2.5 px-3 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Plan / Policy Number <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. AV-993821-P or 00839210"
                  value={policyNumber}
                  onChange={(e) => setPolicyNumber(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg py-2.5 px-3 text-slate-900 font-mono focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition"
                />
              </div>
            </div>

            {/* Account Type & Current Provider (Strict Directory Selection) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Service Scope / Account Type <span className="text-red-500">*</span>
                </label>
                <select
                  value={accountType}
                  onChange={(e) => setAccountType(normalizeServiceScope(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg py-2.5 px-3 text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition"
                >
                  <option value="ISA & GIA">ISA & GIA</option>
                  <option value="CIB">CIB</option>
                  <option value="Pension">Pension</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1 flex items-center justify-between">
                  <span>Provider (from Directory) <span className="text-red-500">*</span></span>
                  <span className="text-[10px] text-slate-400 font-normal">
                    {activeProviders.length} registered
                  </span>
                </label>
                
                <select
                  required
                  value={currentProvider}
                  onChange={(e) => setCurrentProvider(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg py-2.5 px-3 text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition cursor-pointer"
                >
                  {isLegacyProviderNotInDirectory && (
                    <option value={currentProvider}>
                      {currentProvider} (Legacy Record)
                    </option>
                  )}
                  {activeProviders.length === 0 ? (
                    <option value="" disabled>No providers found in directory</option>
                  ) : (
                    activeProviders.map((provider) => {
                      const methodIcon = 
                        provider.bestSubmissionMethod === 'unipass' ? '⚡ Unipass' :
                        provider.bestSubmissionMethod === 'post' ? '✉️ Post' : '📧 Email';
                      return (
                        <option key={provider.id} value={provider.name}>
                          {provider.name} ({methodIcon} • {provider.avgTurnaroundDays}d SLA)
                        </option>
                      );
                    })
                  )}
                </select>
              </div>
            </div>

            {/* Provider Directory Info Card Preview */}
            {selectedProviderInfo && (
              <div className="bg-blue-50/50 border border-blue-100 rounded-xl p-3 text-xs space-y-1.5 animate-in fade-in duration-150">
                <div className="flex items-center justify-between text-blue-900 font-semibold">
                  <div className="flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-blue-600" />
                    <span>{selectedProviderInfo.name} Contact Desk</span>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                    selectedProviderInfo.bestSubmissionMethod === 'unipass'
                      ? 'bg-purple-100 text-purple-800'
                      : selectedProviderInfo.bestSubmissionMethod === 'post'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-emerald-100 text-emerald-800'
                  }`}>
                    Route: {selectedProviderInfo.bestSubmissionMethod === 'unipass' ? '⚡ Unipass' : selectedProviderInfo.bestSubmissionMethod === 'post' ? '✉️ Post' : '📧 Email'}
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-slate-600 pt-1 border-t border-blue-100">
                  <div className="flex items-center gap-1">
                    <Mail className="w-3 h-3 text-slate-400 shrink-0" />
                    <span className="font-mono truncate">{selectedProviderInfo.email || 'N/A'}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Phone className="w-3 h-3 text-slate-400 shrink-0" />
                    <span className="font-mono">{selectedProviderInfo.phone || 'N/A'}</span>
                  </div>
                </div>
              </div>
            )}

            {/* Assigned Advisor */}
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Assigned Advisor</label>
              <select
                value={adviserName}
                onChange={(e) => setAdviserName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg py-2.5 px-3 text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition cursor-pointer"
              >
                <option value="Sam Adams">Sam Adams</option>
                <option value="Anthony Poole">Anthony Poole</option>
              </select>
            </div>

            {/* Date Section */}
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                <span className="font-semibold text-blue-700 flex items-center gap-1.5">
                  <Calculator className="w-4 h-4" />
                  Automatic Date Calculations (DD-MM-YYYY)
                </span>
                <label className="flex items-center gap-1.5 text-[11px] text-slate-500 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isCustomDates}
                    onChange={(e) => setIsCustomDates(e.target.checked)}
                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  Override calculation
                </label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Date Sent with Date Picker */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-slate-700 font-semibold flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-blue-600" />
                      Date Sent <span className="text-red-500">*</span>
                    </label>
                    <div className="flex items-center gap-1 text-[10px]">
                      <button
                        type="button"
                        onClick={() => handleDateSentChange(todayStr)}
                        className="px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 hover:bg-blue-100 font-medium transition"
                      >
                        Today
                      </button>
                    </div>
                  </div>
                  <div className="relative">
                    <input
                      type="date"
                      value={ddmmToYyyyMmDd(dateSent)}
                      onChange={(e) => {
                        if (e.target.value) {
                          handleDateSentChange(yyyymmddToDdMmYyyy(e.target.value));
                        }
                      }}
                      className="w-full bg-white border border-slate-300 rounded-lg py-1.5 px-2.5 text-slate-800 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>
                  <p className="text-[10px] text-slate-400 font-mono">Format: {dateSent}</p>
                </div>

                {/* Target Due Date (Default: +14 days) */}
                <div className="space-y-1.5">
                  <label className="text-slate-700 font-semibold flex items-center justify-between">
                    <span>Target Due Date</span>
                    <span className="text-[10px] text-slate-400 font-normal">(+14 days)</span>
                  </label>
                  <input
                    type="date"
                    disabled={!isCustomDates}
                    value={ddmmToYyyyMmDd(dateDue)}
                    onChange={(e) => {
                      if (e.target.value) {
                        setDateDue(yyyymmddToDdMmYyyy(e.target.value));
                      }
                    }}
                    className={`w-full border rounded-lg py-1.5 px-2.5 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none ${
                      isCustomDates
                        ? 'bg-white border-slate-300 text-slate-800'
                        : 'bg-slate-100 border-slate-200 text-slate-600 cursor-not-allowed'
                    }`}
                  />
                  <p className="text-[10px] text-slate-400 font-mono">Format: {dateDue}</p>
                </div>

                {/* Chase-Up Date (Default: +7 days) */}
                <div className="space-y-1.5">
                  <label className="text-slate-700 font-semibold flex items-center justify-between">
                    <span>Chase-Up Date</span>
                    <span className="text-[10px] text-slate-400 font-normal">(+7 days)</span>
                  </label>
                  <input
                    type="date"
                    disabled={!isCustomDates}
                    value={ddmmToYyyyMmDd(chaseUpDate)}
                    onChange={(e) => {
                      if (e.target.value) {
                        setChaseUpDate(yyyymmddToDdMmYyyy(e.target.value));
                      }
                    }}
                    className={`w-full border rounded-lg py-1.5 px-2.5 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none ${
                      isCustomDates
                        ? 'bg-white border-slate-300 text-slate-800'
                        : 'bg-slate-100 border-slate-200 text-slate-600 cursor-not-allowed'
                    }`}
                  />
                  <p className="text-[10px] text-slate-400 font-mono">Format: {chaseUpDate}</p>
                </div>
              </div>
            </div>

            {/* Status & Priority */}
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as LoAStatus)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg py-2.5 px-3 text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition"
              >
                <option value="Pending">Pending (Awaiting Provider Response)</option>
                <option value="Overdue">Overdue (Past 14 Days SLA)</option>
                <option value="Overdue + Chased">Overdue + Chased (Follow-up letter issued)</option>
                <option value="Received">Received (Information pack complete)</option>
              </select>
            </div>

            {/* Notes & Activity Log */}
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Paraplanning Tracking Notes / Escalation History
              </label>
              <textarea
                rows={3}
                placeholder="e.g. Chased provider desk via phone; awaiting full CETV discharge schedule..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-3 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition"
              />
            </div>
          </div>

          {/* Footer - Fixed at bottom */}
          <div className="border-t border-slate-200 p-4 sm:p-5 bg-slate-50 flex items-center justify-between shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white border border-slate-300 text-slate-700 font-medium rounded-lg hover:bg-slate-100 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg shadow-sm transition flex items-center gap-2"
            >
              <FileText className="w-4 h-4" />
              <span>{editingEntry ? 'Update LoA Record' : 'Save LoA Entry'}</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
