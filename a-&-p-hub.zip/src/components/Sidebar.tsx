import React from 'react';
import { 
  LayoutDashboard, PieChart, Users,
  FileSpreadsheet, Clock, Layers
} from 'lucide-react';
import { LoAEntry } from '../types';
import { AdamsPooleLogo } from './AdamsPooleLogo';

interface SidebarProps {
  loas: LoAEntry[];
  clientAdminCount?: number;
  servicingCount?: number;
  activeTab: 'tracker' | 'analytics' | 'clientAdmin' | 'servicing';
  setActiveTab: (tab: 'tracker' | 'analytics' | 'clientAdmin' | 'servicing') => void;
  onOpenNewModal: () => void;
  onOpenExportModal: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  loas,
  clientAdminCount = 0,
  servicingCount = 0,
  activeTab,
  setActiveTab,
  onOpenExportModal
}) => {
  const totalCount = loas.length;

  // Find next item due or chased
  const nextChaseLoa = loas.find(l => l.status === 'Overdue' || l.status === 'Pending') || loas[0];

  return (
    <aside className="w-64 bg-slate-900 text-white flex flex-col shrink-0 border-r border-slate-800 min-h-screen">
      {/* Brand Header */}
      <div className="p-5 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <AdamsPooleLogo size={44} />
          <div className="flex flex-col">
            <span className="text-sm font-bold tracking-tight text-white leading-tight">
              Adams &amp; Poole
            </span>
            <span className="text-[10px] font-semibold text-[#c5a468] tracking-widest uppercase">
              Financial Services
            </span>
          </div>
        </div>
        <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between">
          <span className="text-[10px] text-slate-400 font-medium uppercase tracking-wider">
            Practice Management
          </span>
          <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/60 font-semibold uppercase">
            Live
          </span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-4 space-y-1 px-3">
        <button
          onClick={() => setActiveTab('tracker')}
          className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors ${
            activeTab === 'tracker'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-400 hover:bg-slate-800 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <LayoutDashboard className="w-4 h-4" />
            <span>LoA Dashboard</span>
          </div>
          <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
            activeTab === 'tracker' ? 'bg-blue-700 text-white' : 'bg-slate-800 text-slate-300'
          }`}>
            {totalCount}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('analytics')}
          className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors ${
            activeTab === 'analytics'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-400 hover:bg-slate-800 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <PieChart className="w-4 h-4" />
            <span>Provider Directory</span>
          </div>
        </button>

        {/* Client Admin Tab - Underneath Provider Directory */}
        <button
          onClick={() => setActiveTab('clientAdmin')}
          className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors ${
            activeTab === 'clientAdmin'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-400 hover:bg-slate-800 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <Users className="w-4 h-4" />
            <span>Client Admin</span>
          </div>
          {clientAdminCount > 0 && (
            <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
              activeTab === 'clientAdmin' ? 'bg-blue-700 text-white' : 'bg-slate-800 text-slate-300'
            }`}>
              {clientAdminCount}
            </span>
          )}
        </button>

        {/* Servicing Tab - Dedicated ongoing servicing pipeline */}
        <button
          onClick={() => setActiveTab('servicing')}
          className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors ${
            activeTab === 'servicing'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-400 hover:bg-slate-800 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <Layers className="w-4 h-4" />
            <span>Servicing</span>
          </div>
          {servicingCount > 0 && (
            <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
              activeTab === 'servicing' ? 'bg-blue-700 text-white' : 'bg-slate-800 text-slate-300'
            }`}>
              {servicingCount}
            </span>
          )}
        </button>

        {/* Quick Export Button in Navigation */}
        <div className="pt-4 px-1">
          <button
            onClick={onOpenExportModal}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-slate-300 bg-slate-800/80 hover:bg-slate-800 hover:text-white rounded-lg border border-slate-700/60 transition"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-blue-400" />
            <span>Export Report / MD</span>
          </button>
        </div>
      </nav>

      {/* Sidebar Next Chase Up Card */}
      <div className="p-4 border-t border-slate-800">
        <div className="bg-slate-800 rounded-xl p-4 border border-slate-700/50">
          <p className="text-xs text-slate-400 font-medium mb-1.5 uppercase tracking-wider flex items-center gap-1">
            <Clock className="w-3 h-3 text-blue-400" />
            Next Chase Up
          </p>
          {nextChaseLoa ? (
            <div>
              <p className="text-sm font-semibold text-slate-100 truncate">
                {nextChaseLoa.clientName} - {nextChaseLoa.currentProvider}
              </p>
              <p className="text-xs text-blue-400 mt-1 flex items-center gap-1 font-mono">
                Due: {nextChaseLoa.chaseUpDate}
              </p>
            </div>
          ) : (
            <p className="text-xs text-slate-400">All LoAs up to date</p>
          )}
        </div>
      </div>
    </aside>
  );
};
