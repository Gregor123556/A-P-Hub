import React, { useState, useEffect } from 'react';
import { X, Copy, Check, Send, RefreshCw, Mail } from 'lucide-react';
import { LoAEntry } from '../types';
import { getTodayDDMMYYYY, parseDDMMYYYY } from '../utils/dateUtils';
import { PROVIDER_CONTACTS } from '../data/mockData';

interface ChaseLetterModalProps {
  entry: LoAEntry | null;
  isOpen: boolean;
  onClose: () => void;
  onLoggedChase: (id: string, dateChased: string) => void;
}

export const ChaseLetterModal: React.FC<ChaseLetterModalProps> = ({
  entry,
  isOpen,
  onClose,
  onLoggedChase
}) => {
  const [letterContent, setLetterContent] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [urgency, setUrgency] = useState<'Standard' | 'Urgent' | 'Formal Escalation'>('Standard');

  const generateLetter = async (urgencyLevel: 'Standard' | 'Urgent' | 'Formal Escalation') => {
    if (!entry) return;
    setIsLoading(true);
    setUrgency(urgencyLevel);

    const contact = PROVIDER_CONTACTS[entry.currentProvider];
    const sentDate = parseDDMMYYYY(entry.dateSent) || new Date();
    const now = new Date();
    const daysElapsed = Math.max(1, Math.floor((now.getTime() - sentDate.getTime()) / (1000 * 60 * 60 * 24)));

    try {
      const response = await fetch('/api/generate-chase-letter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientName: entry.clientName,
          provider: entry.currentProvider,
          accountType: entry.accountType,
          policyNumber: entry.policyNumber || 'On original LoA',
          daysOutstanding: daysElapsed,
          lastChasedDate: entry.lastChasedDate,
          urgencyLevel
        })
      });

      if (!response.ok) throw new Error('API request failed');

      const data = await response.json();
      setLetterContent(data.letter);
    } catch (err) {
      console.error(err);
      const fallback = `SUBJECT: ${urgencyLevel === 'Formal Escalation' ? 'FORMAL ESCALATION:' : ''} Chasing Letter of Authority - ${entry.clientName} (${entry.accountType})

TO: ${contact?.email || `${entry.currentProvider.toLowerCase().replace(/\s+/g, '')}.loa@servicing.co.uk`}
ATTN: ${entry.currentProvider} Servicing & Transfers Team

RE: Letter of Authority - ${entry.clientName}
Account Type: ${entry.accountType}
Policy Reference: ${entry.policyNumber || 'As per signed authority'}
Date Originally Submitted: ${entry.dateSent} (${daysElapsed} days elapsed)
Practice Reference: APFS-LOA-${entry.id.replace('loa-', '')}

Dear Servicing Team,

We are writing on behalf of Adams and Poole Financial Services to chase the status of the signed Letter of Authority submitted for our client, ${entry.clientName}, on ${entry.dateSent}.

Under standard UK financial services guidelines and provider SLAs, this request is now ${entry.status === 'Overdue' ? 'OVERDUE' : 'due for urgent update'}.

Please urgently provide:
1. Current policy value & surrender/transfer value
2. Full fund allocation breakdown and underlying charges schedule
3. Guarantees, penalties, or transfer restrictions

Please reply directly to paraplanning@adamsandpoolefs.co.uk.

Kind regards,
Paraplanning Department
Adams and Poole Financial Services`;

      setLetterContent(fallback);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (entry && isOpen) {
      let initialUrgency: 'Standard' | 'Urgent' | 'Formal Escalation' = 'Standard';
      if (entry.status === 'Overdue') initialUrgency = 'Urgent';
      if (entry.status === 'Overdue + Chased') initialUrgency = 'Formal Escalation';
      setUrgency(initialUrgency);
      generateLetter(initialUrgency);
    }
  }, [entry?.id, entry?.status, isOpen]);

  if (!isOpen || !entry) return null;

  const todayStr = getTodayDDMMYYYY();
  const contact = PROVIDER_CONTACTS[entry.currentProvider];
  const sentDate = parseDDMMYYYY(entry.dateSent) || new Date();
  const now = new Date();
  const daysElapsed = Math.max(1, Math.floor((now.getTime() - sentDate.getTime()) / (1000 * 60 * 60 * 24)));

  const handleCopy = () => {
    navigator.clipboard.writeText(letterContent);
    setIsCopied(true);
    onLoggedChase(entry.id, todayStr);
    setTimeout(() => setIsCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl relative animate-scaleIn overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 p-5 sm:p-6 bg-white shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-blue-50 border border-blue-100 rounded-xl text-blue-600">
              <Send className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                Provider Chase Communication Generator
                <span className="text-[10px] uppercase font-bold text-[#9d7d40] bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">
                  Adams &amp; Poole
                </span>
              </h3>
              <p className="text-xs text-slate-500">
                {entry.clientName} • {entry.currentProvider} ({entry.accountType}) • {daysElapsed} days outstanding
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-4">
          {/* Urgency Controls */}
          <div className="flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs">
            <span className="text-slate-600 font-semibold">Select Urgency Level:</span>
            <div className="flex items-center gap-1.5">
              {(['Standard', 'Urgent', 'Formal Escalation'] as const).map((lvl) => (
                <button
                  key={lvl}
                  type="button"
                  onClick={() => generateLetter(lvl)}
                  className={`px-3 py-1 rounded-lg font-semibold transition ${
                    urgency === lvl
                      ? lvl === 'Formal Escalation'
                        ? 'bg-red-600 text-white'
                        : lvl === 'Urgent'
                        ? 'bg-amber-600 text-white'
                        : 'bg-blue-600 text-white'
                      : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {lvl}
                </button>
              ))}
            </div>
          </div>

          {/* Generated Letter Preview */}
          <div className="relative">
            {isLoading ? (
              <div className="h-64 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-center text-slate-500 text-xs gap-2">
                <RefreshCw className="w-5 h-5 animate-spin text-blue-600" />
                <span>Drafting provider chase letter for Adams &amp; Poole Financial Services...</span>
              </div>
            ) : (
              <textarea
                readOnly
                value={letterContent}
                onChange={(e) => setLetterContent(e.target.value)}
                rows={11}
                className="w-full bg-slate-50 text-slate-800 border border-slate-200 rounded-xl p-4 font-mono text-xs leading-relaxed focus:outline-none focus:ring-2 focus:ring-blue-500/50 resize-none shadow-inner"
              />
            )}
          </div>

          {/* Provider Direct Contact Details */}
          {contact && (
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1.5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-slate-600 font-medium flex items-center gap-1">
                  <Mail className="w-3.5 h-3.5 text-blue-600" />
                  Provider Desk: <span className="text-slate-900 font-mono font-semibold">{contact.email}</span>
                </span>
                <span className="text-slate-600">
                  Tel: <span className="text-slate-900 font-mono font-semibold">{contact.phone}</span>
                </span>
              </div>
              {contact.mailingAddress && (
                <div className="text-[11px] text-slate-500 border-t border-slate-200/60 pt-1.5 flex items-start gap-1">
                  <span className="font-semibold text-slate-600 shrink-0">Postal Address:</span>
                  <span className="text-slate-700">{contact.mailingAddress}</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer Action */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-t border-slate-200 bg-slate-50/80 shrink-0">
          <span className="text-[11px] text-slate-500 italic">
            Copying automatically logs Last Chased Date as today ({todayStr}).
          </span>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 text-xs text-slate-600 hover:text-slate-800 transition"
            >
              Close
            </button>
            <button
              type="button"
              onClick={handleCopy}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium text-xs rounded-lg transition shadow-sm flex items-center gap-2"
            >
              {isCopied ? (
                <>
                  <Check className="w-4 h-4 text-white" />
                  <span>Copied & Logged!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copy Letter & Log Chase</span>
                </>
              )}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
