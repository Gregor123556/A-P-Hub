import { GoogleGenAI, Type } from '@google/genai';
import { AccountType, LoAStatus } from '../types';

let genaiClient: GoogleGenAI | null = null;

function getGenAI(): GoogleGenAI {
  if (!genaiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn('GEMINI_API_KEY environment variable is missing.');
    }
    genaiClient = new GoogleGenAI({
      apiKey: apiKey || '',
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return genaiClient;
}

export interface ParseResult {
  action: 'create' | 'update' | 'unknown';
  clientName?: string;
  accountType?: AccountType;
  currentProvider?: string;
  dateSent?: string;
  policyNumber?: string;
  notes?: string;
  newStatus?: LoAStatus;
  targetClientName?: string;
  targetProvider?: string;
  explanation: string;
}

/**
 * Uses Gemini 3.6 Flash to parse unstructured user input into LoA fields or status updates.
 */
export async function parseUnstructuredLoAInput(userInput: string, referenceDateStr: string): Promise<ParseResult> {
  const ai = getGenAI();

  const systemInstruction = `You are a specialized AI Paraplanning Assistant for Adams and Poole Financial Services, a UK Financial Advisory practice.
Your job is to parse unstructured natural language input from paraplanners and advisers into structured Letter of Authority (LoA) actions.

Rules for field parsing:
1. "action": Determine if the user is creating a new LoA ('create') or updating an existing status ('update').
2. "accountType": MUST strictly be one of the three practice service scopes: "ISA & GIA", "CIB", or "Pension".
   - If user mentions "ISA", "GIA", "Stocks & Shares ISA", "General Investment Account", "unit trust", "portfolio", "investment", "wealth" -> "ISA & GIA".
   - If user mentions "CIB", "Bond", "Collective Investment Bond", "Capital Investment Bond", "Onshore Bond", "Offshore Bond", "Investment Bond" -> "CIB".
   - If user mentions "Pension", "SIPP", "PPP", "retirement", "pension plan", "annuity", "drawdown" -> "Pension".
   - Default to "Pension" if ambiguous.
3. "currentProvider": Existing provider name e.g. "Aviva", "Prudential", "Royal London", "Aegon", "Legal & General", "Fidelity", "Scottish Widows", "Utmost Wealth Solutions", etc.
4. "dateSent": Date format DD-MM-YYYY.
   - If user mentions "today" or leaves date unspecified, set dateSent to referenceDateStr: "${referenceDateStr}".
   - If user mentions "yesterday", calculate 1 day prior to referenceDateStr.
5. "newStatus": MUST strictly be one of: "Pending", "Received", "Overdue", "Overdue + Chased".
   - If user says "received", "got the info", "completed", "docs in" -> "Received".
   - If user says "chased", "still waiting", "chased up", "escalate", "escalated" -> "Overdue + Chased".
6. "explanation": A friendly, professional summary of the action parsed for the Adams and Poole Financial Services paraplanner.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: `Reference date today is ${referenceDateStr}.
User input: "${userInput}"`,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            action: { type: Type.STRING, description: "'create', 'update', or 'unknown'" },
            clientName: { type: Type.STRING, description: "Name of the client e.g. John Smith" },
            accountType: { type: Type.STRING, description: "Must be 'ISA & GIA', 'CIB', or 'Pension'" },
            currentProvider: { type: Type.STRING, description: "Provider name e.g. Aviva" },
            dateSent: { type: Type.STRING, description: "DD-MM-YYYY format" },
            policyNumber: { type: Type.STRING, description: "Policy reference if provided" },
            notes: { type: Type.STRING, description: "Any extra notes" },
            newStatus: { type: Type.STRING, description: "Pending, Received, Overdue, or Overdue + Chased" },
            targetClientName: { type: Type.STRING, description: "For status update: targeted client name" },
            targetProvider: { type: Type.STRING, description: "For status update: targeted provider" },
            explanation: { type: Type.STRING, description: "Friendly paraplanner explanation of parsed details" },
          },
          required: ['action', 'explanation'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return {
      action: parsed.action || 'unknown',
      clientName: parsed.clientName,
      accountType: validateAccountType(parsed.accountType),
      currentProvider: parsed.currentProvider,
      dateSent: parsed.dateSent || referenceDateStr,
      policyNumber: parsed.policyNumber,
      notes: parsed.notes,
      newStatus: validateStatus(parsed.newStatus),
      targetClientName: parsed.targetClientName || parsed.clientName,
      targetProvider: parsed.targetProvider || parsed.currentProvider,
      explanation: parsed.explanation || 'Parsed user request successfully.',
    };
  } catch (error) {
    console.error('Error parsing input with Gemini:', error);
    // Fallback regex parser for basic inputs
    return fallbackRegexParser(userInput, referenceDateStr);
  }
}

function validateAccountType(type?: string): AccountType | undefined {
  if (!type) return undefined;
  const lower = type.toLowerCase();
  if (lower.includes('cib') || lower.includes('bond') || lower.includes('capital') || lower.includes('collective')) return 'CIB';
  if (lower.includes('isa') || lower.includes('gia') || lower.includes('invest') || lower.includes('wealth') || lower.includes('stock')) return 'ISA & GIA';
  if (lower.includes('pension') || lower.includes('sipp') || lower.includes('retire') || lower.includes('annuity')) return 'Pension';
  return 'Pension';
}

function validateStatus(status?: string): LoAStatus | undefined {
  if (!status) return undefined;
  const lower = status.toLowerCase();
  if (lower.includes('receive') || lower.includes('complete') || lower.includes('done')) return 'Received';
  if (lower.includes('escalat') || lower.includes('chased')) return 'Overdue + Chased';
  if (lower.includes('overdue')) return 'Overdue';
  if (lower.includes('pend')) return 'Pending';
  return 'Pending';
}

function fallbackRegexParser(userInput: string, referenceDateStr: string): ParseResult {
  const lower = userInput.toLowerCase();
  const isUpdate = lower.includes('mark') || lower.includes('update') || lower.includes('received') || lower.includes('status');

  if (isUpdate) {
    let newStatus: LoAStatus = 'Pending';
    if (lower.includes('received')) newStatus = 'Received';
    if (lower.includes('escalat') || lower.includes('chased')) newStatus = 'Overdue + Chased';

    return {
      action: 'update',
      newStatus,
      explanation: `Attempting to update status to ${newStatus} based on rule-based parse.`,
    };
  }

  // Basic extraction
  let accountType: AccountType = 'Pension';
  if (lower.includes('cib') || lower.includes('bond')) accountType = 'CIB';
  else if (lower.includes('isa') || lower.includes('gia') || lower.includes('investment')) accountType = 'ISA & GIA';

  return {
    action: 'create',
    accountType,
    dateSent: referenceDateStr,
    explanation: 'Created LoA record with default auto-calculated dates.',
  };
}

/**
 * Drafts a professional Adams and Poole Financial Services provider chase letter using Gemini.
 */
export async function generateChaseLetter(
  clientName: string,
  provider: string,
  accountType: AccountType,
  policyNumber: string,
  daysOutstanding: number,
  lastChasedDate?: string,
  urgencyLevel: 'Standard' | 'Urgent' | 'Formal Escalation' = 'Standard'
): Promise<string> {
  const ai = getGenAI();

  const prompt = `Draft a formal UK Independent Financial Adviser (IFA) provider Letter of Authority (LoA) chase communication.
Firm context: Adams and Poole Financial Services.

Details:
- Client Name: ${clientName}
- Current Provider: ${provider}
- Account Type: ${accountType}
- Policy Reference: ${policyNumber || 'As on signed LoA'}
- Days Elapsed since LoA sent: ${daysOutstanding} days
- Last Chased Date: ${lastChasedDate || 'N/A'}
- Urgency Level: ${urgencyLevel}

Requirements:
1. Standard UK paraplanning tone: professional, polite yet firm, referencing statutory SLAs and industry standard practice.
2. Clear Subject Line.
3. Explicitly request: Current Valuation, Transfer Value, Fund Breakdown, Contribution/Benefit Statements, and Charges Schedule.
4. Include formal practice reference code [APFS-LOA-${Math.floor(1000 + Math.random() * 9000)}].
5. Direct replies to paraplanning@adamsandpoolefs.co.uk.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        systemInstruction: 'You write pristine UK IFA paraplanning communications for provider chasing on behalf of Adams and Poole Financial Services.',
      },
    });

    return response.text || 'Error generating letter template.';
  } catch (error) {
    console.error('Error generating chase letter:', error);
    return `SUBJECT: Chasing Letter of Authority - ${clientName} - ${policyNumber || provider}

Dear ${provider} Servicing Team,

RE: Letter of Authority - ${clientName} (${accountType})
Policy / Reference: ${policyNumber || 'Pending'}
Practice Ref: APFS-LOA-7731

We are writing on behalf of Adams and Poole Financial Services to chase the status of the signed Letter of Authority submitted for our mutual client, ${clientName}, ${daysOutstanding} days ago.

To allow us to complete our client suitability review, please urgently provide:
1. Current policy value & surrender/transfer value
2. Full fund allocation breakdown and underlying charges
3. Guarantees, penalties, or transfer restrictions

Please reply to paraplanning@adamsandpoolefs.co.uk at your earliest convenience.

Kind regards,
Paraplanning Department
Adams and Poole Financial Services`;
  }
}
