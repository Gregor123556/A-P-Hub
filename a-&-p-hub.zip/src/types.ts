/**
 * Core types for Adams & Poole Financial Services Practice Management Assistant
 */

export type ServiceScope = 'ISA & GIA' | 'CIB' | 'Pension';

export type AccountType = 'ISA & GIA' | 'CIB' | 'Pension' | 'Investment' | 'Bond';

export type LoAStatus = 'Pending' | 'Received' | 'Overdue' | 'Overdue + Chased';

export type SubmissionMethod = 'unipass' | 'post' | 'email';

export interface ProviderContact {
  id: string;
  name: string;
  mailingAddress: string;
  email: string;
  phone: string;
  bestSubmissionMethod: SubmissionMethod;
  avgTurnaroundDays: number;
  notes?: string;
}

export interface LoAEntry {
  id: string;
  clientName: string;
  accountType: AccountType;
  currentProvider: string;
  dateSent: string; // DD-MM-YYYY format
  dateDue: string; // DD-MM-YYYY format (14 days from Date Sent)
  chaseUpDate: string; // DD-MM-YYYY format (7 days before Date Due / 7 days after Date Sent)
  status: LoAStatus;
  policyNumber?: string;
  adviserName?: string;
  notes?: string;
  lastChasedDate?: string;
  createdAt: string;
}

export type ClientCategory = 'potential' | 'ongoing' | 'onboarded' | 'completed' | 'on_hold';

export interface ServicingClient {
  id: string;
  clientAdminId?: string;
  clientName: string;
  servicingStartDate: string; // DD-MM-YYYY (defaults to completion date of final admin stage)
  welcomeEmailSent: boolean;
  welcomeEmailSentDate?: string;
  welcomeCallDueDate: string; // DD-MM-YYYY (defaults to 1 week after servicing start date)
  welcomeCallCompleted?: boolean;
  welcomeCallCompletedDate?: string;
  sixMonthReviewDueDate: string; // DD-MM-YYYY (defaults to 6 months after servicing start date)
  sixMonthReviewCompleted?: boolean;
  sixMonthReviewCompletedDate?: string;
  oneYearReviewDueDate: string; // DD-MM-YYYY (defaults to 1 year after servicing start date)
  oneYearReviewCompleted?: boolean;
  oneYearReviewCompletedDate?: string;
  adviserName?: string;
  serviceType?: string;
  estimatedValue?: string;
  notes?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface ClientAdminStep {
  id: string;
  title: string;
  description?: string;
  isCompleted: boolean;
  completedAt?: string;
  completedBy?: string;
  dueDate?: string;
  notes?: string;
}

export interface FactFindPerson {
  fullName: string;
  dateOfBirth?: string; // DD-MM-YYYY or YYYY-MM-DD
  email?: string;
  phone?: string;
  address?: string;
}

export interface FactFindStage1 {
  hasSecondClient?: boolean;
  client1: FactFindPerson;
  client2?: FactFindPerson;
  meetingDate: string; // Defaults to today's date (DD-MM-YYYY)
  adviser: string; // e.g. 'Sam Adams' | 'Anthony Poole'
}

export type FactFindMaritalStatus = 
  | 'Single' 
  | 'Married' 
  | 'Civil Partner'
  | 'Cohabiting'
  | 'Divorced' 
  | 'Separated'
  | 'Widowed'
  | 'Other';

export type FactFindEmploymentStatus = 
  | 'Employed' 
  | 'Self-Employed' 
  | 'Director / Business Owner' 
  | 'Retired' 
  | 'Not Employed'
  | 'Other';

export interface FactFindIncomeStream {
  id?: string;
  employmentStatus: FactFindEmploymentStatus | string;
  employerBusiness: string;
  annualIncome: string;
  owner?: 'Client 1' | 'Client 2' | 'Joint' | string;
}

export type FactFindExpenditureType = 
  | 'Utilities' 
  | 'Rent/Mortgage' 
  | 'General Expenditure' 
  | 'Other';

export interface FactFindExpenditureItem {
  id?: string;
  expenditureType: FactFindExpenditureType | string;
  monthlyAmount: string;
  notes?: string;
}

export interface FactFindYesNoQuestion {
  answered: 'yes' | 'no' | '';
  details?: string;
}

export interface FactFindStage2Personal {
  vulnerability?: FactFindYesNoQuestion;
  pepSanctions?: FactFindYesNoQuestion;
  dependants?: FactFindYesNoQuestion;
  willInPlace?: FactFindYesNoQuestion;
  powerOfAttorney?: FactFindYesNoQuestion;
  expectedLifeChanges?: FactFindYesNoQuestion;
}

export interface FactFindStage2 extends FactFindStage2Personal {
  maritalStatus?: FactFindMaritalStatus;
  client1?: FactFindStage2Personal;
  client2?: FactFindStage2Personal;
}

export interface FactFindClientEmployment {
  employmentStatus?: FactFindEmploymentStatus | string;
  employer?: string;
  annualIncomeApprox?: string;
  monthlyExpenses?: string;
  otherIncome?: FactFindYesNoQuestion;
}

export interface FactFindStage3 {
  incomeStreams?: FactFindIncomeStream[];
  expenditureItems?: FactFindExpenditureItem[];
  monthlyExpenses?: string;
  client1?: FactFindClientEmployment;
  client2?: FactFindClientEmployment;
  employmentStatus?: FactFindEmploymentStatus | string;
  employer?: string;
  annualIncomeApprox?: string;
  otherIncome?: FactFindYesNoQuestion;
}

export type FactFindAssetType = 
  | 'Residential Property'
  | 'Additional Property'
  | 'Pension Pot'
  | 'Cash ISA'
  | 'Stock & Shares ISA'
  | 'Standard Savings Account'
  | 'Premium Bonds'
  | 'GIA'
  | 'Other';

export interface FactFindAssetItem {
  id?: string;
  assetType: FactFindAssetType | string;
  otherAssetType?: string;
  providerPlatform?: string;
  approxValue?: string;
  notes?: string;
  owner?: 'Client 1' | 'Client 2' | 'Joint' | string;
}

export type FactFindLiabilityType = 'Mortgage' | 'Car Loan' | 'Other';

export interface FactFindLiabilityItem {
  id?: string;
  liabilityType: FactFindLiabilityType | string;
  amountOutstanding?: string;
  monthlyRepayment?: string;
  notes?: string;
  owner?: 'Client 1' | 'Client 2' | 'Joint' | string;
}

export interface FactFindStage4 {
  assets: FactFindAssetItem[];
  totalApproxValue?: string;
  liabilities?: FactFindYesNoQuestion;
  liabilityItems?: FactFindLiabilityItem[];
  totalLiabilitiesValue?: string;
  notes?: string;
}

export interface FactFindGiftItem {
  id?: string;
  recipient: string;
  dateGifted: string;
  amountGifted: string;
}

export interface FactFindStage5Personal {
  availableLumpSum?: FactFindYesNoQuestion;
  availableMonthlyInvestment?: FactFindYesNoQuestion;
  isaAllowanceUsed?: FactFindYesNoQuestion;
  cgtAllowanceUsed?: FactFindYesNoQuestion;
  giftAllowanceUsed?: FactFindYesNoQuestion;
  gifts?: FactFindGiftItem[];
}

export interface FactFindStage5 extends FactFindStage5Personal {
  client1?: FactFindStage5Personal;
  client2?: FactFindStage5Personal;
  notes?: string;
}

export type FactFindPrimaryGoal = 'Growth' | 'Income' | 'Preservation' | 'IHT Planning';
export type FactFindTimeHorizon = '0-5 Years' | '5-10 Years' | '10+ Years';
export type FactFindAttitudeToRisk = 'Adventurous' | 'Dynamic' | 'Moderate' | 'Conservative';

export interface FactFindStage6 {
  // Objectives
  primaryGoal?: string;
  primaryGoals?: FactFindPrimaryGoal[];
  timeHorizon?: FactFindTimeHorizon | '';
  objective1: string;
  objective2: string;
  objective3?: string;
  hasObjective3?: boolean;

  // Risk and Investment Preferences
  attitudeToRisk?: FactFindAttitudeToRisk | '';
  ethicalEsgPreferences?: FactFindYesNoQuestion;
  notes?: string;
}

export interface FactFindStage7 {
  additionalNotes: string;
}

export interface ClientFactFind {
  status: 'not_started' | 'in_progress' | 'completed';
  currentStage: number; // 1, 2, 3, 4, 5, 6, 7, 8
  stage1: FactFindStage1;
  stage2?: FactFindStage2;
  stage3?: FactFindStage3;
  stage4?: FactFindStage4;
  stage5?: FactFindStage5;
  stage6?: FactFindStage6;
  stage7?: FactFindStage7;
  updatedAt?: string;
  completedAt?: string;
}

export interface ClientAdminEntry {
  id: string;
  clientName: string;
  category: ClientCategory; // 'potential' | 'ongoing' | 'on_hold' | 'onboarded' | 'completed'
  adviserName: string; // 'Sam Adams' | 'Anthony Poole'
  serviceType: string; // e.g. 'Retirement Planning & SIPP', 'Wealth Management', etc.
  estimatedValue?: string; // e.g. '£380,000'
  
  // Potential Clients specific fields & Fact Find
  potentialSelectedFund?: string; // e.g. 'Vanguard LifeStrategy 60% Equity'
  proposedFeeInitial?: string; // Default '3%'
  proposedFeeOngoing?: string; // Default '1%'
  factFind?: ClientFactFind;

  signUpDate?: string; // DD-MM-YYYY
  targetCompletionDate?: string; // DD-MM-YYYY
  onHoldReason?: string; // e.g. 'Awaiting Grant of Probate'
  nextAction?: string;
  nextActionDueDate?: string; // DD-MM-YYYY
  
  // Onboarded specific checklist fields
  moneyLanded?: boolean;
  moneyLandedDate?: string; // DD-MM-YYYY
  servicingSetUp?: boolean;
  servicingSetUpDate?: string; // DD-MM-YYYY

  email?: string;
  phone?: string;
  steps: ClientAdminStep[];
  notes?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface ParseLoAResponse {
  action: 'create' | 'update' | 'unknown';
  clientName?: string;
  accountType?: AccountType;
  currentProvider?: string;
  dateSent?: string;
  policyNumber?: string;
  notes?: string;
  newStatus?: LoAStatus;
  targetClientName?: string;
  targetProvider?: string;
  targetAccountType?: AccountType;
  explanation: string;
}

export interface ProviderSLAInfo {
  provider: string;
  avgTurnaroundDays: number;
  totalActive: number;
  overdueCount: number;
  contactEmail: string;
  phone: string;
}
