import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  getDocs,
  writeBatch
} from 'firebase/firestore';
import { db } from '../firebase';
import { LoAEntry, LoAStatus } from '../types';
import { INITIAL_LOAS } from '../data/mockData';

const COLLECTION_NAME = 'loas';
let isSeeding = false;

/**
 * Sanitizes an LoA object to ensure no `undefined` values exist (which Firestore forbids).
 */
function sanitizeLoAData(entryData: Partial<LoAEntry>): Record<string, any> {
  return {
    clientName: (entryData.clientName || '').trim(),
    accountType: entryData.accountType || 'Pension',
    currentProvider: (entryData.currentProvider || '').trim(),
    dateSent: (entryData.dateSent || '').trim(),
    dateDue: (entryData.dateDue || '').trim(),
    chaseUpDate: (entryData.chaseUpDate || '').trim(),
    status: (entryData.status as LoAStatus) || 'Pending',
    policyNumber: (entryData.policyNumber || '').trim(),
    adviserName: (entryData.adviserName || 'Sam Adams').trim(),
    notes: (entryData.notes || '').trim(),
    lastChasedDate: (entryData.lastChasedDate || '').trim()
  };
}

/**
 * Initializes Firestore with the initial Adams & Poole practice entries if the collection is empty.
 */
export async function initializeFirestoreIfEmpty(): Promise<void> {
  if (isSeeding) return;
  isSeeding = true;

  try {
    const snapshot = await getDocs(collection(db, COLLECTION_NAME));
    if (snapshot.empty) {
      console.log('Firestore is empty, seeding initial practice dataset...');
      const batch = writeBatch(db);
      for (const item of INITIAL_LOAS) {
        const itemDoc = doc(db, COLLECTION_NAME, item.id);
        const sanitized = sanitizeLoAData(item);
        batch.set(itemDoc, {
          ...sanitized,
          id: itemDoc.id,
          createdAt: item.createdAt || new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
      }
      await batch.commit();
      console.log('Successfully seeded initial LOAs to Firestore.');
    }
  } catch (error) {
    console.error('Error during Firestore initialization:', error);
  } finally {
    isSeeding = false;
  }
}

/**
 * Subscribes to real-time updates for all LoA entries across all users in the practice.
 */
export function subscribeToLoAs(
  onUpdate: (loas: LoAEntry[]) => void,
  onError?: (error: Error) => void
): () => void {
  const loasCollection = collection(db, COLLECTION_NAME);

  const unsubscribe = onSnapshot(
    loasCollection,
    (snapshot) => {
      if (snapshot.empty) {
        // If collection is completely empty, initialize it
        initializeFirestoreIfEmpty().catch(console.error);
        onUpdate([]);
        return;
      }

      const entries: LoAEntry[] = snapshot.docs.map((docSnap) => {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          clientName: data.clientName || '',
          accountType: data.accountType || 'Pension',
          currentProvider: data.currentProvider || '',
          dateSent: data.dateSent || '',
          dateDue: data.dateDue || '',
          chaseUpDate: data.chaseUpDate || '',
          status: (data.status as LoAStatus) || 'Pending',
          policyNumber: data.policyNumber || '',
          adviserName: data.adviserName || 'Sam Adams',
          notes: data.notes || '',
          lastChasedDate: data.lastChasedDate || '',
          createdAt: data.createdAt || new Date().toISOString()
        };
      });

      // Sort by creation time or dateSent descending
      entries.sort((a, b) => {
        const timeA = new Date(a.createdAt).getTime() || 0;
        const timeB = new Date(b.createdAt).getTime() || 0;
        return timeB - timeA;
      });

      onUpdate(entries);
    },
    (err) => {
      console.error('Firestore real-time subscription error:', err);
      if (onError) onError(err);
    }
  );

  return unsubscribe;
}

/**
 * Creates a new LoA record in Firestore.
 */
export async function createLoA(entryData: Omit<LoAEntry, 'id' | 'createdAt'>): Promise<string> {
  const docRef = doc(collection(db, COLLECTION_NAME));
  const sanitized = sanitizeLoAData(entryData);
  const now = new Date().toISOString();

  const newDocData = {
    ...sanitized,
    id: docRef.id,
    createdAt: now,
    updatedAt: now
  };

  await setDoc(docRef, newDocData);
  return docRef.id;
}

/**
 * Updates an existing LoA record in Firestore with merge enabled.
 */
export async function updateLoA(id: string, updates: Partial<LoAEntry>): Promise<void> {
  const docRef = doc(db, COLLECTION_NAME, id);
  const cleanUpdates: Record<string, any> = {
    id,
    updatedAt: new Date().toISOString()
  };

  for (const [key, value] of Object.entries(updates)) {
    if (value !== undefined) {
      cleanUpdates[key] = typeof value === 'string' ? value.trim() : value;
    }
  }

  await setDoc(docRef, cleanUpdates, { merge: true });
}

/**
 * Deletes an LoA record from Firestore across all user sessions.
 */
export async function deleteLoA(id: string): Promise<void> {
  const docRef = doc(db, COLLECTION_NAME, id);
  await deleteDoc(docRef);
}

/**
 * Updates LoA status by client name and provider matching (for natural language assistant).
 */
export async function updateLoAStatusByMatch(
  clientName: string,
  provider: string,
  newStatus: LoAStatus,
  currentLoas: LoAEntry[]
): Promise<boolean> {
  const clientLower = clientName.toLowerCase().trim();
  const providerLower = provider.toLowerCase().trim();

  const matched = currentLoas.find((item) => {
    const matchClient =
      item.clientName.toLowerCase().includes(clientLower) ||
      clientLower.includes(item.clientName.toLowerCase());
    const matchProvider =
      item.currentProvider.toLowerCase().includes(providerLower) ||
      providerLower.includes(item.currentProvider.toLowerCase());
    return matchClient && matchProvider;
  });

  if (matched) {
    await updateLoA(matched.id, { status: newStatus });
    return true;
  }

  return false;
}

/**
 * Resets the practice Firestore collection to the default initial mock dataset.
 */
export async function resetLoAsToInitial(): Promise<void> {
  const snapshot = await getDocs(collection(db, COLLECTION_NAME));
  const batch = writeBatch(db);

  // Delete existing documents
  snapshot.docs.forEach((d) => batch.delete(d.ref));

  // Re-insert standard practice records
  INITIAL_LOAS.forEach((item) => {
    const newDoc = doc(db, COLLECTION_NAME, item.id);
    const sanitized = sanitizeLoAData(item);
    batch.set(newDoc, {
      ...sanitized,
      id: newDoc.id,
      createdAt: item.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
  });

  await batch.commit();
}
