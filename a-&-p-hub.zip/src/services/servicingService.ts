import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  getDocs,
  writeBatch
} from 'firebase/firestore';
import { db } from '../firebase';
import { ServicingClient, ClientAdminEntry } from '../types';
import { calculateServicingDates, getTodayDDMMYYYY, formatDDMMYYYY } from '../utils/dateUtils';

const COLLECTION_NAME = 'servicingClients';
const STORAGE_KEY = 'adams_poole_servicing_clients';

let isSeeding = false;
const activeListeners = new Set<(clients: ServicingClient[]) => void>();

function notifySubscribers(clients: ServicingClient[]): void {
  activeListeners.forEach(callback => {
    try {
      callback(clients);
    } catch (e) {
      console.error('Error notifying servicing subscriber:', e);
    }
  });
}

export function getStoredServicingClients(): ServicingClient[] {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Failed to read servicing clients from localStorage:', e);
  }
  return INITIAL_SERVICING_CLIENTS;
}

export function saveStoredServicingClients(clients: ServicingClient[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(clients));
  } catch (e) {
    console.warn('Failed to save servicing clients to localStorage:', e);
  }
}

// Initial mock data for Servicing tab to showcase functionality immediately
const today = new Date();
const daysAgo = (days: number) => {
  const d = new Date(today);
  d.setDate(d.getDate() - days);
  return formatDDMMYYYY(d);
};

const initialStart1 = daysAgo(14);
const initialDates1 = calculateServicingDates(initialStart1);

export const INITIAL_SERVICING_CLIENTS: ServicingClient[] = [
  {
    id: 'servicing-1',
    clientAdminId: 'client-ong-demo-1',
    clientName: 'Geoffrey & Diane Harper',
    servicingStartDate: initialStart1,
    welcomeEmailSent: true,
    welcomeEmailSentDate: daysAgo(13),
    welcomeCallDueDate: initialDates1.welcomeCallDueDate,
    welcomeCallCompleted: true,
    welcomeCallCompletedDate: daysAgo(7),
    sixMonthReviewDueDate: initialDates1.sixMonthReviewDueDate,
    sixMonthReviewCompleted: false,
    oneYearReviewDueDate: initialDates1.oneYearReviewDueDate,
    oneYearReviewCompleted: false,
    adviserName: 'Sam Adams',
    serviceType: 'Pension & ISA',
    estimatedValue: '£720,000',
    notes: 'All onboarding & admin milestones completed. Portfolio transferred to Aviva SIPP & Wrap ISA successfully.',
    createdAt: new Date().toISOString()
  }
];

function sanitizeServicingData(entry: Partial<ServicingClient>): Record<string, any> {
  return {
    clientName: (entry.clientName || '').trim(),
    clientAdminId: entry.clientAdminId || '',
    servicingStartDate: entry.servicingStartDate || getTodayDDMMYYYY(),
    welcomeEmailSent: Boolean(entry.welcomeEmailSent),
    welcomeEmailSentDate: entry.welcomeEmailSentDate || '',
    welcomeCallDueDate: entry.welcomeCallDueDate || '',
    welcomeCallCompleted: Boolean(entry.welcomeCallCompleted),
    welcomeCallCompletedDate: entry.welcomeCallCompletedDate || '',
    sixMonthReviewDueDate: entry.sixMonthReviewDueDate || '',
    sixMonthReviewCompleted: Boolean(entry.sixMonthReviewCompleted),
    sixMonthReviewCompletedDate: entry.sixMonthReviewCompletedDate || '',
    oneYearReviewDueDate: entry.oneYearReviewDueDate || '',
    oneYearReviewCompleted: Boolean(entry.oneYearReviewCompleted),
    oneYearReviewCompletedDate: entry.oneYearReviewCompletedDate || '',
    adviserName: (entry.adviserName || 'Sam Adams').trim(),
    serviceType: (entry.serviceType || 'Pension').trim(),
    estimatedValue: (entry.estimatedValue || '').trim(),
    notes: (entry.notes || '').trim()
  };
}

/**
 * Initializes Firestore with default servicing clients if empty.
 */
export async function initializeServicingIfEmpty(): Promise<void> {
  if (isSeeding) return;
  isSeeding = true;

  try {
    const snapshot = await getDocs(collection(db, COLLECTION_NAME));
    if (snapshot.empty) {
      console.log('Firestore servicingClients is empty, seeding initial datasets...');
      const batch = writeBatch(db);
      for (const item of INITIAL_SERVICING_CLIENTS) {
        const itemDoc = doc(db, COLLECTION_NAME, item.id);
        const sanitized = sanitizeServicingData(item);
        batch.set(itemDoc, {
          ...sanitized,
          id: itemDoc.id,
          createdAt: item.createdAt || new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
      }
      await batch.commit();
      console.log('Successfully seeded initial servicingClients to Firestore.');
    }
  } catch (error) {
    console.error('Error during Firestore servicingClients initialization:', error);
  } finally {
    isSeeding = false;
  }
}

/**
 * Subscribes to real-time updates for Servicing clients.
 */
export function subscribeToServicingClients(
  onUpdate: (clients: ServicingClient[]) => void,
  onError?: (error: Error) => void
): () => void {
  activeListeners.add(onUpdate);

  // Send current stored state immediately
  onUpdate(getStoredServicingClients());

  const servicingCollection = collection(db, COLLECTION_NAME);

  const unsubscribe = onSnapshot(
    servicingCollection,
    (snapshot) => {
      if (snapshot.empty) {
        const fallback = getStoredServicingClients();
        if (!fallback || fallback.length === 0) {
          initializeServicingIfEmpty().catch(console.error);
        }
        notifySubscribers(fallback);
        return;
      }

      const entries: ServicingClient[] = snapshot.docs.map((docSnap) => {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          clientAdminId: data.clientAdminId || '',
          clientName: data.clientName || 'Unnamed Client',
          servicingStartDate: data.servicingStartDate || getTodayDDMMYYYY(),
          welcomeEmailSent: Boolean(data.welcomeEmailSent),
          welcomeEmailSentDate: data.welcomeEmailSentDate || '',
          welcomeCallDueDate: data.welcomeCallDueDate || '',
          welcomeCallCompleted: Boolean(data.welcomeCallCompleted),
          welcomeCallCompletedDate: data.welcomeCallCompletedDate || '',
          sixMonthReviewDueDate: data.sixMonthReviewDueDate || '',
          sixMonthReviewCompleted: Boolean(data.sixMonthReviewCompleted),
          sixMonthReviewCompletedDate: data.sixMonthReviewCompletedDate || '',
          oneYearReviewDueDate: data.oneYearReviewDueDate || '',
          oneYearReviewCompleted: Boolean(data.oneYearReviewCompleted),
          oneYearReviewCompletedDate: data.oneYearReviewCompletedDate || '',
          adviserName: data.adviserName || 'Sam Adams',
          serviceType: data.serviceType || 'Pension',
          estimatedValue: data.estimatedValue || '',
          notes: data.notes || '',
          createdAt: data.createdAt || new Date().toISOString(),
          updatedAt: data.updatedAt || new Date().toISOString()
        };
      });

      // Sort by servicing start date / creation time descending
      entries.sort((a, b) => {
        const timeA = new Date(a.createdAt).getTime() || 0;
        const timeB = new Date(b.createdAt).getTime() || 0;
        return timeB - timeA;
      });

      saveStoredServicingClients(entries);
      notifySubscribers(entries);
    },
    (error) => {
      console.error('Firestore servicingClients subscription error:', error);
      if (onError) onError(error);
      const fallback = getStoredServicingClients();
      notifySubscribers(fallback);
    }
  );

  return () => {
    activeListeners.delete(onUpdate);
    unsubscribe();
  };
}

/**
 * Creates or feeds a client into the Servicing pipeline once all ongoing admin stages are complete.
 */
export async function feedClientToServicing(
  clientAdmin: ClientAdminEntry,
  completionDate?: string
): Promise<string> {
  const startDate = completionDate || getTodayDDMMYYYY();
  const dates = calculateServicingDates(startDate);

  const existing = getStoredServicingClients();
  // Check if this client is already in servicing by clientAdminId or name
  const matched = existing.find(
    s => (clientAdmin.id && s.clientAdminId === clientAdmin.id) ||
         s.clientName.trim().toLowerCase() === clientAdmin.clientName.trim().toLowerCase()
  );

  if (matched) {
    // Update existing record if needed
    await updateServicingClient(matched.id, {
      servicingStartDate: startDate,
      welcomeCallDueDate: dates.welcomeCallDueDate,
      sixMonthReviewDueDate: dates.sixMonthReviewDueDate,
      oneYearReviewDueDate: dates.oneYearReviewDueDate,
      adviserName: clientAdmin.adviserName,
      serviceType: clientAdmin.serviceType,
      estimatedValue: clientAdmin.estimatedValue
    });
    return matched.id;
  }

  const collectionRef = collection(db, COLLECTION_NAME);
  const docRef = doc(collectionRef);
  const now = new Date().toISOString();

  const newEntry: ServicingClient = {
    id: docRef.id,
    clientAdminId: clientAdmin.id,
    clientName: clientAdmin.clientName,
    servicingStartDate: startDate,
    welcomeEmailSent: false,
    welcomeCallDueDate: dates.welcomeCallDueDate,
    welcomeCallCompleted: false,
    sixMonthReviewDueDate: dates.sixMonthReviewDueDate,
    sixMonthReviewCompleted: false,
    oneYearReviewDueDate: dates.oneYearReviewDueDate,
    oneYearReviewCompleted: false,
    adviserName: clientAdmin.adviserName || 'Sam Adams',
    serviceType: clientAdmin.serviceType || 'Pension',
    estimatedValue: clientAdmin.estimatedValue || '',
    notes: clientAdmin.notes || '',
    createdAt: now,
    updatedAt: now
  };

  const updated = [newEntry, ...existing];
  saveStoredServicingClients(updated);
  notifySubscribers(updated);

  try {
    const sanitized = sanitizeServicingData(newEntry);
    await setDoc(docRef, {
      ...sanitized,
      id: docRef.id,
      createdAt: now,
      updatedAt: now
    });
  } catch (err) {
    console.error('Failed to create servicing record in Firestore:', err);
  }

  return docRef.id;
}

/**
 * Updates a servicing client record.
 */
export async function updateServicingClient(
  id: string,
  updates: Partial<ServicingClient>
): Promise<void> {
  const existing = getStoredServicingClients();
  const current = existing.find(c => c.id === id);

  const cleanUpdates: Record<string, any> = {
    updatedAt: new Date().toISOString()
  };

  for (const [key, val] of Object.entries(updates)) {
    if (val !== undefined && key !== 'id') {
      cleanUpdates[key] = val;
    }
  }

  // If servicingStartDate changed, recalculate default due dates if they were not explicitly updated
  if (updates.servicingStartDate && updates.servicingStartDate !== current?.servicingStartDate) {
    const newDates = calculateServicingDates(updates.servicingStartDate);
    if (!updates.welcomeCallDueDate) cleanUpdates.welcomeCallDueDate = newDates.welcomeCallDueDate;
    if (!updates.sixMonthReviewDueDate) cleanUpdates.sixMonthReviewDueDate = newDates.sixMonthReviewDueDate;
    if (!updates.oneYearReviewDueDate) cleanUpdates.oneYearReviewDueDate = newDates.oneYearReviewDueDate;
  }

  // Optimistic update
  const updated = existing.map(c => (c.id === id ? { ...c, ...cleanUpdates } : c));
  saveStoredServicingClients(updated);
  notifySubscribers(updated);

  try {
    const docRef = doc(db, COLLECTION_NAME, id);
    await setDoc(docRef, cleanUpdates, { merge: true });
  } catch (err) {
    console.error('Failed to update servicing record in Firestore:', err);
  }
}

/**
 * Deletes a servicing client record.
 */
export async function deleteServicingClient(id: string): Promise<void> {
  const existing = getStoredServicingClients();
  const updated = existing.filter(c => c.id !== id);
  saveStoredServicingClients(updated);
  notifySubscribers(updated);

  try {
    const docRef = doc(db, COLLECTION_NAME, id);
    await deleteDoc(docRef);
  } catch (err) {
    console.error('Failed to delete servicing record in Firestore:', err);
  }
}
