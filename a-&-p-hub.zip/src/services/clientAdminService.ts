import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  getDocs,
  writeBatch
} from 'firebase/firestore';
import { db } from '../firebase';
import { ClientAdminEntry, ClientAdminStep, ClientCategory, ClientFactFind } from '../types';
import { INITIAL_CLIENT_ADMIN, generateStepsForCategory, normalizeOngoingMilestones } from '../data/mockClientAdmin';
import { feedClientToServicing } from './servicingService';

const COLLECTION_NAME = 'clientAdmin';
const STORAGE_KEY = 'adams_poole_client_admin';
let isSeeding = false;

const activeListeners = new Set<(clients: ClientAdminEntry[]) => void>();

function notifySubscribers(clients: ClientAdminEntry[]): void {
  activeListeners.forEach(callback => {
    try {
      callback(clients);
    } catch (e) {
      console.error('Error notifying clientAdmin subscriber:', e);
    }
  });
}

export function getStoredClients(): ClientAdminEntry[] {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) {
        const existingIds = new Set(parsed.map((c: any) => c.id));
        const missingInitial = INITIAL_CLIENT_ADMIN.filter(c => !existingIds.has(c.id));
        const combined = [...parsed, ...missingInitial];
        return combined.map((client: ClientAdminEntry) => {
          if (client.category === 'ongoing') {
            return {
              ...client,
              steps: normalizeOngoingMilestones(client.steps, client.id)
            };
          }
          return client;
        });
      }
    }
  } catch (e) {
    console.warn('Failed to read clients from localStorage:', e);
  }
  return INITIAL_CLIENT_ADMIN.map((client) => {
    if (client.category === 'ongoing') {
      return {
        ...client,
        steps: normalizeOngoingMilestones(client.steps, client.id)
      };
    }
    return client;
  });
}

export function saveStoredClients(clients: ClientAdminEntry[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(clients));
  } catch (e) {
    console.warn('Failed to save clients to localStorage:', e);
  }
}

/**
 * Recursively removes all undefined keys/values from an object to prevent Firestore setDoc errors.
 */
export function removeUndefinedDeep<T>(obj: T): T {
  if (obj === null || obj === undefined) {
    return obj;
  }
  if (Array.isArray(obj)) {
    return obj.map(item => removeUndefinedDeep(item)) as unknown as T;
  }
  if (typeof obj === 'object') {
    const cleaned: Record<string, any> = {};
    for (const [key, value] of Object.entries(obj)) {
      if (value !== undefined) {
        cleaned[key] = removeUndefinedDeep(value);
      }
    }
    return cleaned as unknown as T;
  }
  return obj;
}

/**
 * Sanitizes ClientAdminEntry before writing to Firestore
 */
function sanitizeClientData(entry: Partial<ClientAdminEntry>): Record<string, any> {
  const result: Record<string, any> = {
    clientName: (entry.clientName || '').trim(),
    category: (entry.category as ClientCategory) || 'potential',
    adviserName: (entry.adviserName || 'Sam Adams').trim(),
    serviceType: (entry.serviceType || 'Pension').trim(),
    estimatedValue: (entry.estimatedValue || '').trim(),
    potentialSelectedFund: (entry.potentialSelectedFund || '').trim(),
    proposedFeeInitial: (entry.proposedFeeInitial || '3%').trim(),
    proposedFeeOngoing: (entry.proposedFeeOngoing || '1%').trim(),
    signUpDate: (entry.signUpDate || '').trim(),
    targetCompletionDate: (entry.targetCompletionDate || '').trim(),
    onHoldReason: (entry.onHoldReason || '').trim(),
    nextAction: (entry.nextAction || '').trim(),
    nextActionDueDate: (entry.nextActionDueDate || '').trim(),
    moneyLanded: Boolean(entry.moneyLanded),
    moneyLandedDate: (entry.moneyLandedDate || '').trim(),
    servicingSetUp: Boolean(entry.servicingSetUp),
    servicingSetUpDate: (entry.servicingSetUpDate || '').trim(),
    email: (entry.email || '').trim(),
    phone: (entry.phone || '').trim(),
    notes: (entry.notes || '').trim(),
    steps: Array.isArray(entry.steps) ? entry.steps.map(step => ({
      id: step.id || `step-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      title: step.title || '',
      description: step.description || '',
      isCompleted: Boolean(step.isCompleted),
      completedAt: step.completedAt || '',
      completedBy: step.completedBy || '',
      dueDate: step.dueDate || '',
      notes: step.notes || ''
    })) : []
  };

  if (entry.factFind) {
    const stage1Obj: Record<string, any> = {
      hasSecondClient: Boolean(entry.factFind.stage1?.hasSecondClient),
      client1: {
        fullName: (entry.factFind.stage1?.client1?.fullName || '').trim(),
        dateOfBirth: (entry.factFind.stage1?.client1?.dateOfBirth || '').trim(),
        email: (entry.factFind.stage1?.client1?.email || '').trim(),
        phone: (entry.factFind.stage1?.client1?.phone || '').trim(),
        address: (entry.factFind.stage1?.client1?.address || '').trim()
      },
      meetingDate: (entry.factFind.stage1?.meetingDate || '').trim(),
      adviser: (entry.factFind.stage1?.adviser || 'Sam Adams').trim()
    };

    if (entry.factFind.stage1?.hasSecondClient && entry.factFind.stage1?.client2) {
      stage1Obj.client2 = {
        fullName: (entry.factFind.stage1.client2.fullName || '').trim(),
        dateOfBirth: (entry.factFind.stage1.client2.dateOfBirth || '').trim(),
        email: (entry.factFind.stage1.client2.email || '').trim(),
        phone: (entry.factFind.stage1.client2.phone || '').trim(),
        address: (entry.factFind.stage1.client2.address || '').trim()
      };
    }

    result.factFind = {
      status: entry.factFind.status || 'not_started',
      currentStage: entry.factFind.currentStage || 1,
      stage1: stage1Obj,
      stage2: entry.factFind.stage2 ? {
        maritalStatus: entry.factFind.stage2.maritalStatus || '',
        vulnerability: {
          answered: entry.factFind.stage2.vulnerability?.answered || '',
          details: (entry.factFind.stage2.vulnerability?.details || '').trim()
        },
        pepSanctions: {
          answered: entry.factFind.stage2.pepSanctions?.answered || '',
          details: (entry.factFind.stage2.pepSanctions?.details || '').trim()
        },
        dependants: {
          answered: entry.factFind.stage2.dependants?.answered || '',
          details: (entry.factFind.stage2.dependants?.details || '').trim()
        },
        willInPlace: {
          answered: entry.factFind.stage2.willInPlace?.answered || '',
          details: (entry.factFind.stage2.willInPlace?.details || '').trim()
        },
        powerOfAttorney: {
          answered: entry.factFind.stage2.powerOfAttorney?.answered || '',
          details: (entry.factFind.stage2.powerOfAttorney?.details || '').trim()
        },
        expectedLifeChanges: {
          answered: entry.factFind.stage2.expectedLifeChanges?.answered || '',
          details: (entry.factFind.stage2.expectedLifeChanges?.details || '').trim()
        }
      } : {},
      stage3: entry.factFind.stage3 ? {
        incomeStreams: Array.isArray(entry.factFind.stage3.incomeStreams)
          ? entry.factFind.stage3.incomeStreams.map((stream: any) => ({
              id: stream.id || '',
              employmentStatus: (stream.employmentStatus || 'Employed').trim(),
              employerBusiness: (stream.employerBusiness || '').trim(),
              annualIncome: (stream.annualIncome || '').trim(),
              owner: stream.owner || undefined
            }))
          : undefined,
        expenditureItems: Array.isArray(entry.factFind.stage3.expenditureItems)
          ? entry.factFind.stage3.expenditureItems.map((item: any) => ({
              id: item.id || '',
              expenditureType: (item.expenditureType || 'General Expenditure').trim(),
              monthlyAmount: (item.monthlyAmount || '').trim(),
              notes: (item.notes || '').trim()
            }))
          : undefined,
        monthlyExpenses: (entry.factFind.stage3.monthlyExpenses || '').trim(),
        employmentStatus: (entry.factFind.stage3.employmentStatus || '').trim(),
        employer: (entry.factFind.stage3.employer || '').trim(),
        annualIncomeApprox: (entry.factFind.stage3.annualIncomeApprox || '').trim(),
        otherIncome: entry.factFind.stage3.otherIncome ? {
          answered: entry.factFind.stage3.otherIncome.answered || '',
          details: (entry.factFind.stage3.otherIncome.details || '').trim()
        } : undefined,
        client1: entry.factFind.stage3.client1 ? {
          employmentStatus: (entry.factFind.stage3.client1.employmentStatus || '').trim(),
          employer: (entry.factFind.stage3.client1.employer || '').trim(),
          annualIncomeApprox: (entry.factFind.stage3.client1.annualIncomeApprox || '').trim(),
          monthlyExpenses: (entry.factFind.stage3.client1.monthlyExpenses || '').trim(),
          otherIncome: {
            answered: entry.factFind.stage3.client1.otherIncome?.answered || '',
            details: (entry.factFind.stage3.client1.otherIncome?.details || '').trim()
          }
        } : undefined,
        client2: entry.factFind.stage3.client2 ? {
          employmentStatus: (entry.factFind.stage3.client2.employmentStatus || '').trim(),
          employer: (entry.factFind.stage3.client2.employer || '').trim(),
          annualIncomeApprox: (entry.factFind.stage3.client2.annualIncomeApprox || '').trim(),
          monthlyExpenses: (entry.factFind.stage3.client2.monthlyExpenses || '').trim(),
          otherIncome: {
            answered: entry.factFind.stage3.client2.otherIncome?.answered || '',
            details: (entry.factFind.stage3.client2.otherIncome?.details || '').trim()
          }
        } : undefined
      } : {},
      stage4: entry.factFind.stage4 ? {
        assets: Array.isArray(entry.factFind.stage4.assets)
          ? entry.factFind.stage4.assets.map((asset: any) => ({
              id: asset.id || '',
              assetType: (asset.assetType || 'Residential Property').trim(),
              otherAssetType: (asset.otherAssetType || '').trim(),
              providerPlatform: (asset.providerPlatform || '').trim(),
              approxValue: (asset.approxValue || '').trim(),
              notes: (asset.notes || '').trim(),
              owner: (asset.owner || 'Client 1').trim()
            }))
          : [],
        totalApproxValue: (entry.factFind.stage4.totalApproxValue || '').trim(),
        liabilities: entry.factFind.stage4.liabilities ? {
          answered: entry.factFind.stage4.liabilities.answered || '',
          details: (entry.factFind.stage4.liabilities.details || '').trim()
        } : undefined,
        liabilityItems: Array.isArray(entry.factFind.stage4.liabilityItems)
          ? entry.factFind.stage4.liabilityItems.map((item: any) => ({
              id: item.id || '',
              liabilityType: (item.liabilityType || 'Mortgage').trim(),
              amountOutstanding: (item.amountOutstanding || '').trim(),
              monthlyRepayment: (item.monthlyRepayment || '').trim(),
              notes: (item.notes || '').trim(),
              owner: (item.owner || 'Client 1').trim()
            }))
          : undefined,
        totalLiabilitiesValue: (entry.factFind.stage4.totalLiabilitiesValue || '').trim(),
        notes: (entry.factFind.stage4.notes || '').trim()
      } : {},
      updatedAt: entry.factFind.updatedAt || new Date().toISOString(),
      completedAt: entry.factFind.completedAt || ''
    };
  }

  return removeUndefinedDeep(result);
}

/**
 * Initializes Firestore with default client administrative workflows if empty.
 */
export async function initializeClientAdminIfEmpty(): Promise<void> {
  if (isSeeding) return;
  isSeeding = true;

  try {
    const snapshot = await getDocs(collection(db, COLLECTION_NAME));
    if (snapshot.empty) {
      console.log('Firestore clientAdmin is empty, seeding initial datasets...');
      const batch = writeBatch(db);
      for (const item of INITIAL_CLIENT_ADMIN) {
        const itemDoc = doc(db, COLLECTION_NAME, item.id);
        const sanitized = sanitizeClientData(item);
        batch.set(itemDoc, {
          ...sanitized,
          id: itemDoc.id,
          createdAt: item.createdAt || new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
      }
      await batch.commit();
      console.log('Successfully seeded initial clientAdmin records to Firestore.');
    }
  } catch (error) {
    console.error('Error during Firestore clientAdmin initialization:', error);
  } finally {
    isSeeding = false;
  }
}

/**
 * Subscribes to real-time updates for Client Admin tracking.
 */
export function subscribeToClientAdmin(
  onUpdate: (clients: ClientAdminEntry[]) => void,
  onError?: (error: Error) => void
): () => void {
  activeListeners.add(onUpdate);

  // Send current stored state immediately
  onUpdate(getStoredClients());

  const clientAdminCollection = collection(db, COLLECTION_NAME);

  const unsubscribe = onSnapshot(
    clientAdminCollection,
    (snapshot) => {
      if (snapshot.empty) {
        const fallback = getStoredClients();
        if (!fallback || fallback.length === 0) {
          initializeClientAdminIfEmpty().catch(console.error);
        }
        notifySubscribers(fallback);
        return;
      }

      const entries: ClientAdminEntry[] = snapshot.docs.map((docSnap) => {
        const data = docSnap.data();
        const initialMatch = INITIAL_CLIENT_ADMIN.find((i) => i.id === docSnap.id);
        const storedMatch = getStoredClients().find((s) => s.id === docSnap.id);
        
        let clientName = (data.clientName || '').trim();
        if (!clientName) {
          clientName = initialMatch?.clientName || storedMatch?.clientName || 'Client';
          // Repair Firestore document if name was previously wiped
          setDoc(docSnap.ref, { clientName }, { merge: true }).catch(console.warn);
        }

        const category = (data.category as ClientCategory) || 'potential';
        let rawSteps = Array.isArray(data.steps) ? data.steps : (initialMatch?.steps || []);
        const steps = category === 'ongoing' ? normalizeOngoingMilestones(rawSteps, docSnap.id) : rawSteps;

        // If ongoing client was using legacy milestones, update Firestore in background
        if (category === 'ongoing' && Array.isArray(data.steps)) {
          const needsMilestoneMigration = data.steps.length !== 9 || data.steps.some((s: any, idx: number) => s.title !== steps[idx]?.title);
          if (needsMilestoneMigration) {
            setDoc(docSnap.ref, { steps }, { merge: true }).catch(console.warn);
          }
        }

        return {
          id: docSnap.id,
          clientName,
          category,
          adviserName: data.adviserName || initialMatch?.adviserName || 'Sam Adams',
          serviceType: data.serviceType || initialMatch?.serviceType || 'Pension',
          estimatedValue: data.estimatedValue || initialMatch?.estimatedValue || '',
          potentialSelectedFund: data.potentialSelectedFund || initialMatch?.potentialSelectedFund || '',
          proposedFeeInitial: data.proposedFeeInitial || initialMatch?.proposedFeeInitial || '3%',
          proposedFeeOngoing: data.proposedFeeOngoing || initialMatch?.proposedFeeOngoing || '1%',
          factFind: data.factFind || initialMatch?.factFind || storedMatch?.factFind,
          signUpDate: data.signUpDate || '',
          targetCompletionDate: data.targetCompletionDate || '',
          onHoldReason: data.onHoldReason || '',
          nextAction: data.nextAction || '',
          nextActionDueDate: data.nextActionDueDate || '',
          moneyLanded: typeof data.moneyLanded === 'boolean' ? data.moneyLanded : (initialMatch?.moneyLanded ?? false),
          moneyLandedDate: data.moneyLandedDate || initialMatch?.moneyLandedDate || '',
          servicingSetUp: typeof data.servicingSetUp === 'boolean' ? data.servicingSetUp : (initialMatch?.servicingSetUp ?? false),
          servicingSetUpDate: data.servicingSetUpDate || initialMatch?.servicingSetUpDate || '',
          email: data.email || initialMatch?.email || '',
          phone: data.phone || initialMatch?.phone || '',
          notes: data.notes || '',
          steps,
          createdAt: data.createdAt || new Date().toISOString(),
          updatedAt: data.updatedAt || new Date().toISOString()
        };
      });

      // Sort by creation time descending
      entries.sort((a, b) => {
        const timeA = new Date(a.createdAt).getTime() || 0;
        const timeB = new Date(b.createdAt).getTime() || 0;
        return timeB - timeA;
      });

      saveStoredClients(entries);
      notifySubscribers(entries);
    },
    (error) => {
      console.error('Firestore clientAdmin subscription error:', error);
      if (onError) onError(error);
      const fallback = getStoredClients();
      notifySubscribers(fallback);
    }
  );

  return () => {
    activeListeners.delete(onUpdate);
    unsubscribe();
  };
}

/**
 * Creates a new client admin tracking record.
 */
export async function createClient(
  clientData: Omit<ClientAdminEntry, 'id' | 'createdAt' | 'updatedAt'>
): Promise<string> {
  const collectionRef = collection(db, COLLECTION_NAME);
  const docRef = doc(collectionRef);
  const now = new Date().toISOString();

  // If steps are empty, generate default steps for selected category
  const steps = (clientData.steps && clientData.steps.length > 0)
    ? clientData.steps
    : generateStepsForCategory(clientData.category);

  const sanitized = sanitizeClientData({
    ...clientData,
    steps
  });

  const fullData: ClientAdminEntry = {
    ...sanitized,
    id: docRef.id,
    steps,
    createdAt: now,
    updatedAt: now
  } as ClientAdminEntry;

  // Immediate optimistic update
  const existing = getStoredClients();
  const updated = [fullData, ...existing.filter(c => c.id !== fullData.id)];
  saveStoredClients(updated);
  notifySubscribers(updated);

  try {
    await setDoc(docRef, removeUndefinedDeep(fullData));
  } catch (err) {
    console.error('Failed to create client in Firestore:', err);
  }

  return docRef.id;
}

/**
 * Updates a client admin record.
 */
export async function updateClient(
  id: string,
  updates: Partial<ClientAdminEntry>
): Promise<void> {
  const existing = getStoredClients();
  const currentClient = existing.find(c => c.id === id);
  const initialMatch = INITIAL_CLIENT_ADMIN.find(i => i.id === id);

  const cleanUpdates: Record<string, any> = {
    updatedAt: new Date().toISOString()
  };

  // Only include defined, non-empty properties from updates
  for (const [key, val] of Object.entries(updates)) {
    if (val !== undefined && key !== 'id') {
      if (typeof val === 'string') {
        cleanUpdates[key] = val.trim();
      } else {
        cleanUpdates[key] = val;
      }
    }
  }

  // Preserve existing clientName if update did not specify one or if specified as empty
  if (!cleanUpdates.clientName) {
    if (currentClient?.clientName) {
      cleanUpdates.clientName = currentClient.clientName;
    } else if (initialMatch?.clientName) {
      cleanUpdates.clientName = initialMatch.clientName;
    }
  }

  // Preserve other essential fields if somehow omitted
  if (!cleanUpdates.adviserName && currentClient?.adviserName) {
    cleanUpdates.adviserName = currentClient.adviserName;
  }
  if (!cleanUpdates.serviceType && currentClient?.serviceType) {
    cleanUpdates.serviceType = currentClient.serviceType;
  }

  const sanitizedCleanUpdates = removeUndefinedDeep(cleanUpdates);

  // Immediate optimistic update
  const updated = existing.map(c => (c.id === id ? { ...c, ...sanitizedCleanUpdates } : c));
  saveStoredClients(updated);
  notifySubscribers(updated);

  try {
    const docRef = doc(db, COLLECTION_NAME, id);
    await setDoc(docRef, sanitizedCleanUpdates, { merge: true });
  } catch (err) {
    console.error('Failed to update client in Firestore:', err);
  }
}

/**
 * Deletes a client admin record.
 */
export async function deleteClient(id: string): Promise<void> {
  // Update local cache and notify subscribers immediately
  const existing = getStoredClients();
  const updated = existing.filter(c => c.id !== id);
  saveStoredClients(updated);
  notifySubscribers(updated);

  try {
    const docRef = doc(db, COLLECTION_NAME, id);
    await deleteDoc(docRef);
  } catch (err) {
    console.error('Failed to delete client in Firestore:', err);
  }
}

/**
 * Toggles a specific admin step status for a client.
 * If all potential client stages are completed, automatically advances them to 'ongoing'.
 */
export async function toggleClientStep(
  clientId: string,
  stepId: string,
  isCompleted: boolean,
  completedBy: string = 'Sam Adams'
): Promise<void> {
  const existing = getStoredClients();
  const client = existing.find(c => c.id === clientId);
  if (!client) return;

  const nowFormatted = new Date().toLocaleDateString('en-GB', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  }).replace(/\//g, '-');

  const updatedSteps = client.steps.map(s => {
    if (s.id === stepId) {
      return {
        ...s,
        isCompleted,
        completedAt: isCompleted ? nowFormatted : '',
        completedBy: isCompleted ? completedBy : ''
      };
    }
    return s;
  });

  // Check if all stages for a potential client are complete -> auto-promote to 'ongoing'
  // Check if all stages for an ongoing client are complete -> auto-promote to 'onboarded'
  const isPotential = client.category === 'potential';
  const isOngoing = client.category === 'ongoing';
  const allStagesCompleted = updatedSteps.length > 0 && updatedSteps.every(s => s.isCompleted);

  if (isPotential && allStagesCompleted) {
    const ongoingSteps = generateStepsForCategory('ongoing');
    await updateClient(clientId, {
      clientName: client.clientName,
      category: 'ongoing',
      signUpDate: client.signUpDate || nowFormatted,
      nextAction: 'Complete AML/KYC Identity Verification & Dispatch LoAs',
      steps: ongoingSteps
    });
  } else if (isOngoing && allStagesCompleted) {
    await updateClient(clientId, {
      clientName: client.clientName,
      category: 'onboarded',
      steps: updatedSteps
    });
  } else {
    await updateClient(clientId, { 
      clientName: client.clientName,
      steps: updatedSteps 
    });
  }
}

/**
 * Moves client between categories (Potential -> Ongoing -> On Hold)
 */
export async function moveClientCategory(
  clientId: string,
  newCategory: ClientCategory,
  onHoldReason?: string,
  extraUpdates?: Partial<ClientAdminEntry>
): Promise<void> {
  const existing = getStoredClients();
  const client = existing.find(c => c.id === clientId);
  if (!client) return;

  const nowFormatted = new Date().toLocaleDateString('en-GB', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  }).replace(/\//g, '-');

  const updates: Partial<ClientAdminEntry> = {
    clientName: client.clientName,
    category: newCategory,
    ...(extraUpdates || {})
  };

  if (newCategory === 'ongoing') {
    if (!client.signUpDate) {
      updates.signUpDate = nowFormatted;
    }
    // If client had potential steps or empty steps, initialize ongoing workflow steps
    if (client.category === 'potential' || !client.steps || client.steps.length === 0 || client.steps[0]?.id?.includes('potential')) {
      const ongoingSteps = generateStepsForCategory('ongoing');
      // Note: Xplan FF is a separate practice management system workflow to the in-app Fact Find,
      // and is tracked manually on the admin checklist.
      updates.steps = ongoingSteps;
    }
  }

  if (newCategory === 'on_hold') {
    updates.onHoldReason = onHoldReason || client.onHoldReason || 'Temporarily on hold by adviser';
  } else {
    // If moving back to potential or ongoing or completed, clear on-hold reason
    updates.onHoldReason = '';
  }

  if (newCategory === 'completed') {
    updates.moneyLanded = true;
    updates.moneyLandedDate = client.moneyLandedDate || nowFormatted;
    updates.servicingSetUp = true;
    updates.servicingSetUpDate = client.servicingSetUpDate || nowFormatted;
    updates.steps = generateStepsForCategory('completed').map(s => ({
      ...s,
      isCompleted: true,
      completedAt: nowFormatted,
      completedBy: 'Sam Adams'
    }));
    // Also feed to Servicing pipeline
    await feedClientToServicing({
      ...client,
      ...updates
    } as ClientAdminEntry, nowFormatted);
  }

  await updateClient(clientId, updates);
}

/**
 * Handles Onboarded checklist updates for moneyLanded and servicingSetUp.
 * When both checkboxes are checked, automatically moves the client to 'completed'
 * and triggers feeding them into the Servicing pipeline.
 */
export async function updateOnboardedChecklist(
  clientId: string,
  updates: { moneyLanded?: boolean; servicingSetUp?: boolean }
): Promise<{ movedToCompleted: boolean }> {
  const existing = getStoredClients();
  const client = existing.find(c => c.id === clientId);
  if (!client) return { movedToCompleted: false };

  const nowFormatted = new Date().toLocaleDateString('en-GB', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  }).replace(/\//g, '-');

  const newMoneyLanded = updates.moneyLanded !== undefined ? updates.moneyLanded : Boolean(client.moneyLanded);
  const newServicingSetUp = updates.servicingSetUp !== undefined ? updates.servicingSetUp : Boolean(client.servicingSetUp);

  const moneyLandedDate = newMoneyLanded 
    ? (client.moneyLandedDate || nowFormatted)
    : '';

  const servicingSetUpDate = newServicingSetUp
    ? (client.servicingSetUpDate || nowFormatted)
    : '';

  const bothChecked = newMoneyLanded && newServicingSetUp;

  if (bothChecked) {
    // Move to 'completed' (dormant database) and trigger Servicing tab entry
    const completedSteps = generateStepsForCategory('completed').map(s => ({
      ...s,
      isCompleted: true,
      completedAt: nowFormatted,
      completedBy: 'Sam Adams'
    }));

    const clientForServicing: ClientAdminEntry = {
      ...client,
      category: 'completed',
      moneyLanded: true,
      moneyLandedDate: moneyLandedDate || nowFormatted,
      servicingSetUp: true,
      servicingSetUpDate: servicingSetUpDate || nowFormatted,
      nextAction: 'File completed and archived in dormant database • Active in Servicing tab',
      steps: completedSteps
    };

    await updateClient(clientId, {
      clientName: client.clientName,
      category: 'completed',
      moneyLanded: true,
      moneyLandedDate: moneyLandedDate || nowFormatted,
      servicingSetUp: true,
      servicingSetUpDate: servicingSetUpDate || nowFormatted,
      nextAction: 'File completed and archived in dormant database • Active in Servicing tab',
      steps: completedSteps
    });

    // Trigger feeding into Servicing tab pipeline
    await feedClientToServicing(clientForServicing, servicingSetUpDate || nowFormatted);

    return { movedToCompleted: true };
  } else {
    await updateClient(clientId, {
      clientName: client.clientName,
      moneyLanded: newMoneyLanded,
      moneyLandedDate,
      servicingSetUp: newServicingSetUp,
      servicingSetUpDate
    });

    return { movedToCompleted: false };
  }
}

/**
 * Updates a client's Fact Find data, synchronizing top-level client particulars if requested.
 */
export async function updateClientFactFind(
  clientId: string,
  factFind: ClientFactFind,
  syncTopLevelClientDetails: boolean = true
): Promise<void> {
  const existing = getStoredClients();
  const client = existing.find(c => c.id === clientId);
  if (!client) return;

  const updates: Partial<ClientAdminEntry> = {
    factFind: {
      ...factFind,
      updatedAt: new Date().toISOString()
    }
  };

  if (syncTopLevelClientDetails && factFind.stage1?.client1?.fullName) {
    const c1Name = factFind.stage1.client1.fullName.trim();
    const c2Name = factFind.stage1.hasSecondClient && factFind.stage1.client2?.fullName 
      ? factFind.stage1.client2.fullName.trim() 
      : '';

    updates.clientName = c2Name ? `${c1Name} & ${c2Name}` : c1Name;
    if (factFind.stage1.client1.email) updates.email = factFind.stage1.client1.email.trim();
    if (factFind.stage1.client1.phone) updates.phone = factFind.stage1.client1.phone.trim();
    if (factFind.stage1.adviser) updates.adviserName = factFind.stage1.adviser;
  }

  await updateClient(clientId, updates);
}

/**
 * Resets Client Admin collection to initial mock datasets.
 */
export async function resetClientsToInitial(): Promise<void> {
  try {
    const snapshot = await getDocs(collection(db, COLLECTION_NAME));
    const batch = writeBatch(db);
    snapshot.docs.forEach(d => batch.delete(d.ref));
    await batch.commit();

    const seedBatch = writeBatch(db);
    for (const item of INITIAL_CLIENT_ADMIN) {
      const docRef = doc(db, COLLECTION_NAME, item.id);
      const sanitized = sanitizeClientData(item);
      seedBatch.set(docRef, {
        ...sanitized,
        id: docRef.id,
        createdAt: item.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
    }
    await seedBatch.commit();
    saveStoredClients(INITIAL_CLIENT_ADMIN);
  } catch (error) {
    console.error('Error resetting clientAdmin in Firestore:', error);
    saveStoredClients(INITIAL_CLIENT_ADMIN);
  }
}
