import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  getDocs,
  writeBatch
} from 'firebase/firestore';
import { db } from '../firebase';
import { ProviderContact } from '../types';
import { INITIAL_PROVIDERS } from '../data/mockData';

const COLLECTION_NAME = 'providers';
const STORAGE_KEY = 'adams_poole_provider_directory';
let isSeeding = false;

export function getStoredProviders(): ProviderContact[] {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Failed to read providers from localStorage:', e);
  }
  return INITIAL_PROVIDERS;
}

export function saveStoredProviders(providers: ProviderContact[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(providers));
  } catch (e) {
    console.warn('Failed to save providers to localStorage:', e);
  }
}

/**
 * Initializes Firestore providers collection with INITIAL_PROVIDERS if empty.
 */
export async function initializeProvidersIfEmpty(): Promise<void> {
  if (isSeeding) return;
  isSeeding = true;

  try {
    const snapshot = await getDocs(collection(db, COLLECTION_NAME));
    if (snapshot.empty) {
      console.log('Firestore providers is empty, seeding defaults...');
      const batch = writeBatch(db);
      for (const item of INITIAL_PROVIDERS) {
        const itemDoc = doc(db, COLLECTION_NAME, item.id);
        batch.set(itemDoc, {
          name: item.name,
          mailingAddress: item.mailingAddress,
          email: item.email,
          phone: item.phone,
          bestSubmissionMethod: item.bestSubmissionMethod,
          avgTurnaroundDays: item.avgTurnaroundDays,
          notes: item.notes || '',
          id: item.id
        });
      }
      await batch.commit();
      console.log('Successfully seeded initial providers to Firestore.');
    }
  } catch (error) {
    console.error('Error during Firestore providers initialization:', error);
  } finally {
    isSeeding = false;
  }
}

/**
 * Subscribes to real-time updates for Provider Directory.
 */
export function subscribeToProviders(
  onUpdate: (providers: ProviderContact[]) => void,
  onError?: (error: Error) => void
): () => void {
  const providersCollection = collection(db, COLLECTION_NAME);

  const unsubscribe = onSnapshot(
    providersCollection,
    (snapshot) => {
      if (snapshot.empty) {
        initializeProvidersIfEmpty().catch(console.error);
        const fallback = getStoredProviders();
        onUpdate(fallback);
        return;
      }

      const entries: ProviderContact[] = snapshot.docs.map((docSnap) => {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          name: data.name || '',
          mailingAddress: data.mailingAddress || '',
          email: data.email || '',
          phone: data.phone || '',
          bestSubmissionMethod: data.bestSubmissionMethod || 'unipass',
          avgTurnaroundDays: Number(data.avgTurnaroundDays) || 14,
          notes: data.notes || ''
        };
      });

      // Sort alphabetically by name
      entries.sort((a, b) => a.name.localeCompare(b.name));
      saveStoredProviders(entries);
      onUpdate(entries);
    },
    (error) => {
      console.error('Firestore providers subscription error:', error);
      if (onError) onError(error);
      // Use local storage fallback on network failure
      const fallback = getStoredProviders();
      onUpdate(fallback);
    }
  );

  return unsubscribe;
}

export async function createProvider(data: Omit<ProviderContact, 'id'>): Promise<string> {
  const providersCollection = collection(db, COLLECTION_NAME);
  const newDocRef = doc(providersCollection);
  const newProvider: ProviderContact = {
    ...data,
    id: newDocRef.id
  };

  await setDoc(newDocRef, newProvider);

  // Update local cache
  const existing = getStoredProviders();
  saveStoredProviders([newProvider, ...existing]);

  return newDocRef.id;
}

export async function updateProvider(id: string, data: Partial<ProviderContact>): Promise<void> {
  const docRef = doc(db, COLLECTION_NAME, id);
  await setDoc(docRef, data, { merge: true });

  // Update local cache
  const existing = getStoredProviders();
  const updated = existing.map(p => (p.id === id ? { ...p, ...data } : p));
  saveStoredProviders(updated);
}

export async function deleteProvider(id: string): Promise<void> {
  const docRef = doc(db, COLLECTION_NAME, id);
  await deleteDoc(docRef);

  // Update local cache
  const existing = getStoredProviders();
  saveStoredProviders(existing.filter(p => p.id !== id));
}

export async function resetProvidersToInitial(): Promise<void> {
  try {
    const snapshot = await getDocs(collection(db, COLLECTION_NAME));
    const batch = writeBatch(db);
    snapshot.docs.forEach((d) => batch.delete(d.ref));
    await batch.commit();

    // Re-seed defaults
    const seedBatch = writeBatch(db);
    for (const item of INITIAL_PROVIDERS) {
      const itemDoc = doc(db, COLLECTION_NAME, item.id);
      seedBatch.set(itemDoc, {
        name: item.name,
        mailingAddress: item.mailingAddress,
        email: item.email,
        phone: item.phone,
        bestSubmissionMethod: item.bestSubmissionMethod,
        avgTurnaroundDays: item.avgTurnaroundDays,
        notes: item.notes || '',
        id: item.id
      });
    }
    await seedBatch.commit();
    saveStoredProviders(INITIAL_PROVIDERS);
  } catch (error) {
    console.error('Error resetting providers in Firestore:', error);
    saveStoredProviders(INITIAL_PROVIDERS);
  }
}
